from PyQt6.QtWidgets import QWidget
from PyQt6.QtGui import QPainter, QColor, QPen, QBrush, QFont
from PyQt6.QtCore import QTimer, QPoint
import math

class RadarWidget(QWidget):
    def __init__(self):
        super().__init__()
        self.angle = 0
        self.targets = []
        self.setMinimumSize(400, 400)
        
        self.timer = QTimer()
        self.timer.timeout.connect(self.animate)
        self.timer.start(30)

    def animate(self):
        self.angle += 2
        if self.angle >= 360:
            self.angle = 0
        self.repaint()

    def update_targets(self, targets):
        self.targets = targets
        self.repaint()

    def paintEvent(self, a0):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.fillRect(self.rect(), QColor("#041006"))

        center = self.rect().center()
        radius = min(self.width(), self.height()) // 2 - 20

        pen = QPen(QColor("#00FF44"))
        pen.setWidth(1)
        painter.setPen(pen)

        for r in range(1, 6):
            painter.drawEllipse(center, radius * r // 5, radius * r // 5)

        for angle in range(0, 360, 45):
            x = center.x() + math.cos(math.radians(angle)) * radius
            y = center.y() - math.sin(math.radians(angle)) * radius
            painter.drawLine(center.x(), center.y(), int(x), int(y))

        sweep_pen = QPen(QColor("#00FF44"))
        sweep_pen.setWidth(3)
        painter.setPen(sweep_pen)
        sweep_x = center.x() + math.cos(math.radians(self.angle)) * radius
        sweep_y = center.y() - math.sin(math.radians(self.angle)) * radius
        painter.drawLine(center.x(), center.y(), int(sweep_x), int(sweep_y))

        for i in range(20):
            fade_angle = self.angle - i * 2
            alpha = max(0, 255 - i * 12)
            fade_color = QColor(0, 255, 68, alpha)
            fade_pen = QPen(fade_color)
            fade_pen.setWidth(2)
            painter.setPen(fade_pen)
            x = center.x() + math.cos(math.radians(fade_angle)) * radius
            y = center.y() - math.sin(math.radians(fade_angle)) * radius
            painter.drawLine(center.x(), center.y(), int(x), int(y))

        for t in self.targets:
            x = center.x() + t[0] * radius
            y = center.y() - t[1] * radius
            
            glow_brush = QBrush(QColor(0, 255, 68, 100))
            painter.setBrush(glow_brush)
            painter.setPen(QPen(QColor(0, 255, 68, 100)))
            painter.drawEllipse(QPoint(int(x), int(y)), 12, 12)
            
            painter.setBrush(QBrush(QColor("#00FF44")))
            painter.setPen(QPen(QColor("#00FF44")))
            painter.drawEllipse(QPoint(int(x), int(y)), 6, 6)

        font = QFont("Arial", 10)
        painter.setFont(font)
        painter.setPen(QPen(QColor("#00AA44")))
        painter.drawText(center.x() - 30, 20, "RADAR SCAN")

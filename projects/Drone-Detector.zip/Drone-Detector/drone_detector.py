class DroneDetector:
    def __init__(self):
        self.threshold = -45

    def process(self, freq, power):
        if 2.40e9 <= freq <= 2.485e9 and power > self.threshold:
            return True

        if 5.72e9 <= freq <= 5.85e9 and power > self.threshold:
            return True

        return False

from PyQt6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QComboBox, QLabel
from PyQt6.QtCore import QTimer
import pyqtgraph as pg
import numpy as np

class WaterfallWidget(QWidget):
    def __init__(self, hackrf_backend):
        super().__init__()
        self.hackrf = hackrf_backend

        layout = QVBoxLayout()
        self.setLayout(layout)

        controls = QHBoxLayout()
        band_label = QLabel("Band:")
        band_label.setStyleSheet("color: #A8FFA8; font-size: 12px;")
        controls.addWidget(band_label)
        
        self.band_selector = QComboBox()
        self.band_selector.addItems(["2.4 GHz (2400-2485 MHz)", "5.8 GHz (5720-5850 MHz)"])
        self.band_selector.setStyleSheet("background-color: #1A2530; color: #A8FFA8; padding: 5px;")
        self.band_selector.currentIndexChanged.connect(self.on_band_change)
        controls.addWidget(self.band_selector)
        controls.addStretch()
        
        layout.addLayout(controls)

        self.img = pg.ImageView()
        self.img.ui.roiBtn.hide()
        self.img.ui.menuBtn.hide()
        
        colormap = pg.colormap.get('viridis')
        self.img.setColorMap(colormap)
        layout.addWidget(self.img)

        self.buffer = np.zeros((200, 512))

        self.timer = QTimer()
        self.timer.timeout.connect(self.update_waterfall)
        self.timer.start(150)

        self.center_freq = 2.45e9
        self.bands = {
            0: 2.45e9,
            1: 5.785e9
        }

    def on_band_change(self, index):
        self.center_freq = self.bands[index]
        self.buffer = np.zeros((200, 512))

    def update_waterfall(self):
        freqs, values = self.hackrf.get_fft(self.center_freq)

        row = np.interp(values, [-100, -20], [0, 255])
        row = row.astype(np.uint8)

        self.buffer = np.roll(self.buffer, -1, axis=0)
        self.buffer[-1] = row[:512]

        self.img.setImage(self.buffer.T, autoLevels=False)

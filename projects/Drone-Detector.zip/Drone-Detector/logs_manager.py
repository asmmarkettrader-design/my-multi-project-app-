import datetime

class LogsManager:
    def __init__(self):
        self.logs = []

    def add(self, text):
        t = datetime.datetime.now().strftime("%H:%M:%S")
        entry = f"[{t}] {text}"
        print(entry)
        self.logs.append(entry)

    def get_all(self):
        return self.logs

import numpy as np
import random

class HackRFBackend:
    def __init__(self):
        self.recent_hits = []
        self.sample_rate = 20_000_000
        self.bands = [
            (2_400_000_000, 2_485_000_000),
            (5_720_000_000, 5_850_000_000)
        ]
        self.current_band = 0

    def scan_once(self):
        if random.random() > 0.7:
            self.current_band = 1 - self.current_band
        
        band = self.bands[self.current_band]
        freq = random.uniform(band[0], band[1])
        power = random.uniform(-90, -20)

        if power > -40:
            x = random.uniform(-0.9, 0.9)
            y = random.uniform(-0.9, 0.9)
            self.recent_hits.append((x, y))

            if len(self.recent_hits) > 10:
                self.recent_hits.pop(0)

        return freq, power

    def get_recent_hits(self):
        return self.recent_hits

    def scan_frequency(self, freq):
        return random.uniform(-90, -20)

    def get_fft(self, center_freq):
        freqs = np.linspace(center_freq - 10e6, center_freq + 10e6, 1024)
        
        base_noise = np.random.normal(-70, 5, 1024)
        
        if random.random() > 0.6:
            spike_pos = random.randint(100, 924)
            spike_width = random.randint(10, 50)
            spike_height = random.uniform(20, 40)
            for i in range(max(0, spike_pos - spike_width), min(1024, spike_pos + spike_width)):
                distance = abs(i - spike_pos)
                base_noise[i] += spike_height * np.exp(-distance**2 / (2 * (spike_width/3)**2))
        
        return freqs, base_noise

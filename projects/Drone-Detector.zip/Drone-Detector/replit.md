# Drone Detector by Ali Abbas

## Overview
A military-style radar dashboard application for RF spectrum analysis and drone detection. Built with PyQt6 and pyqtgraph for real-time visualization.

## Project Structure
```
DroneDetectorByAliAbbas/
├── main.py              # Application entry point
├── ui_main.py           # Main UI window with military radar dashboard
├── radar_widget.py      # Animated radar display widget
├── spectrum_analyzer.py # Real-time FFT spectrum graph with band selector
├── waterfall_widget.py  # Waterfall spectrogram display with band selector
├── hackrf_backend.py    # HackRF One scanning engine (simulation mode)
├── drone_detector.py    # Drone signature recognition
├── logs_manager.py      # Log management system
└── assets/              # Icons and images
    └── app_icon.ico     # Application icon
```

## Features
- **Radar Display**: Animated military-style radar sweep with target tracking
- **Spectrum Analyzer**: Real-time FFT visualization with band selector (2.4 GHz / 5.8 GHz)
- **Waterfall View**: Spectrogram display with band selector for frequency analysis over time
- **Manual Frequency Scan**: Input specific frequencies for targeted scanning
- **Drone Detection**: Automatic detection of drone signatures in 2.4 GHz and 5.8 GHz bands
- **Logging System**: Real-time logging of detection events
- **Band Selection**: Switch between 2.4 GHz and 5.8 GHz bands for spectrum/waterfall views

## Technical Details
- **Framework**: PyQt6 for GUI
- **Visualization**: pyqtgraph for real-time graphs
- **Backend**: Simulated HackRF scanning (can be connected to real HackRF One)
- **Detection Bands**: 2.4 GHz (2400-2485 MHz) and 5.8 GHz (5720-5850 MHz)

## Running the Application
The application runs as a desktop GUI using VNC display. Simply start the "Drone Detector" workflow.

## Windows 10 Deployment
To create a Windows executable on Windows 10, follow these steps:

1. Install Python 3.11 on Windows
2. Copy all the project files to your Windows machine
3. Install dependencies:
   ```bash
   pip install PyQt6 pyqtgraph numpy pyinstaller
   ```
4. Create the executable:
   ```bash
   pyinstaller --onefile --windowed --icon=assets/app_icon.ico --name="DroneDetector" main.py
   ```
5. The executable will be in the `dist` folder

## Recent Changes
- 2025-12-08: Initial project setup with all core components
- Added band selector to Spectrum Analyzer and Waterfall View
- Backend now simulates both 2.4 GHz and 5.8 GHz frequency bands
- Fixed PyQt6 compatibility issues with pen styles
- Configured VNC display for desktop application

## Dependencies
- PyQt6
- pyqtgraph
- numpy (via pyqtgraph)

from PyQt6.QtWidgets import *
from PyQt6.QtGui import *
from PyQt6.QtCore import *

from radar_widget import RadarWidget
from spectrum_analyzer import SpectrumAnalyzer
from waterfall_widget import WaterfallWidget
from hackrf_backend import HackRFBackend
from logs_manager import LogsManager
from drone_detector import DroneDetector


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("Drone Detector by Ali Abbas")
        self.setWindowIcon(QIcon("assets/app_icon.ico"))
        self.setMinimumSize(1400, 850)
        self.setStyleSheet("background-color: #0A0F1A; color: #A8FFA8;")

        self.hackrf = HackRFBackend()
        self.logs = LogsManager()
        self.drone_detector = DroneDetector()

        container = QWidget()
        main_layout = QGridLayout()
        container.setLayout(main_layout)
        self.setCentralWidget(container)

        self.radar = RadarWidget()
        main_layout.addWidget(self.radar, 0, 0, 2, 1)

        self.info_panel = self.build_info_panel()
        main_layout.addWidget(self.info_panel, 0, 1)

        self.tabs = QTabWidget()
        self.tabs.addTab(SpectrumAnalyzer(self.hackrf), "Spectrum Analyzer")
        self.tabs.addTab(WaterfallWidget(self.hackrf), "Waterfall View")
        self.tabs.addTab(self.manual_frequency_tab(), "Manual Frequency")
        main_layout.addWidget(self.tabs, 1, 1)

        self.log_panel = self.build_log_panel()
        main_layout.addWidget(self.log_panel, 2, 0, 1, 2)

        self.timer = QTimer()
        self.timer.timeout.connect(self.update_loop)
        self.timer.start(150)

    def update_loop(self):
        freq, power = self.hackrf.scan_once()
        detected = self.drone_detector.process(freq, power)

        if detected:
            self.logs.add(f"Drone detected @ {freq/1e6:.2f} MHz")
            self.log_view.append(self.logs.logs[-1])
            self.update_info_panel(freq, power)

        self.radar.update_targets(self.hackrf.get_recent_hits())

    def update_info_panel(self, freq, power):
        self.status_label.setText("DRONE DETECTED!")
        self.status_label.setStyleSheet("color: #FF4444; font-weight: bold; font-size: 16px;")
        self.freq_label.setText(f"Freq: {freq/1e6:.2f} MHz")
        self.dist_label.setText(f"Signal Power: {power:.2f} dB")
        self.coord_label.setText(f"Band: {'2.4 GHz' if freq < 3e9 else '5.8 GHz'}")

    def build_info_panel(self):
        panel = QGroupBox("Drone Info")
        panel.setStyleSheet("color: #A8FFA8; font-size: 14px;")
        layout = QVBoxLayout()
        panel.setLayout(layout)

        self.status_label = QLabel("No drone detected")
        self.status_label.setStyleSheet("font-size: 16px; font-weight: bold;")
        layout.addWidget(self.status_label)

        self.freq_label = QLabel("Freq: ---")
        self.dist_label = QLabel("Signal Power: ---")
        self.coord_label = QLabel("Band: ---")
        layout.addWidget(self.freq_label)
        layout.addWidget(self.dist_label)
        layout.addWidget(self.coord_label)

        return panel

    def manual_frequency_tab(self):
        tab = QWidget()
        layout = QVBoxLayout()
        tab.setLayout(layout)

        self.manual_freq_input = QLineEdit()
        self.manual_freq_input.setPlaceholderText("Enter Frequency (e.g. 2404.6)")
        self.manual_freq_input.setStyleSheet("background-color: #1A2530; color: #A8FFA8; padding: 10px; font-size: 14px;")
        layout.addWidget(self.manual_freq_input)

        btn = QPushButton("Scan Frequency")
        btn.setStyleSheet("background-color: #00AA44; color: white; padding: 10px; font-size: 14px; font-weight: bold;")
        btn.clicked.connect(self.scan_manual_frequency)
        layout.addWidget(btn)

        self.manual_result = QLabel("---")
        self.manual_result.setStyleSheet("font-size: 14px;")
        layout.addWidget(self.manual_result)

        return tab

    def scan_manual_frequency(self):
        try:
            freq = float(self.manual_freq_input.text()) * 1e6
            power = self.hackrf.scan_frequency(freq)
            self.manual_result.setText(f"Power: {power:.2f} dB")
        except:
            self.manual_result.setText("Invalid frequency")

    def build_log_panel(self):
        box = QGroupBox("LOGS")
        box.setStyleSheet("color: #A8FFA8;")
        layout = QVBoxLayout()
        box.setLayout(layout)

        self.log_view = QTextEdit()
        self.log_view.setReadOnly(True)
        self.log_view.setStyleSheet("background-color: #0A1510; color: #00FF44; font-family: monospace;")
        layout.addWidget(self.log_view)

        return box

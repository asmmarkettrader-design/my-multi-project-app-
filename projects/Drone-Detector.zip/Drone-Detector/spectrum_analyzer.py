from PyQt6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QComboBox, QLabel
from PyQt6.QtCore import QTimer, Qt
import pyqtgraph as pg

class SpectrumAnalyzer(QWidget):
    def __init__(self, hackrf_backend):
        super().__init__()
        self.hackrf = hackrf_backend

        layout = QVBoxLayout()
        self.setLayout(layout)

        controls = QHBoxLayout()
        band_label = QLabel("Band:")
        band_label.setStyleSheet("color: #A8FFA8; font-size: 12px;")
        controls.addWidget(band_label)
        
        self.band_selector = QComboBox()
        self.band_selector.addItems(["2.4 GHz (2400-2485 MHz)", "5.8 GHz (5720-5850 MHz)"])
        self.band_selector.setStyleSheet("background-color: #1A2530; color: #A8FFA8; padding: 5px;")
        self.band_selector.currentIndexChanged.connect(self.on_band_change)
        controls.addWidget(self.band_selector)
        controls.addStretch()
        
        layout.addLayout(controls)

        self.graph = pg.PlotWidget()
        self.graph.setBackground('#0A0F1A')
        self.graph.showGrid(x=True, y=True, alpha=0.3)
        self.graph.setLabel('bottom', 'Frequency (MHz)', color='#A8FFA8')
        self.graph.setLabel('left', 'Power (dB)', color='#A8FFA8')
        plot_item = self.graph.getPlotItem()
        if plot_item:
            plot_item.setTitle("Live Spectrum Analyzer - 2.4 GHz Band", color='#00FF44')

        layout.addWidget(self.graph)

        self.curve = self.graph.plot(pen=pg.mkPen('#00FF44', width=2))
        self.threshold_line = self.graph.addLine(y=-45, pen=pg.mkPen('#FF4444', width=1, style=Qt.PenStyle.DashLine))

        self.timer = QTimer()
        self.timer.timeout.connect(self.update_spectrum)
        self.timer.start(200)

        self.center_freq = 2.45e9
        self.bands = {
            0: (2.45e9, "2.4 GHz Band"),
            1: (5.785e9, "5.8 GHz Band")
        }

    def on_band_change(self, index):
        self.center_freq = self.bands[index][0]
        plot_item = self.graph.getPlotItem()
        if plot_item:
            plot_item.setTitle(f"Live Spectrum Analyzer - {self.bands[index][1]}", color='#00FF44')

    def update_spectrum(self):
        freqs, values = self.hackrf.get_fft(self.center_freq)
        freqs_mhz = freqs / 1e6
        self.curve.setData(freqs_mhz, values)

#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                         🤖 JARVIS WITH ALI - CORE 🤖                          ║
║                    The Autonomous Intelligence Heartbeat                      ║
║                                                                               ║
║  Version: 1.0.0-alpha                                                        ║
║  Architect: Lead AI Engineer - Tier-1 Defense & Automation Firm              ║
║  Stack: Python 3.9+ | CustomTkinter | OpenCV | Groq | Gemini | Nvidia NIM    ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

import os
import sys
import time
import json
import gc
import threading
import asyncio
import queue
from datetime import datetime
from typing import Dict, List, Optional, Callable, Any, Union
from dataclasses import dataclass, field
from enum import Enum, auto
from pathlib import Path
import warnings

# Suppress warnings for cleaner logs
warnings.filterwarnings('ignore')

# Add parent directory to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent))

# Core imports with graceful fallback
try:
    import customtkinter as ctk
    GUI_AVAILABLE = True
except ImportError:
    GUI_AVAILABLE = False
    print("[WARNING] CustomTkinter not available. Running in CLI mode.")

try:
    import cv2
    import numpy as np
    VISION_AVAILABLE = True
except ImportError:
    VISION_AVAILABLE = False
    print("[WARNING] OpenCV not available. Vision modules disabled.")

# =============================================================================
# SYSTEM STATE ENUMS
# =============================================================================

class SystemState(Enum):
    """Core system states for state machine"""
    INITIALIZING = auto()
    BOOTING = auto()
    IDLE = auto()
    LISTENING = auto()
    PROCESSING = auto()
    EXECUTING = auto()
    LEARNING = auto()
    ERROR = auto()
    SHUTDOWN = auto()

class ModuleStatus(Enum):
    """Module health status"""
    OFFLINE = "🔴"
    LOADING = "🟡"
    ONLINE = "🟢"
    ERROR = "⚠️"
    UPDATING = "🔵"

# =============================================================================
# DATA CLASSES
# =============================================================================

@dataclass
class SystemMetrics:
    """Real-time system performance metrics"""
    cpu_percent: float = 0.0
    memory_used_mb: float = 0.0
    memory_total_mb: float = 8192.0
    uptime_seconds: float = 0.0
    api_calls_count: int = 0
    last_gc_time: float = 0.0
    active_threads: int = 0
    
    @property
    def memory_percent(self) -> float:
        return (self.memory_used_mb / self.memory_total_mb) * 100

@dataclass
class IntelligenceRequest:
    """Unified request structure for all AI brains"""
    request_id: str
    timestamp: float
    source: str  # 'voice', 'gui', 'automation', 'scheduled'
    query: str
    context: Dict[str, Any] = field(default_factory=dict)
    priority: int = 5  # 1-10, lower is higher priority
    callback: Optional[Callable] = None
    
@dataclass
class IntelligenceResponse:
    """Unified response structure from AI brains"""
    request_id: str
    success: bool
    source_brain: str  # 'groq', 'gemini', 'fusion'
    content: str
    execution_time_ms: float
    metadata: Dict[str, Any] = field(default_factory=dict)

# =============================================================================
# THE HEARTBEAT - MAIN ORCHESTRATOR
# =============================================================================

class JarvisCore:
    """
    🫀 THE HEARTBEAT - Central Orchestrator
    
    Manages all subsystems, coordinates between modules,
    handles memory optimization, and ensures recursive evolution.
    """
    
    _instance = None
    _lock = threading.Lock()
    
    def __new__(cls, *args, **kwargs):
        """Singleton pattern for single core instance"""
        if not cls._instance:
            with cls._lock:
                if not cls._instance:
                    cls._instance = super().__new__(cls)
        return cls._instance
    
    def __init__(self, config_path: Optional[str] = None):
        """Initialize the Jarvis Core"""
        if hasattr(self, '_initialized'):
            return
            
        self._initialized = True
        self.start_time = time.time()
        self.state = SystemState.INITIALIZING
        self.metrics = SystemMetrics()
        
        # Configuration
        self.config = self._load_config(config_path)
        self.debug_mode = self.config.get('debug', False)
        
        # Module registry
        self.modules: Dict[str, Any] = {}
        self.module_status: Dict[str, ModuleStatus] = {}
        
        # Communication queues
        self.request_queue: queue.PriorityQueue = queue.PriorityQueue()
        self.response_queue: queue.Queue = queue.Queue()
        self.event_queue: queue.Queue = queue.Queue()
        
        # Threading
        self.threads: Dict[str, threading.Thread] = {}
        self.running = False
        self.shutdown_event = threading.Event()
        
        # Logging
        self.log_history: List[Dict] = []
        self.max_log_entries = 1000
        
        # Callbacks
        self.state_callbacks: List[Callable] = []
        self.log_callbacks: List[Callable] = []
        
        self._log("🚀 JARVIS CORE INITIALIZING...", "SYSTEM")
        
    # ========================================================================
    # CONFIGURATION
    # ========================================================================
    
    def _load_config(self, config_path: Optional[str]) -> Dict:
        """Load configuration from YAML or return defaults"""
        default_config = {
            'debug': False,
            'memory_limit_mb': 4096,
            'gc_interval_seconds': 60,
            'api_timeout_seconds': 30,
            'screen_scan_interval': 2.0,
            'log_level': 'INFO',
            'gui_enabled': True,
            'voice_enabled': True,
            'vision_enabled': True,
            'auto_update': True,
            'sandbox_mode': True,
            'api_keys': {
                'groq': os.getenv('GROQ_API_KEY', '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'),
                'gemini': os.getenv('GEMINI_API_KEY', 'AIzaSyBs3-vbv7XF_8uCGcKRjQxEQVBCVYCh1G0'),
                'nvidia_nim': os.getenv('NVIDIA_NIM_API_KEY', '')
            },
            'paths': {
                'data': './data',
                'logs': './data/logs',
                'cache': './data/cache',
                'downloads': './data/downloads',
                'modules': './evolution/handlers'
            }
        }
        
        if config_path and os.path.exists(config_path):
            try:
                import yaml
                with open(config_path, 'r') as f:
                    user_config = yaml.safe_load(f)
                    default_config.update(user_config)
                self._log(f"✅ Config loaded from {config_path}", "CONFIG")
            except Exception as e:
                self._log(f"⚠️ Config load failed: {e}. Using defaults.", "CONFIG")
        
        # Ensure directories exist
        for path_key, path_val in default_config['paths'].items():
            Path(path_val).mkdir(parents=True, exist_ok=True)
            
        return default_config
    
    # ========================================================================
    # LOGGING SYSTEM
    # ========================================================================
    
    def _log(self, message: str, module: str = "CORE", level: str = "INFO"):
        """Central logging with terminal output and callbacks"""
        timestamp = datetime.now().strftime("%H:%M:%S.%f")[:-3]
        log_entry = {
            'timestamp': timestamp,
            'module': module,
            'level': level,
            'message': message,
            'unix_time': time.time()
        }
        
        self.log_history.append(log_entry)
        
        # Trim log history
        if len(self.log_history) > self.max_log_entries:
            self.log_history = self.log_history[-self.max_log_entries:]
        
        # Terminal output with colors
        color_map = {
            "INFO": "\033[36m",      # Cyan
            "WARNING": "\033[33m",   # Yellow
            "ERROR": "\033[31m",     # Red
            "SUCCESS": "\033[32m",   # Green
            "SYSTEM": "\033[35m",    # Magenta
            "API": "\033[34m",       # Blue
            "DEBUG": "\033[90m"      # Gray
        }
        reset = "\033[0m"
        color = color_map.get(level, "")
        
        log_line = f"{color}[{timestamp}] [{module:12}] {message}{reset}"
        print(log_line)
        
        # Trigger callbacks
        for callback in self.log_callbacks:
            try:
                callback(log_entry)
            except Exception as e:
                print(f"Log callback error: {e}")
    
    def get_recent_logs(self, count: int = 50, module_filter: Optional[str] = None) -> List[Dict]:
        """Get recent log entries with optional filtering"""
        logs = self.log_history[-count:] if count < len(self.log_history) else self.log_history
        if module_filter:
            logs = [log for log in logs if log['module'] == module_filter]
        return logs
    
    # ========================================================================
    # MODULE MANAGEMENT
    # ========================================================================
    
    def register_module(self, name: str, module_instance: Any, dependencies: List[str] = None):
        """Register a module with the core"""
        self._log(f"📦 Registering module: {name}", "MODULE")
        self.module_status[name] = ModuleStatus.LOADING
        
        # Check dependencies
        if dependencies:
            for dep in dependencies:
                if dep not in self.modules:
                    self._log(f"⚠️ Dependency {dep} not found for {name}", "MODULE")
        
        self.modules[name] = module_instance
        self.module_status[name] = ModuleStatus.ONLINE
        self._log(f"✅ Module {name} registered successfully", "MODULE")
        
    def get_module(self, name: str) -> Optional[Any]:
        """Get a registered module"""
        return self.modules.get(name)
    
    def get_module_status(self) -> Dict[str, str]:
        """Get status of all modules"""
        return {name: status.value for name, status in self.module_status.items()}
    
    # ========================================================================
    # STATE MANAGEMENT
    # ========================================================================
    
    def set_state(self, new_state: SystemState):
        """Change system state and notify listeners"""
        old_state = self.state
        self.state = new_state
        self._log(f"🔄 State change: {old_state.name} → {new_state.name}", "STATE")
        
        for callback in self.state_callbacks:
            try:
                callback(old_state, new_state)
            except Exception as e:
                self._log(f"State callback error: {e}", "ERROR")
    
    # ========================================================================
    # MEMORY MANAGEMENT
    # ========================================================================
    
    def _memory_monitor(self):
        """Background thread for memory monitoring and GC"""
        import psutil
        
        while not self.shutdown_event.is_set():
            try:
                process = psutil.Process()
                mem_info = process.memory_info()
                
                self.metrics.memory_used_mb = mem_info.rss / 1024 / 1024
                self.metrics.cpu_percent = process.cpu_percent()
                self.metrics.active_threads = threading.active_count()
                self.metrics.uptime_seconds = time.time() - self.start_time
                
                # Aggressive GC if memory threshold exceeded
                if self.metrics.memory_percent > 80:
                    self._log(f"⚠️ High memory usage: {self.metrics.memory_percent:.1f}%. Running GC...", "MEMORY")
                    gc.collect()
                    self.metrics.last_gc_time = time.time()
                
                # Periodic GC
                if time.time() - self.metrics.last_gc_time > self.config['gc_interval_seconds']:
                    gc.collect()
                    self.metrics.last_gc_time = time.time()
                    if self.debug_mode:
                        self._log(f"🧹 Periodic GC completed. Memory: {self.metrics.memory_used_mb:.1f}MB", "MEMORY")
                
                time.sleep(5)
                
            except Exception as e:
                self._log(f"Memory monitor error: {e}", "ERROR")
                time.sleep(10)
    
    # ========================================================================
    # MAIN LIFECYCLE
    # ========================================================================
    
    def bootstrap(self):
        """Initialize all core subsystems"""
        self._log("🔄 BOOTSTRAP SEQUENCE INITIATED", "SYSTEM")
        self.set_state(SystemState.BOOTING)
        
        # Start memory monitor
        mem_thread = threading.Thread(target=self._memory_monitor, name="MemoryMonitor", daemon=True)
        mem_thread.start()
        self.threads['memory'] = mem_thread
        
        # Initialize modules in order
        self._init_security()
        self._init_brain()
        self._init_vision()
        self._init_voice()
        self._init_gui()
        self._init_tools()
        self._init_automation()
        self._init_evolution()
        
        self._log("✅ BOOTSTRAP COMPLETE", "SYSTEM")
        self.set_state(SystemState.IDLE)
        
    def _init_security(self):
        """Initialize security module"""
        try:
            from security.encryption import SecurityManager
            from security.api_key_manager import APIKeyManager
            
            security = SecurityManager()
            key_manager = APIKeyManager(self.config['api_keys'])
            
            self.register_module('security', security)
            self.register_module('key_manager', key_manager)
            
        except Exception as e:
            self._log(f"Security init failed: {e}", "ERROR")
    
    def _init_brain(self):
        """Initialize AI brain modules"""
        try:
            from brain.api_manager import APIManager
            from brain.groq_engine import GroqEngine
            from brain.gemini_engine import GeminiEngine
            from brain.context_fusion import ContextFusion
            
            api_manager = APIManager(self.config['api_keys'])
            groq = GroqEngine(self.config['api_keys']['groq'])
            gemini = GeminiEngine(self.config['api_keys']['gemini'])
            fusion = ContextFusion(groq, gemini)
            
            self.register_module('api_manager', api_manager, ['security'])
            self.register_module('groq', groq)
            self.register_module('gemini', gemini)
            self.register_module('fusion', fusion, ['groq', 'gemini'])
            
        except Exception as e:
            self._log(f"Brain init failed: {e}", "ERROR")
    
    def _init_vision(self):
        """Initialize vision modules"""
        if not self.config['vision_enabled'] or not VISION_AVAILABLE:
            self._log("Vision modules disabled", "VISION")
            return
            
        try:
            from vision.screen_perception import ScreenPerception
            from vision.ui_detector import UIDetector
            from vision.screen_capture import ScreenCapture
            
            screen_cap = ScreenCapture()
            ui_detector = UIDetector()
            screen_perception = ScreenPerception(
                screen_cap, ui_detector,
                self.config['api_keys'].get('nvidia_nim', ''),
                scan_interval=self.config['screen_scan_interval']
            )
            
            self.register_module('screen_capture', screen_cap)
            self.register_module('ui_detector', ui_detector)
            self.register_module('screen_perception', screen_perception, ['screen_capture', 'ui_detector'])
            
        except Exception as e:
            self._log(f"Vision init failed: {e}", "ERROR")
    
    def _init_voice(self):
        """Initialize voice modules"""
        if not self.config['voice_enabled']:
            self._log("Voice modules disabled", "VOICE")
            return
            
        try:
            from voice.stt_engine import STTEngine
            from voice.tts_engine import TTSEngine
            from voice.wake_word import WakeWordDetector
            
            stt = STTEngine()
            tts = TTSEngine()
            wake = WakeWordDetector()
            
            self.register_module('stt', stt)
            self.register_module('tts', tts)
            self.register_module('wake_word', wake)
            
        except Exception as e:
            self._log(f"Voice init failed: {e}", "ERROR")
    
    def _init_gui(self):
        """Initialize GUI"""
        if not self.config['gui_enabled'] or not GUI_AVAILABLE:
            self._log("GUI disabled - running in CLI mode", "GUI")
            return
            
        try:
            from gui.interface import JarvisHUD
            
            gui = JarvisHUD(self)
            self.register_module('gui', gui)
            
        except Exception as e:
            self._log(f"GUI init failed: {e}", "ERROR")
    
    def _init_tools(self):
        """Initialize tool modules"""
        try:
            from tools.video_editor import VideoEditor
            from smm_ecommerce.seo_auditor import SEOAuditor
            from smm_ecommerce.shopify_manager import ShopifyManager
            from financial.nbp_monitor import NBPMonitor
            from ghost_coder.code_generator import GhostCoder
            
            video_editor = VideoEditor()
            seo = SEOAuditor()
            shopify = ShopifyManager()
            nbp = NBPMonitor()
            ghost = GhostCoder()
            
            self.register_module('video_editor', video_editor)
            self.register_module('seo_auditor', seo)
            self.register_module('shopify', shopify)
            self.register_module('nbp_monitor', nbp)
            self.register_module('ghost_coder', ghost)
            
        except Exception as e:
            self._log(f"Tools init failed: {e}", "ERROR")
    
    def _init_automation(self):
        """Initialize automation modules"""
        try:
            from automation.global_app_handler import GlobalAppHandler
            from automation.pyautogui_controller import PyAutoGUIController
            
            controller = PyAutoGUIController()
            app_handler = GlobalAppHandler(controller)
            
            self.register_module('controller', controller)
            self.register_module('app_handler', app_handler, ['controller'])
            
        except Exception as e:
            self._log(f"Automation init failed: {e}", "ERROR")
    
    def _init_evolution(self):
        """Initialize self-evolution modules"""
        try:
            from evolution.self_upgrade import SelfUpgrade
            from evolution.module_generator import ModuleGenerator
            from evolution.dependency_manager import DependencyManager
            
            upgrader = SelfUpgrade()
            generator = ModuleGenerator()
            dep_manager = DependencyManager()
            
            self.register_module('upgrader', upgrader)
            self.register_module('module_generator', generator)
            self.register_module('dep_manager', dep_manager)
            
            # Check for updates if enabled
            if self.config['auto_update']:
                threading.Thread(target=dep_manager.check_updates, daemon=True).start()
                
        except Exception as e:
            self._log(f"Evolution init failed: {e}", "ERROR")
    
    # ========================================================================
    # REQUEST PROCESSING
    # ========================================================================
    
    def process_request(self, request: IntelligenceRequest) -> IntelligenceResponse:
        """Process an intelligence request through the appropriate brain"""
        self.set_state(SystemState.PROCESSING)
        start_time = time.time()
        
        self._log(f"🧠 Processing request {request.request_id}: {request.query[:50]}...", "API")
        
        try:
            # Determine which brain to use
            fusion = self.get_module('fusion')
            
            if fusion:
                response_content = fusion.process(request)
                source = 'fusion'
            elif self.get_module('groq'):
                response_content = self.get_module('groq').process(request)
                source = 'groq'
            elif self.get_module('gemini'):
                response_content = self.get_module('gemini').process(request)
                source = 'gemini'
            else:
                raise RuntimeError("No AI brain available")
            
            execution_time = (time.time() - start_time) * 1000
            self.metrics.api_calls_count += 1
            
            response = IntelligenceResponse(
                request_id=request.request_id,
                success=True,
                source_brain=source,
                content=response_content,
                execution_time_ms=execution_time
            )
            
            self._log(f"✅ Request {request.request_id} completed in {execution_time:.1f}ms", "API")
            
        except Exception as e:
            execution_time = (time.time() - start_time) * 1000
            response = IntelligenceResponse(
                request_id=request.request_id,
                success=False,
                source_brain='error',
                content=f"Error: {str(e)}",
                execution_time_ms=execution_time
            )
            self._log(f"❌ Request {request.request_id} failed: {e}", "ERROR")
        
        self.set_state(SystemState.IDLE)
        return response
    
    def queue_request(self, request: IntelligenceRequest):
        """Queue a request for async processing"""
        self.request_queue.put((request.priority, time.time(), request))
        self._log(f"📥 Queued request {request.request_id} (priority {request.priority})", "QUEUE")
    
    def _request_processor(self):
        """Background thread for processing queued requests"""
        while not self.shutdown_event.is_set():
            try:
                if not self.request_queue.empty():
                    priority, timestamp, request = self.request_queue.get(timeout=1)
                    response = self.process_request(request)
                    
                    if request.callback:
                        request.callback(response)
                    else:
                        self.response_queue.put(response)
                else:
                    time.sleep(0.1)
            except Exception as e:
                self._log(f"Request processor error: {e}", "ERROR")
    
    # ========================================================================
    # MAIN LOOP
    # ========================================================================
    
    def run(self):
        """Main execution loop"""
        self._log("🚀 JARVIS WITH ALI ACTIVATED", "SYSTEM")
        self.running = True
        
        # Start request processor
        req_thread = threading.Thread(target=self._request_processor, name="RequestProcessor", daemon=True)
        req_thread.start()
        self.threads['request_processor'] = req_thread
        
        # Start GUI if available
        gui = self.get_module('gui')
        if gui:
            gui.run()
        else:
            self._cli_loop()
    
    def _cli_loop(self):
        """CLI mode main loop"""
        self._log("Running in CLI mode. Type 'exit' to quit.", "SYSTEM")
        
        while self.running:
            try:
                user_input = input("\n🤖 JARVIS> ")
                
                if user_input.lower() in ['exit', 'quit', 'shutdown']:
                    self.shutdown()
                    break
                
                request = IntelligenceRequest(
                    request_id=f"cli_{int(time.time()*1000)}",
                    timestamp=time.time(),
                    source='cli',
                    query=user_input,
                    priority=5
                )
                
                response = self.process_request(request)
                print(f"\n🧠 [{response.source_brain.upper()}]: {response.content}\n")
                
            except KeyboardInterrupt:
                self.shutdown()
                break
            except Exception as e:
                self._log(f"CLI error: {e}", "ERROR")
    
    # ========================================================================
    # SHUTDOWN
    # ========================================================================
    
    def shutdown(self):
        """Graceful shutdown sequence"""
        self._log("🛑 SHUTDOWN SEQUENCE INITIATED", "SYSTEM")
        self.set_state(SystemState.SHUTDOWN)
        self.running = False
        self.shutdown_event.set()
        
        # Stop all threads
        for name, thread in self.threads.items():
            self._log(f"Stopping thread: {name}", "SYSTEM")
        
        # Cleanup
        gc.collect()
        
        self._log("👋 JARVIS OFFLINE. GOODBYE.", "SYSTEM")
        
    # ========================================================================
    # UTILITY METHODS
    # ========================================================================
    
    def get_system_info(self) -> Dict:
        """Get comprehensive system information"""
        return {
            'version': '1.0.0-alpha',
            'state': self.state.name,
            'uptime': self.metrics.uptime_seconds,
            'memory': {
                'used_mb': round(self.metrics.memory_used_mb, 2),
                'total_mb': self.metrics.memory_total_mb,
                'percent': round(self.metrics.memory_percent, 2)
            },
            'api_calls': self.metrics.api_calls_count,
            'modules': self.get_module_status(),
            'threads': self.metrics.active_threads
        }


# =============================================================================
# ENTRY POINT
# =============================================================================

def main():
    """Main entry point for Jarvis"""
    print("""
    ╔══════════════════════════════════════════════════════════════════════════╗
    ║                                                                          ║
    ║     ██╗ █████╗ ██████╗ ██╗   ██╗██╗███████╗    ██╗    ██╗██╗████████╗  ║
    ║     ██║██╔══██╗██╔══██╗██║   ██║██║██╔════╝    ██║    ██║██║╚══██╔══╝  ║
    ║     ██║███████║██████╔╝██║   ██║██║███████╗    ██║ █╗ ██║██║   ██║     ║
    ║     ██║██╔══██║██╔══██╗╚██╗ ██╔╝██║╚════██║    ██║███╗██║██║   ██║     ║
    ║     ██║██║  ██║██║  ██║ ╚████╔╝ ██║███████║    ╚███╔███╔╝██║   ██║     ║
    ║     ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝  ╚═══╝  ╚═╝╚══════╝     ╚══╝╚══╝ ╚═╝   ╚═╝     ║
    ║                                                                          ║
    ║              🤖 AUTONOMOUS INTELLIGENCE OVERLAY v1.0.0 🤖               ║
    ║                                                                          ║
    ╚══════════════════════════════════════════════════════════════════════════╝
    """)
    
    # Initialize core
    config_path = sys.argv[1] if len(sys.argv) > 1 else None
    jarvis = JarvisCore(config_path)
    
    # Bootstrap all systems
    jarvis.bootstrap()
    
    # Run main loop
    try:
        jarvis.run()
    except Exception as e:
        print(f"Fatal error: {e}")
        jarvis.shutdown()
        sys.exit(1)


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                    🎨 JARVIS GUI - HACKER HUD INTERFACE 🎨                    ║
║                                                                              ║
║  Visual Aesthetic: High-tech Hacker HUD with transparent overlay            ║
║  Colors: Cyan (#00FFFF) / Blue (#0080FF) / Dark background                  ║
║  Features: Rotating Intelligence Core, Real-time Terminal Logs              ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

import os
import sys
import time
import threading
import queue
from datetime import datetime
from typing import Optional, Callable, List, Dict, Any
from pathlib import Path

# CustomTkinter for modern UI
try:
    import customtkinter as ctk
    from customtkinter import CTk, CTkFrame, CTkLabel, CTkButton, CTkEntry, CTkTextbox, CTkProgressBar
    CTK_AVAILABLE = True
except ImportError:
    CTK_AVAILABLE = False
    print("[ERROR] CustomTkinter not installed. GUI cannot start.")

# OpenCV for overlay effects
try:
    import cv2
    import numpy as np
    from PIL import Image, ImageTk, ImageDraw, ImageFont
    CV_AVAILABLE = True
except ImportError:
    CV_AVAILABLE = False
    print("[WARNING] OpenCV/PIL not available. Visual effects disabled.")

# =============================================================================
# THEME CONFIGURATION - Hacker HUD Colors
# =============================================================================

class HUDTheme:
    """Hacker HUD Color Scheme"""
    # Primary Colors
    CYAN = "#00FFFF"
    CYAN_DARK = "#00AAAA"
    CYAN_GLOW = "#AAFFFF"
    
    # Secondary Colors
    BLUE = "#0080FF"
    BLUE_DARK = "#004080"
    BLUE_GLOW = "#80C0FF"
    
    # Accent Colors
    GREEN = "#00FF80"
    YELLOW = "#FFAA00"
    ORANGE = "#FF6600"
    RED = "#FF0040"
    MAGENTA = "#FF00FF"
    
    # Background Colors
    BG_DARK = "#0A0A0F"
    BG_PANEL = "#12121A"
    BG_TERMINAL = "#08080C"
    
    # Text Colors
    TEXT_PRIMARY = "#E0E0E0"
    TEXT_SECONDARY = "#808080"
    TEXT_DIM = "#404040"
    
    # Transparency
    ALPHA_OVERLAY = 0.95

# =============================================================================
# JARVIS HUD - Main Interface
# =============================================================================

class JarvisHUD:
    """
    🎨 THE HACKER HUD - Main GUI Interface
    
    Features:
    - Transparent overlay with glowing cyan/blue theme
    - Rotating central Intelligence Core
    - Real-time scrolling terminal logs
    - Voice visualizer
    - System status indicators
    - API call monitoring
    """
    
    def __init__(self, core_instance: Any):
        """Initialize the Hacker HUD"""
        if not CTK_AVAILABLE:
            raise RuntimeError("CustomTkinter not available")
        
        self.core = core_instance
        self.theme = HUDTheme()
        
        # Window settings
        self.width = 1400
        self.height = 900
        self.transparency = 0.97
        
        # Animation states
        self.core_rotation = 0.0
        self.animation_running = True
        self.pulse_state = 0
        
        # Data queues
        self.log_queue = queue.Queue()
        self.api_call_queue = queue.Queue()
        
        # Callbacks
        self.command_callback: Optional[Callable] = None
        
        # UI Elements storage
        self.ui_elements = {}
        
        self._log("HUD Interface initializing...")
        self._setup_window()
        self._create_layout()
        self._start_animations()
        
    def _log(self, message: str):
        """Internal logging"""
        print(f"[HUD] {message}")
        
    # ========================================================================
    # WINDOW SETUP
    # ========================================================================
    
    def _setup_window(self):
        """Configure the main window"""
        ctk.set_appearance_mode("dark")
        ctk.set_default_color_theme("dark-blue")
        
        self.root = CTk()
        self.root.title("🤖 JARVIS WITH ALI - Autonomous Intelligence Overlay")
        self.root.geometry(f"{self.width}x{self.height}")
        self.root.configure(fg_color=self.theme.BG_DARK)
        
        # Make window transparent (Windows)
        try:
            self.root.attributes('-alpha', self.transparency)
            self.root.attributes('-topmost', False)
        except:
            pass
        
        # Custom font setup
        self.font_main = ("Consolas", 12)
        self.font_mono = ("Courier New", 10)
        self.font_title = ("Consolas", 14, "bold")
        self.font_large = ("Consolas", 18, "bold")
        
        # Handle close
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)
        
        self._log("Window configured")
    
    # ========================================================================
    # LAYOUT CREATION
    # ========================================================================
    
    def _create_layout(self):
        """Create the Hacker HUD layout"""
        # Main container with grid
        self.root.grid_columnconfigure(0, weight=1)
        self.root.grid_rowconfigure(0, weight=0)  # Header
        self.root.grid_rowconfigure(1, weight=1)  # Main content
        self.root.grid_rowconfigure(2, weight=0)  # Footer
        
        # Header
        self._create_header()
        
        # Main Content Area
        self.main_frame = CTkFrame(self.root, fg_color=self.theme.BG_DARK)
        self.main_frame.grid(row=1, column=0, sticky="nsew", padx=10, pady=5)
        self.main_frame.grid_columnconfigure(0, weight=1)
        self.main_frame.grid_columnconfigure(1, weight=2)
        self.main_frame.grid_columnconfigure(2, weight=1)
        self.main_frame.grid_rowconfigure(0, weight=1)
        
        # Left Panel - System Status
        self._create_left_panel()
        
        # Center Panel - Intelligence Core
        self._create_center_panel()
        
        # Right Panel - API Monitor
        self._create_right_panel()
        
        # Footer - Input & Controls
        self._create_footer()
        
        self._log("Layout created")
    
    def _create_header(self):
        """Create header bar with title and system info"""
        header = CTkFrame(self.root, fg_color=self.theme.BG_PANEL, height=50)
        header.grid(row=0, column=0, sticky="ew", padx=10, pady=5)
        header.grid_propagate(False)
        
        # Title with glow effect
        title = CTkLabel(
            header, 
            text="◉ JARVIS WITH ALI",
            font=self.font_large,
            text_color=self.theme.CYAN
        )
        title.place(x=20, y=10)
        
        # Status indicators
        self.status_groq = CTkLabel(header, text="● GROQ", font=self.font_main, text_color=self.theme.GREEN)
        self.status_groq.place(x=300, y=15)
        
        self.status_gemini = CTkLabel(header, text="● GEMINI", font=self.font_main, text_color=self.theme.GREEN)
        self.status_gemini.place(x=400, y=15)
        
        self.status_vision = CTkLabel(header, text="● VISION", font=self.font_main, text_color=self.theme.GREEN)
        self.status_vision.place(x=520, y=15)
        
        # System metrics
        self.metrics_label = CTkLabel(
            header, 
            text="RAM: 0MB | CPU: 0% | Uptime: 00:00:00",
            font=self.font_mono,
            text_color=self.theme.TEXT_SECONDARY
        )
        self.metrics_label.place(relx=0.98, rely=0.5, anchor="e")
        
        self.ui_elements['header'] = header
        self.ui_elements['metrics'] = self.metrics_label
    
    def _create_left_panel(self):
        """Create left panel with terminal logs"""
        left_frame = CTkFrame(self.main_frame, fg_color=self.theme.BG_PANEL)
        left_frame.grid(row=0, column=0, sticky="nsew", padx=5, pady=5)
        left_frame.grid_columnconfigure(0, weight=1)
        left_frame.grid_rowconfigure(1, weight=1)
        
        # Panel title
        title = CTkLabel(
            left_frame, 
            text="▣ SYSTEM LOGS",
            font=self.font_title,
            text_color=self.theme.CYAN
        )
        title.grid(row=0, column=0, sticky="w", padx=10, pady=5)
        
        # Terminal text box
        self.terminal = CTkTextbox(
            left_frame,
            fg_color=self.theme.BG_TERMINAL,
            text_color=self.theme.TEXT_PRIMARY,
            font=self.font_mono,
            wrap="word",
            state="disabled"
        )
        self.terminal.grid(row=1, column=0, sticky="nsew", padx=10, pady=5)
        
        # Tag configurations for colors
        self.terminal.tag_config("INFO", foreground=self.theme.CYAN)
        self.terminal.tag_config("WARNING", foreground=self.theme.YELLOW)
        self.terminal.tag_config("ERROR", foreground=self.theme.RED)
        self.terminal.tag_config("SUCCESS", foreground=self.theme.GREEN)
        self.terminal.tag_config("API", foreground=self.theme.BLUE)
        self.terminal.tag_config("SYSTEM", foreground=self.theme.MAGENTA)
        
        self.ui_elements['terminal'] = self.terminal
        self.ui_elements['left_panel'] = left_frame
    
    def _create_center_panel(self):
        """Create center panel with Intelligence Core"""
        center_frame = CTkFrame(self.main_frame, fg_color=self.theme.BG_PANEL)
        center_frame.grid(row=0, column=1, sticky="nsew", padx=5, pady=5)
        center_frame.grid_columnconfigure(0, weight=1)
        center_frame.grid_rowconfigure(0, weight=2)  # Core
        center_frame.grid_rowconfigure(1, weight=1)  # Voice visualizer
        
        # Intelligence Core Canvas
        self.core_canvas = self._create_intelligence_core(center_frame)
        self.core_canvas.grid(row=0, column=0, sticky="nsew", padx=10, pady=10)
        
        # Voice Visualizer
        self.voice_canvas = self._create_voice_visualizer(center_frame)
        self.voice_canvas.grid(row=1, column=0, sticky="nsew", padx=10, pady=10)
        
        self.ui_elements['center_panel'] = center_frame
        self.ui_elements['core_canvas'] = self.core_canvas
    
    def _create_intelligence_core(self, parent) -> Any:
        """Create the rotating Intelligence Core visualization"""
        if CV_AVAILABLE:
            # Use OpenCV/Canvas for animated core
            from tkinter import Canvas
            canvas = Canvas(
                parent, 
                bg=self.theme.BG_PANEL, 
                highlightthickness=0,
                width=400,
                height=400
            )
            
            # Create core elements
            canvas.create_oval(150, 150, 250, 250, fill=self.theme.CYAN, outline="", tags="core_inner")
            canvas.create_oval(100, 100, 300, 300, outline=self.theme.CYAN, width=2, tags="core_ring1")
            canvas.create_oval(50, 50, 350, 350, outline=self.theme.BLUE, width=1, tags="core_ring2")
            
            # Orbiting particles
            for i in range(8):
                angle = i * 45
                canvas.create_oval(0, 0, 10, 10, fill=self.theme.CYAN, tags=f"particle_{i}")
            
            # Status text
            canvas.create_text(
                200, 380, 
                text="INTELLIGENCE CORE ONLINE",
                fill=self.theme.CYAN,
                font=("Consolas", 10)
            )
            
            return canvas
        else:
            # Fallback to label
            label = CTkLabel(
                parent,
                text="◉\nINTELLIGENCE\nCORE\nONLINE",
                font=("Consolas", 24, "bold"),
                text_color=self.theme.CYAN
            )
            return label
    
    def _create_voice_visualizer(self, parent) -> Any:
        """Create voice waveform visualizer"""
        if CV_AVAILABLE:
            from tkinter import Canvas
            canvas = Canvas(
                parent,
                bg=self.theme.BG_TERMINAL,
                highlightthickness=0,
                height=100
            )
            
            # Create initial waveform bars
            bar_count = 30
            bar_width = 8
            gap = 4
            start_x = 20
            
            for i in range(bar_count):
                x = start_x + i * (bar_width + gap)
                canvas.create_rectangle(
                    x, 50, x + bar_width, 50,
                    fill=self.theme.CYAN,
                    outline="",
                    tags=f"bar_{i}"
                )
            
            canvas.create_text(
                200, 85,
                text="VOICE INPUT READY",
                fill=self.theme.TEXT_SECONDARY,
                font=("Consolas", 9)
            )
            
            return canvas
        else:
            return CTkLabel(parent, text="♪ Voice Ready", text_color=self.theme.CYAN)
    
    def _create_right_panel(self):
        """Create right panel with API monitor and module status"""
        right_frame = CTkFrame(self.main_frame, fg_color=self.theme.BG_PANEL)
        right_frame.grid(row=0, column=2, sticky="nsew", padx=5, pady=5)
        right_frame.grid_columnconfigure(0, weight=1)
        
        # API Monitor Section
        api_title = CTkLabel(
            right_frame,
            text="▣ API MONITOR",
            font=self.font_title,
            text_color=self.theme.BLUE
        )
        api_title.grid(row=0, column=0, sticky="w", padx=10, pady=5)
        
        self.api_text = CTkTextbox(
            right_frame,
            fg_color=self.theme.BG_TERMINAL,
            text_color=self.theme.TEXT_PRIMARY,
            font=self.font_mono,
            height=200,
            state="disabled"
        )
        self.api_text.grid(row=1, column=0, sticky="ew", padx=10, pady=5)
        
        # Module Status Section
        module_title = CTkLabel(
            right_frame,
            text="▣ MODULE STATUS",
            font=self.font_title,
            text_color=self.theme.BLUE
        )
        module_title.grid(row=2, column=0, sticky="w", padx=10, pady=(15, 5))
        
        self.module_frame = CTkFrame(right_frame, fg_color=self.theme.BG_TERMINAL)
        self.module_frame.grid(row=3, column=0, sticky="nsew", padx=10, pady=5)
        
        # Module status labels (will be updated dynamically)
        self.module_labels = {}
        modules = [
            ("Brain", "brain"),
            ("Vision", "vision"),
            ("Voice", "voice"),
            ("Video", "video"),
            ("Ghost Coder", "ghost"),
            ("Finance", "finance"),
            ("Automation", "auto"),
            ("Evolution", "evolution")
        ]
        
        for i, (name, key) in enumerate(modules):
            label = CTkLabel(
                self.module_frame,
                text=f"● {name}",
                font=self.font_mono,
                text_color=self.theme.GREEN
            )
            label.grid(row=i, column=0, sticky="w", padx=10, pady=2)
            self.module_labels[key] = label
        
        self.ui_elements['right_panel'] = right_frame
        self.ui_elements['api_text'] = self.api_text
    
    def _create_footer(self):
        """Create footer with input and controls"""
        footer = CTkFrame(self.root, fg_color=self.theme.BG_PANEL, height=80)
        footer.grid(row=2, column=0, sticky="ew", padx=10, pady=5)
        footer.grid_propagate(False)
        footer.grid_columnconfigure(0, weight=1)
        
        # Command input
        self.command_input = CTkEntry(
            footer,
            placeholder_text="Enter command or speak...",
            font=self.font_main,
            fg_color=self.theme.BG_TERMINAL,
            text_color=self.theme.TEXT_PRIMARY,
            border_color=self.theme.CYAN,
            border_width=1,
            height=40
        )
        self.command_input.grid(row=0, column=0, sticky="ew", padx=(10, 5), pady=15)
        self.command_input.bind("<Return>", self._on_command_enter)
        
        # Buttons
        btn_frame = CTkFrame(footer, fg_color="transparent")
        btn_frame.grid(row=0, column=1, sticky="e", padx=5, pady=15)
        
        self.voice_btn = CTkButton(
            btn_frame,
            text="🎤",
            font=("Segoe UI", 16),
            width=40,
            height=40,
            fg_color=self.theme.CYAN_DARK,
            hover_color=self.theme.CYAN,
            command=self._toggle_voice
        )
        self.voice_btn.pack(side="left", padx=2)
        
        self.send_btn = CTkButton(
            btn_frame,
            text="SEND",
            font=self.font_main,
            width=80,
            height=40,
            fg_color=self.theme.BLUE,
            hover_color=self.theme.BLUE_GLOW,
            command=self._send_command
        )
        self.send_btn.pack(side="left", padx=2)
        
        self.clear_btn = CTkButton(
            btn_frame,
            text="CLEAR",
            font=self.font_main,
            width=80,
            height=40,
            fg_color=self.theme.BG_TERMINAL,
            hover_color=self.theme.RED,
            command=self._clear_terminal
        )
        self.clear_btn.pack(side="left", padx=2)
        
        self.ui_elements['footer'] = footer
        self.ui_elements['command_input'] = self.command_input
    
    # ========================================================================
    # ANIMATIONS
    # ========================================================================
    
    def _start_animations(self):
        """Start all animation threads"""
        if CV_AVAILABLE:
            self.anim_thread = threading.Thread(target=self._animation_loop, daemon=True)
            self.anim_thread.start()
        
        # Start update loops
        self._schedule_updates()
    
    def _animation_loop(self):
        """Main animation loop for Intelligence Core"""
        while self.animation_running:
            try:
                self.core_rotation = (self.core_rotation + 2) % 360
                self.pulse_state = (self.pulse_state + 0.1) % (2 * 3.14159)
                
                # Update core visualization
                self.root.after(0, self._update_core_visualization)
                
                time.sleep(0.033)  # ~30 FPS
            except Exception as e:
                time.sleep(0.1)
    
    def _update_core_visualization(self):
        """Update the Intelligence Core canvas"""
        if not CV_AVAILABLE:
            return
        
        try:
            canvas = self.core_canvas
            
            # Pulse effect
            pulse = abs(int(50 * (1 + 0.3 * (1 + self.pulse_state))))
            
            # Update ring sizes with pulse
            canvas.coords("core_ring1", 100 - pulse/4, 100 - pulse/4, 300 + pulse/4, 300 + pulse/4)
            
            # Update orbiting particles
            import math
            for i in range(8):
                angle = math.radians(self.core_rotation + i * 45)
                radius = 150
                x = 200 + radius * math.cos(angle)
                y = 200 + radius * math.sin(angle)
                canvas.coords(f"particle_{i}", x-5, y-5, x+5, y+5)
            
        except Exception as e:
            pass
    
    def _schedule_updates(self):
        """Schedule periodic UI updates"""
        self._update_metrics()
        self._process_log_queue()
        self._process_api_queue()
        self._update_voice_visualizer()
    
    def _update_metrics(self):
        """Update system metrics display"""
        if self.core:
            metrics = self.core.get_system_info()
            mem_used = metrics['memory']['used_mb']
            mem_pct = metrics['memory']['percent']
            uptime = metrics['uptime']
            
            hours = int(uptime // 3600)
            minutes = int((uptime % 3600) // 60)
            seconds = int(uptime % 60)
            
            text = f"RAM: {mem_used:.0f}MB ({mem_pct:.0f}%) | Uptime: {hours:02d}:{minutes:02d}:{seconds:02d}"
            self.metrics_label.configure(text=text)
        
        self.root.after(1000, self._update_metrics)
    
    def _update_voice_visualizer(self):
        """Update voice waveform animation"""
        if CV_AVAILABLE and hasattr(self, 'voice_canvas'):
            try:
                import random
                for i in range(30):
                    height = random.randint(10, 80)
                    x1 = 20 + i * 12
                    y1 = 50 - height // 2
                    x2 = x1 + 8
                    y2 = 50 + height // 2
                    self.voice_canvas.coords(f"bar_{i}", x1, y1, x2, y2)
            except:
                pass
        
        self.root.after(100, self._update_voice_visualizer)
    
    # ========================================================================
    # LOG HANDLING
    # ========================================================================
    
    def add_log(self, message: str, level: str = "INFO", module: str = "SYSTEM"):
        """Add a log entry to the terminal"""
        timestamp = datetime.now().strftime("%H:%M:%S")
        log_line = f"[{timestamp}] [{module:10}] {message}\n"
        self.log_queue.put((log_line, level))
    
    def _process_log_queue(self):
        """Process queued log entries"""
        try:
            while not self.log_queue.empty():
                log_line, level = self.log_queue.get_nowait()
                
                self.terminal.configure(state="normal")
                self.terminal.insert("end", log_line, level)
                self.terminal.see("end")
                
                # Limit lines
                lines = self.terminal.get("1.0", "end").split("\n")
                if len(lines) > 500:
                    self.terminal.delete("1.0", f"{len(lines) - 500}.0")
                
                self.terminal.configure(state="disabled")
        except:
            pass
        
        self.root.after(100, self._process_log_queue)
    
    def add_api_call(self, api_name: str, endpoint: str, duration_ms: float):
        """Record an API call"""
        self.api_call_queue.put((api_name, endpoint, duration_ms))
    
    def _process_api_queue(self):
        """Process API call records"""
        try:
            while not self.api_call_queue.empty():
                api_name, endpoint, duration = self.api_call_queue.get_nowait()
                
                timestamp = datetime.now().strftime("%H:%M:%S")
                line = f"[{timestamp}] {api_name}: {endpoint[:30]}... ({duration:.0f}ms)\n"
                
                self.api_text.configure(state="normal")
                self.api_text.insert("end", line)
                self.api_text.see("end")
                self.api_text.configure(state="disabled")
        except:
            pass
        
        self.root.after(500, self._process_api_queue)
    
    # ========================================================================
    # EVENT HANDLERS
    # ========================================================================
    
    def _on_command_enter(self, event=None):
        """Handle Enter key in command input"""
        self._send_command()
    
    def _send_command(self):
        """Send command to core"""
        command = self.command_input.get().strip()
        if command:
            self.add_log(f"User: {command}", "INFO", "INPUT")
            self.command_input.delete(0, "end")
            
            if self.command_callback:
                self.command_callback(command)
    
    def _toggle_voice(self):
        """Toggle voice input"""
        self.add_log("Voice input toggled", "INFO", "VOICE")
    
    def _clear_terminal(self):
        """Clear terminal output"""
        self.terminal.configure(state="normal")
        self.terminal.delete("1.0", "end")
        self.terminal.configure(state="disabled")
    
    def set_command_callback(self, callback: Callable):
        """Set callback for command input"""
        self.command_callback = callback
    
    def _on_close(self):
        """Handle window close"""
        self.animation_running = False
        if self.core:
            self.core.shutdown()
        self.root.destroy()
    
    # ========================================================================
    # MAIN LOOP
    # ========================================================================
    
    def run(self):
        """Start the GUI main loop"""
        self._log("HUD starting main loop")
        
        # Connect to core logging
        if self.core:
            self.core.log_callbacks.append(self._on_core_log)
        
        self.root.mainloop()
    
    def _on_core_log(self, log_entry: Dict):
        """Receive logs from core"""
        self.add_log(log_entry['message'], log_entry['level'], log_entry['module'])
    
    def update_module_status(self, module: str, status: str):
        """Update module status indicator"""
        if module in self.module_labels:
            color = {
                "online": self.theme.GREEN,
                "offline": self.theme.RED,
                "loading": self.theme.YELLOW,
                "error": self.theme.RED
            }.get(status.lower(), self.theme.TEXT_SECONDARY)
            
            self.module_labels[module].configure(text_color=color)


# =============================================================================
# STANDALONE TEST
# =============================================================================

if __name__ == "__main__":
    # Test the HUD standalone
    class MockCore:
        def get_system_info(self):
            return {
                'memory': {'used_mb': 1024, 'percent': 25},
                'uptime': 3661
            }
        def shutdown(self):
            print("Mock shutdown")
    
    hud = JarvisHUD(MockCore())
    
    # Add some test logs
    for i in range(10):
        hud.add_log(f"Test log message {i}", "INFO" if i % 3 else "WARNING")
    
    hud.run()

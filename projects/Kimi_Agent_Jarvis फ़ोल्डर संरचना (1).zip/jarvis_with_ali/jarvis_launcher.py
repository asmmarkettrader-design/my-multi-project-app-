#!/usr/bin/env python3
"""
JARVIS WITH ALI - LAUNCHER
Simple entry point for the autonomous system
"""
import sys
import os

# Add core to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from core.main import main

if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                    🧠 BRAIN API MANAGER - INTELLIGENCE FUSION                 ║
║                                                                              ║
║  Manages Groq (Primary Brain) and Gemini (High-Context Brain)               ║
║  Coordinates between APIs for optimal response quality and speed            ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

import os
import time
import json
import asyncio
from typing import Dict, List, Optional, Any, Union, Callable
from dataclasses import dataclass, field
from enum import Enum
from concurrent.futures import ThreadPoolExecutor, as_completed
import threading

# API Clients
try:
    import groq
    GROQ_AVAILABLE = True
except ImportError:
    GROQ_AVAILABLE = False

try:
    import google.generativeai as genai
    GEMINI_AVAILABLE = True
except ImportError:
    GEMINI_AVAILABLE = False

import requests


# =============================================================================
# DATA CLASSES & ENUMS
# =============================================================================

class BrainType(Enum):
    """Available AI brains"""
    GROQ = "groq"
    GEMINI = "gemini"
    FUSION = "fusion"
    FALLBACK = "fallback"

class RequestPriority(Enum):
    """Request priority levels"""
    CRITICAL = 1    # System alerts, errors
    HIGH = 2        # User commands
    NORMAL = 3      # General queries
    LOW = 4         # Background tasks
    BACKGROUND = 5  # Learning, updates

@dataclass
class BrainResponse:
    """Standardized response from any brain"""
    success: bool
    content: str
    brain_used: BrainType
    latency_ms: float
    tokens_used: int = 0
    metadata: Dict[str, Any] = field(default_factory=dict)
    error: Optional[str] = None

@dataclass
class BrainRequest:
    """Standardized request to any brain"""
    query: str
    context: Dict[str, Any] = field(default_factory=dict)
    priority: RequestPriority = RequestPriority.NORMAL
    prefer_speed: bool = True  # True = Groq, False = Gemini
    require_context: bool = False  # Force Gemini for large context
    system_prompt: Optional[str] = None
    max_tokens: Optional[int] = None
    temperature: float = 0.7
    callback: Optional[Callable] = None


# =============================================================================
# API MANAGER - Main Coordinator
# =============================================================================

class APIManager:
    """
    🧠 API MANAGER - Central coordinator for all AI brains
    
    Features:
    - Automatic brain selection based on query type
    - Load balancing between Groq and Gemini
    - Fallback mechanisms
    - Request queuing and prioritization
    - Usage tracking and rate limiting
    """
    
    def __init__(self, api_keys: Dict[str, str]):
        """Initialize API Manager with all brain modules"""
        self.api_keys = api_keys
        self.logger = self._setup_logger()
        
        # Initialize brain modules
        self.groq = None
        self.gemini = None
        self.fusion = None
        
        self._init_brains()
        
        # Request queue
        self.request_queue = []
        self.queue_lock = threading.Lock()
        
        # Usage tracking
        self.usage_stats = {
            'groq': {'calls': 0, 'tokens': 0, 'errors': 0},
            'gemini': {'calls': 0, 'tokens': 0, 'errors': 0}
        }
        
        # Thread pool for async operations
        self.executor = ThreadPoolExecutor(max_workers=4)
        
        self.logger("API Manager initialized")
    
    def _setup_logger(self):
        """Setup logging function"""
        def log(msg: str, level: str = "INFO"):
            print(f"[API Manager] [{level}] {msg}")
        return log
    
    def _init_brains(self):
        """Initialize all brain modules"""
        # Initialize Groq
        if GROQ_AVAILABLE and self.api_keys.get('groq'):
            try:
                from .groq_engine import GroqEngine
                self.groq = GroqEngine(self.api_keys['groq'])
                self.logger("Groq engine initialized")
            except Exception as e:
                self.logger(f"Groq init failed: {e}", "ERROR")
        
        # Initialize Gemini
        if GEMINI_AVAILABLE and self.api_keys.get('gemini'):
            try:
                from .gemini_engine import GeminiEngine
                self.gemini = GeminiEngine(self.api_keys['gemini'])
                self.logger("Gemini engine initialized")
            except Exception as e:
                self.logger(f"Gemini init failed: {e}", "ERROR")
        
        # Initialize Fusion if both are available
        if self.groq and self.gemini:
            try:
                from .context_fusion import ContextFusion
                self.fusion = ContextFusion(self.groq, self.gemini)
                self.logger("Context Fusion initialized")
            except Exception as e:
                self.logger(f"Fusion init failed: {e}", "ERROR")
    
    # ========================================================================
    # REQUEST ROUTING
    # ========================================================================
    
    def route_request(self, request: BrainRequest) -> BrainResponse:
        """
        Route request to appropriate brain based on query characteristics
        
        Routing Logic:
        - Speed critical + Short context → Groq
        - Large context (>100k tokens) → Gemini
        - Complex reasoning → Fusion
        - Code generation → Groq (faster)
        - Video/Document analysis → Gemini
        """
        start_time = time.time()
        
        # Determine best brain
        brain = self._select_brain(request)
        
        self.logger(f"Routing to {brain.value}: {request.query[:50]}...")
        
        # Execute request
        try:
            if brain == BrainType.GROQ and self.groq:
                response = self.groq.process(request)
                self.usage_stats['groq']['calls'] += 1
                
            elif brain == BrainType.GEMINI and self.gemini:
                response = self.gemini.process(request)
                self.usage_stats['gemini']['calls'] += 1
                
            elif brain == BrainType.FUSION and self.fusion:
                response = self.fusion.process(request)
                
            else:
                # Fallback to available brain
                response = self._fallback_process(request)
            
            latency = (time.time() - start_time) * 1000
            response.latency_ms = latency
            
            self.logger(f"Response received in {latency:.1f}ms")
            return response
            
        except Exception as e:
            latency = (time.time() - start_time) * 1000
            self.logger(f"Request failed: {e}", "ERROR")
            return BrainResponse(
                success=False,
                content="",
                brain_used=brain,
                latency_ms=latency,
                error=str(e)
            )
    
    def _select_brain(self, request: BrainRequest) -> BrainType:
        """Select the best brain for the request"""
        query = request.query.lower()
        
        # Force Gemini for large context requirements
        if request.require_context:
            return BrainType.GEMINI if self.gemini else BrainType.GROQ
        
        # Check for video/document analysis patterns
        video_patterns = ['youtube', 'video', 'analyze video', 'transcript', 'podcast']
        if any(p in query for p in video_patterns):
            return BrainType.GEMINI if self.gemini else BrainType.GROQ
        
        # Check for financial analysis (complex)
        financial_patterns = ['analyze', 'audit', 'financial', 'investment', 'portfolio']
        if any(p in query for p in financial_patterns):
            return BrainType.FUSION if self.fusion else BrainType.GEMINI
        
        # Code generation - prefer Groq for speed
        code_patterns = ['code', 'write', 'function', 'script', 'program', 'debug']
        if any(p in query for p in code_patterns):
            return BrainType.GROQ if self.groq else BrainType.GEMINI
        
        # Default based on preference
        if request.prefer_speed and self.groq:
            return BrainType.GROQ
        elif self.gemini:
            return BrainType.GEMINI
        else:
            return BrainType.GROQ if self.groq else BrainType.FALLBACK
    
    def _fallback_process(self, request: BrainRequest) -> BrainResponse:
        """Fallback processing when preferred brain unavailable"""
        if self.groq:
            return self.groq.process(request)
        elif self.gemini:
            return self.gemini.process(request)
        else:
            return BrainResponse(
                success=False,
                content="No AI brain available",
                brain_used=BrainType.FALLBACK,
                latency_ms=0,
                error="All brains offline"
            )
    
    # ========================================================================
    # ASYNC OPERATIONS
    # ========================================================================
    
    def process_async(self, request: BrainRequest, callback: Callable):
        """Process request asynchronously"""
        future = self.executor.submit(self.route_request, request)
        
        def on_complete(fut):
            try:
                response = fut.result()
                callback(response)
            except Exception as e:
                callback(BrainResponse(
                    success=False,
                    content="",
                    brain_used=BrainType.FALLBACK,
                    latency_ms=0,
                    error=str(e)
                ))
        
        future.add_done_callback(on_complete)
        return future
    
    def parallel_query(self, requests: List[BrainRequest]) -> List[BrainResponse]:
        """Execute multiple requests in parallel"""
        futures = [self.executor.submit(self.route_request, req) for req in requests]
        return [f.result() for f in as_completed(futures)]
    
    # ========================================================================
    # SPECIALIZED METHODS
    # ========================================================================
    
    def quick_response(self, query: str, context: str = "") -> str:
        """Get quick response (uses Groq for speed)"""
        request = BrainRequest(
            query=query,
            context={'previous': context},
            prefer_speed=True
        )
        response = self.route_request(request)
        return response.content if response.success else f"Error: {response.error}"
    
    def deep_analysis(self, query: str, documents: List[str] = None) -> str:
        """Deep analysis (uses Gemini for context)"""
        request = BrainRequest(
            query=query,
            context={'documents': documents or []},
            require_context=True,
            prefer_speed=False
        )
        response = self.route_request(request)
        return response.content if response.success else f"Error: {response.error}"
    
    def generate_code(self, description: str, language: str = "python") -> str:
        """Generate code (uses Groq for speed)"""
        request = BrainRequest(
            query=f"Write {language} code: {description}",
            system_prompt="You are an expert programmer. Write clean, well-documented code.",
            prefer_speed=True
        )
        response = self.route_request(request)
        return response.content if response.success else f"Error: {response.error}"
    
    def analyze_video_content(self, transcript: str, query: str) -> str:
        """Analyze video content (uses Gemini for large context)"""
        request = BrainRequest(
            query=f"Analyze this video transcript and answer: {query}\n\nTranscript:\n{transcript[:50000]}",
            require_context=True,
            prefer_speed=False
        )
        response = self.route_request(request)
        return response.content if response.success else f"Error: {response.error}"
    
    # ========================================================================
    # USAGE & HEALTH
    # ========================================================================
    
    def get_usage_stats(self) -> Dict:
        """Get usage statistics"""
        return {
            'groq': self.usage_stats['groq'].copy(),
            'gemini': self.usage_stats['gemini'].copy(),
            'total_calls': sum(s['calls'] for s in self.usage_stats.values()),
            'total_errors': sum(s['errors'] for s in self.usage_stats.values())
        }
    
    def health_check(self) -> Dict[str, bool]:
        """Check health of all brains"""
        return {
            'groq': self.groq is not None and self.groq.is_healthy(),
            'gemini': self.gemini is not None and self.gemini.is_healthy(),
            'fusion': self.fusion is not None
        }
    
    def get_status(self) -> str:
        """Get formatted status string"""
        health = self.health_check()
        stats = self.get_usage_stats()
        
        status = []
        status.append(f"Groq: {'✓' if health['groq'] else '✗'} ({stats['groq']['calls']} calls)")
        status.append(f"Gemini: {'✓' if health['gemini'] else '✗'} ({stats['gemini']['calls']} calls)")
        status.append(f"Fusion: {'✓' if health['fusion'] else '✗'}")
        
        return " | ".join(status)


# =============================================================================
# STANDALONE TEST
# =============================================================================

if __name__ == "__main__":
    # Test API Manager
    api_keys = {
        'groq': 'test_key',
        'gemini': 'test_key'
    }
    
    manager = APIManager(api_keys)
    print(manager.get_status())

#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                         ⚡ GROQ ENGINE - PRIMARY BRAIN                        ║
║                                                                              ║
║  Sub-500ms reasoning | Terminal command generation | Real-time dialogue     ║
║  Model: Mixtral-8x7b-32768 | Optimized for speed and code generation        ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

import os
import time
import json
from typing import Dict, List, Optional, Any, Generator
from dataclasses import dataclass

try:
    import groq
    from groq import Groq
    GROQ_AVAILABLE = True
except ImportError:
    GROQ_AVAILABLE = False
    print("[WARNING] Groq package not installed")

from .api_manager import BrainRequest, BrainResponse, BrainType


# =============================================================================
# GROQ ENGINE
# =============================================================================

class GroqEngine:
    """
    ⚡ GROQ ENGINE - Primary Fast Brain
    
    Capabilities:
    - Sub-500ms response time
    - Code generation and debugging
    - Terminal command generation
    - Real-time dialogue
    - System command execution planning
    
    Model: mixtral-8x7b-32768 (32k context, fast inference)
    """
    
    # System prompts for different tasks
    SYSTEM_PROMPTS = {
        'default': """You are JARVIS, an advanced AI assistant. Be concise, helpful, and accurate.
Respond in a professional but friendly manner.""",
        
        'code': """You are an expert programmer. Write clean, efficient, well-documented code.
Include comments explaining key logic. Follow best practices and PEP8 for Python.""",
        
        'terminal': """You are a system administrator. Generate safe terminal commands.
Only provide commands that are non-destructive. Explain what each command does.""",
        
        'debug': """You are a debugging expert. Analyze code errors and provide solutions.
Explain the root cause and suggest fixes with code examples.""",
        
        'planning': """You are a task planner. Break down complex tasks into actionable steps.
Provide clear, sequential instructions."""
    }
    
    def __init__(self, api_key: str, model: str = "mixtral-8x7b-32768"):
        """Initialize Groq Engine"""
        if not GROQ_AVAILABLE:
            raise RuntimeError("Groq package not installed. Run: pip install groq")
        
        self.api_key = api_key
        self.model = model
        self.client = None
        
        # Performance tracking
        self.total_calls = 0
        self.total_tokens = 0
        self.avg_latency_ms = 0
        self.last_error = None
        
        # Rate limiting
        self.last_call_time = 0
        self.min_interval = 0.1  # 100ms between calls
        
        self._init_client()
    
    def _init_client(self):
        """Initialize Groq client"""
        try:
            self.client = Groq(api_key=self.api_key)
            print(f"[Groq] Client initialized with model: {self.model}")
        except Exception as e:
            print(f"[Groq] Client init failed: {e}")
            self.last_error = str(e)
    
    def is_healthy(self) -> bool:
        """Check if Groq client is healthy"""
        return self.client is not None
    
    # ========================================================================
    # CORE PROCESSING
    # ========================================================================
    
    def process(self, request: BrainRequest) -> BrainResponse:
        """Process a request through Groq"""
        start_time = time.time()
        
        # Rate limiting
        self._rate_limit()
        
        try:
            # Select system prompt
            system_prompt = request.system_prompt or self._select_system_prompt(request.query)
            
            # Build messages
            messages = self._build_messages(request, system_prompt)
            
            # Make API call
            completion = self.client.chat.completions.create(
                model=self.model,
                messages=messages,
                temperature=request.temperature,
                max_tokens=request.max_tokens or 4096,
                top_p=0.9,
                stream=False
            )
            
            # Extract response
            content = completion.choices[0].message.content
            tokens_used = completion.usage.total_tokens if completion.usage else 0
            
            # Update stats
            latency = (time.time() - start_time) * 1000
            self._update_stats(latency, tokens_used)
            
            return BrainResponse(
                success=True,
                content=content,
                brain_used=BrainType.GROQ,
                latency_ms=latency,
                tokens_used=tokens_used,
                metadata={
                    'model': self.model,
                    'finish_reason': completion.choices[0].finish_reason
                }
            )
            
        except Exception as e:
            latency = (time.time() - start_time) * 1000
            self.last_error = str(e)
            print(f"[Groq] Error: {e}")
            
            return BrainResponse(
                success=False,
                content="",
                brain_used=BrainType.GROQ,
                latency_ms=latency,
                error=str(e)
            )
    
    def process_stream(self, request: BrainRequest) -> Generator[str, None, None]:
        """Process request with streaming response"""
        self._rate_limit()
        
        try:
            system_prompt = request.system_prompt or self._select_system_prompt(request.query)
            messages = self._build_messages(request, system_prompt)
            
            stream = self.client.chat.completions.create(
                model=self.model,
                messages=messages,
                temperature=request.temperature,
                max_tokens=request.max_tokens or 4096,
                stream=True
            )
            
            for chunk in stream:
                if chunk.choices[0].delta.content:
                    yield chunk.choices[0].delta.content
                    
        except Exception as e:
            print(f"[Groq Stream] Error: {e}")
            yield f"\n[Error: {e}]"
    
    def _build_messages(self, request: BrainRequest, system_prompt: str) -> List[Dict]:
        """Build message list for API"""
        messages = [
            {"role": "system", "content": system_prompt}
        ]
        
        # Add context if available
        if request.context:
            context_str = self._format_context(request.context)
            if context_str:
                messages.append({"role": "system", "content": f"Context: {context_str}"})
        
        # Add user query
        messages.append({"role": "user", "content": request.query})
        
        return messages
    
    def _format_context(self, context: Dict) -> str:
        """Format context dictionary for prompt"""
        parts = []
        for key, value in context.items():
            if isinstance(value, list):
                parts.append(f"{key}: {', '.join(str(v) for v in value)}")
            else:
                parts.append(f"{key}: {value}")
        return "; ".join(parts)
    
    def _select_system_prompt(self, query: str) -> str:
        """Select appropriate system prompt based on query"""
        query_lower = query.lower()
        
        if any(kw in query_lower for kw in ['code', 'write', 'function', 'script', 'program']):
            return self.SYSTEM_PROMPTS['code']
        elif any(kw in query_lower for kw in ['terminal', 'command', 'bash', 'cmd', 'powershell']):
            return self.SYSTEM_PROMPTS['terminal']
        elif any(kw in query_lower for kw in ['debug', 'error', 'fix', 'bug']):
            return self.SYSTEM_PROMPTS['debug']
        elif any(kw in query_lower for kw in ['plan', 'steps', 'how to', 'guide']):
            return self.SYSTEM_PROMPTS['planning']
        else:
            return self.SYSTEM_PROMPTS['default']
    
    def _rate_limit(self):
        """Apply rate limiting"""
        elapsed = time.time() - self.last_call_time
        if elapsed < self.min_interval:
            time.sleep(self.min_interval - elapsed)
        self.last_call_time = time.time()
    
    def _update_stats(self, latency_ms: float, tokens: int):
        """Update performance statistics"""
        self.total_calls += 1
        self.total_tokens += tokens
        
        # Running average
        self.avg_latency_ms = (
            (self.avg_latency_ms * (self.total_calls - 1) + latency_ms) / self.total_calls
        )
    
    # ========================================================================
    # SPECIALIZED METHODS
    # ========================================================================
    
    def generate_terminal_command(self, task_description: str, os_type: str = "windows") -> str:
        """Generate safe terminal command for task"""
        request = BrainRequest(
            query=f"Generate {os_type} terminal command to: {task_description}",
            system_prompt=self.SYSTEM_PROMPTS['terminal'],
            temperature=0.3,
            prefer_speed=True
        )
        response = self.process(request)
        return response.content if response.success else f"Error: {response.error}"
    
    def explain_code(self, code: str, language: str = "python") -> str:
        """Explain what code does"""
        request = BrainRequest(
            query=f"Explain this {language} code:\n\n```{language}\n{code}\n```",
            system_prompt="You are a code reviewer. Explain code clearly and concisely.",
            temperature=0.5
        )
        response = self.process(request)
        return response.content if response.success else f"Error: {response.error}"
    
    def refactor_code(self, code: str, improvements: List[str] = None) -> str:
        """Refactor code with improvements"""
        improvements_str = ", ".join(improvements) if improvements else "better readability and performance"
        request = BrainRequest(
            query=f"Refactor this code for {improvements_str}:\n\n```python\n{code}\n```",
            system_prompt=self.SYSTEM_PROMPTS['code'],
            temperature=0.4
        )
        response = self.process(request)
        return response.content if response.success else f"Error: {response.error}"
    
    def generate_python_script(self, description: str, include_error_handling: bool = True) -> str:
        """Generate complete Python script"""
        eh_note = " with proper error handling" if include_error_handling else ""
        request = BrainRequest(
            query=f"Write a complete Python script{eh_note}: {description}",
            system_prompt=self.SYSTEM_PROMPTS['code'],
            temperature=0.5,
            max_tokens=4096
        )
        response = self.process(request)
        return response.content if response.success else f"Error: {response.error}"
    
    def create_task_plan(self, goal: str, num_steps: int = 5) -> List[str]:
        """Create step-by-step task plan"""
        request = BrainRequest(
            query=f"Break down this goal into {num_steps} actionable steps: {goal}",
            system_prompt=self.SYSTEM_PROMPTS['planning'],
            temperature=0.4
        )
        response = self.process(request)
        
        if response.success:
            # Parse steps from response
            lines = response.content.strip().split('\n')
            steps = [line.strip('- 1234567890.') for line in lines if line.strip()]
            return steps
        return [f"Error: {response.error}"]
    
    # ========================================================================
    # STATS & INFO
    # ========================================================================
    
    def get_stats(self) -> Dict:
        """Get engine statistics"""
        return {
            'total_calls': self.total_calls,
            'total_tokens': self.total_tokens,
            'avg_latency_ms': round(self.avg_latency_ms, 2),
            'model': self.model,
            'healthy': self.is_healthy(),
            'last_error': self.last_error
        }
    
    def quick_chat(self, message: str) -> str:
        """Quick chat without full request object"""
        request = BrainRequest(query=message, prefer_speed=True)
        response = self.process(request)
        return response.content if response.success else f"Error: {response.error}"


# =============================================================================
# STANDALONE TEST
# =============================================================================

if __name__ == "__main__":
    # Test Groq Engine
    api_key = os.getenv('GROQ_API_KEY', 'test_key')
    
    try:
        engine = GroqEngine(api_key)
        
        # Test quick chat
        response = engine.quick_chat("What is Python?")
        print(f"Response: {response}")
        
        print(f"Stats: {engine.get_stats()}")
        
    except Exception as e:
        print(f"Test failed: {e}")

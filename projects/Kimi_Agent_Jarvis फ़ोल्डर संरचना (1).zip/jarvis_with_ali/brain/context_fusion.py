#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                    🔗 CONTEXT FUSION - MULTI-BRAIN SYNTHESIS                  ║
║                                                                              ║
║  Combines Groq (speed) and Gemini (depth) for optimal responses             ║
║  Adaptive fusion strategy based on query complexity                         ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

import time
import asyncio
from typing import Dict, List, Optional, Any, Callable
from dataclasses import dataclass
from concurrent.futures import ThreadPoolExecutor

from .api_manager import BrainRequest, BrainResponse, BrainType


# =============================================================================
# FUSION STRATEGIES
# =============================================================================

class FusionStrategy:
    """Available fusion strategies"""
    PARALLEL = "parallel"      # Query both, combine results
    ADAPTIVE = "adaptive"      # Choose based on query
    CASCADE = "cascade"        # Try Groq first, fallback to Gemini
    HYBRID = "hybrid"          # Groq for speed, Gemini for depth


@dataclass
class FusionResult:
    """Result from fusion processing"""
    content: str
    strategy_used: str
    groq_contribution: float
    gemini_contribution: float
    latency_ms: float
    metadata: Dict[str, Any]


# =============================================================================
# CONTEXT FUSION ENGINE
# =============================================================================

class ContextFusion:
    """
    🔗 CONTEXT FUSION - Multi-Brain Synthesis
    
    Strategies:
    1. PARALLEL: Query both brains simultaneously, synthesize responses
    2. ADAPTIVE: Analyze query, select best single brain or hybrid approach
    3. CASCADE: Try fast brain first, escalate if needed
    4. HYBRID: Use Groq for initial draft, Gemini for refinement
    
    The fusion engine intelligently combines the strengths of both
    AI systems to produce superior results.
    """
    
    def __init__(self, groq_engine: Any, gemini_engine: Any, default_strategy: str = FusionStrategy.ADAPTIVE):
        """Initialize Context Fusion"""
        self.groq = groq_engine
        self.gemini = gemini_engine
        self.default_strategy = default_strategy
        
        # Thread pool for parallel execution
        self.executor = ThreadPoolExecutor(max_workers=2)
        
        # Performance tracking
        self.fusion_stats = {
            'total_fusions': 0,
            'strategy_usage': {
                FusionStrategy.PARALLEL: 0,
                FusionStrategy.ADAPTIVE: 0,
                FusionStrategy.CASCADE: 0,
                FusionStrategy.HYBRID: 0
            },
            'avg_latency_ms': 0
        }
        
        print("[Fusion] Context Fusion initialized")
    
    # ========================================================================
    # MAIN PROCESSING
    # ========================================================================
    
    def process(self, request: BrainRequest) -> BrainResponse:
        """Process request using fusion strategy"""
        start_time = time.time()
        
        # Select strategy
        strategy = self._select_strategy(request)
        self.fusion_stats['strategy_usage'][strategy] += 1
        
        print(f"[Fusion] Using strategy: {strategy}")
        
        # Execute based on strategy
        if strategy == FusionStrategy.PARALLEL:
            result = self._parallel_fusion(request)
        elif strategy == FusionStrategy.CASCADE:
            result = self._cascade_fusion(request)
        elif strategy == FusionStrategy.HYBRID:
            result = self._hybrid_fusion(request)
        else:  # ADAPTIVE
            result = self._adaptive_fusion(request)
        
        # Update stats
        latency = (time.time() - start_time) * 1000
        self._update_stats(latency)
        
        return BrainResponse(
            success=True,
            content=result.content,
            brain_used=BrainType.FUSION,
            latency_ms=latency,
            metadata={
                'strategy': strategy,
                'groq_weight': result.groq_contribution,
                'gemini_weight': result.gemini_contribution,
                **result.metadata
            }
        )
    
    def _select_strategy(self, request: BrainRequest) -> str:
        """Select best fusion strategy for request"""
        query = request.query.lower()
        
        # Force strategy if specified
        if hasattr(request, 'fusion_strategy'):
            return request.fusion_strategy
        
        # High priority = parallel for best quality
        if request.priority.value <= 2:
            return FusionStrategy.PARALLEL
        
        # Code tasks = cascade (Groq usually sufficient)
        if any(kw in query for kw in ['code', 'script', 'function', 'debug']):
            return FusionStrategy.CASCADE
        
        # Complex analysis = hybrid (draft + refine)
        if any(kw in query for kw in ['analyze', 'report', 'document', 'strategy']):
            return FusionStrategy.HYBRID
        
        # Default to adaptive
        return FusionStrategy.ADAPTIVE
    
    # ========================================================================
    # FUSION STRATEGIES
    # ========================================================================
    
    def _parallel_fusion(self, request: BrainRequest) -> FusionResult:
        """Query both brains in parallel and synthesize"""
        start = time.time()
        
        # Submit both queries
        groq_future = self.executor.submit(self.groq.process, request)
        gemini_future = self.executor.submit(self.gemini.process, request)
        
        # Wait for both
        groq_response = groq_future.result()
        gemini_response = gemini_future.result()
        
        # Synthesize responses
        fused_content = self._synthesize_responses(
            groq_response.content if groq_response.success else "",
            gemini_response.content if gemini_response.success else "",
            request.query
        )
        
        # Calculate contributions
        groq_weight = 0.5 if groq_response.success else 0.0
        gemini_weight = 0.5 if gemini_response.success else 0.0
        
        # Normalize
        total = groq_weight + gemini_weight
        if total > 0:
            groq_weight /= total
            gemini_weight /= total
        
        return FusionResult(
            content=fused_content,
            strategy_used=FusionStrategy.PARALLEL,
            groq_contribution=groq_weight,
            gemini_contribution=gemini_weight,
            latency_ms=(time.time() - start) * 1000,
            metadata={
                'groq_latency': groq_response.latency_ms,
                'gemini_latency': gemini_response.latency_ms,
                'groq_success': groq_response.success,
                'gemini_success': gemini_response.success
            }
        )
    
    def _cascade_fusion(self, request: BrainRequest) -> FusionResult:
        """Try Groq first, escalate to Gemini if needed"""
        start = time.time()
        
        # Try Groq first
        groq_response = self.groq.process(request)
        
        # Check if Groq response is sufficient
        if groq_response.success and self._is_response_sufficient(groq_response.content):
            return FusionResult(
                content=groq_response.content,
                strategy_used=FusionStrategy.CASCADE,
                groq_contribution=1.0,
                gemini_contribution=0.0,
                latency_ms=(time.time() - start) * 1000,
                metadata={'escalated': False, 'groq_only': True}
            )
        
        # Escalate to Gemini
        print("[Fusion] Escalating to Gemini...")
        gemini_response = self.gemini.process(request)
        
        return FusionResult(
            content=gemini_response.content if gemini_response.success else groq_response.content,
            strategy_used=FusionStrategy.CASCADE,
            groq_contribution=0.3 if gemini_response.success else 1.0,
            gemini_contribution=0.7 if gemini_response.success else 0.0,
            latency_ms=(time.time() - start) * 1000,
            metadata={'escalated': True, 'groq_success': groq_response.success}
        )
    
    def _hybrid_fusion(self, request: BrainRequest) -> FusionResult:
        """Use Groq for draft, Gemini for refinement"""
        start = time.time()
        
        # Step 1: Get draft from Groq
        draft_request = BrainRequest(
            query=request.query,
            context=request.context,
            system_prompt="Provide a quick draft response. Be concise.",
            temperature=0.7
        )
        
        groq_response = self.groq.process(draft_request)
        
        if not groq_response.success:
            # Fallback to Gemini
            gemini_response = self.gemini.process(request)
            return FusionResult(
                content=gemini_response.content if gemini_response.success else "Error",
                strategy_used=FusionStrategy.HYBRID,
                groq_contribution=0.0,
                gemini_contribution=1.0,
                latency_ms=(time.time() - start) * 1000,
                metadata={'draft_failed': True}
            )
        
        # Step 2: Refine with Gemini
        refine_request = BrainRequest(
            query=f"""Refine and improve this draft response:

Draft:
{groq_response.content}

Original Query: {request.query}

Provide a polished, comprehensive response.""",
            system_prompt="You are an expert editor. Improve clarity, depth, and accuracy.",
            temperature=0.5,
            max_tokens=8192
        )
        
        gemini_response = self.gemini.process(refine_request)
        
        return FusionResult(
            content=gemini_response.content if gemini_response.success else groq_response.content,
            strategy_used=FusionStrategy.HYBRID,
            groq_contribution=0.3,
            gemini_contribution=0.7,
            latency_ms=(time.time() - start) * 1000,
            metadata={
                'draft_length': len(groq_response.content),
                'refined_length': len(gemini_response.content) if gemini_response.success else 0
            }
        )
    
    def _adaptive_fusion(self, request: BrainRequest) -> FusionResult:
        """Adaptively choose best approach based on query analysis"""
        query = request.query.lower()
        
        # Analyze complexity
        complexity_score = self._analyze_complexity(query)
        
        # Route based on complexity
        if complexity_score < 3:
            # Simple query - use Groq only
            groq_response = self.groq.process(request)
            return FusionResult(
                content=groq_response.content,
                strategy_used=FusionStrategy.ADAPTIVE,
                groq_contribution=1.0,
                gemini_contribution=0.0,
                latency_ms=groq_response.latency_ms,
                metadata={'complexity': complexity_score, 'approach': 'groq_only'}
            )
        elif complexity_score < 6:
            # Medium complexity - cascade
            return self._cascade_fusion(request)
        else:
            # High complexity - parallel
            return self._parallel_fusion(request)
    
    # ========================================================================
    # SYNTHESIS & ANALYSIS
    # ========================================================================
    
    def _synthesize_responses(self, groq_content: str, gemini_content: str, original_query: str) -> str:
        """Intelligently combine responses from both brains"""
        if not groq_content and not gemini_content:
            return "Both AI systems failed to respond."
        
        if not groq_content:
            return gemini_content
        
        if not gemini_content:
            return groq_content
        
        # Use Gemini to synthesize (it has larger context)
        synthesis_prompt = f"""Synthesize these two AI responses into the best possible answer:

Original Query: {original_query}

Response A (Fast, Concise):
{groq_content}

Response B (Detailed, Comprehensive):
{gemini_content}

Create a response that combines the speed and clarity of Response A with the depth of Response B."""
        
        synthesis_request = BrainRequest(
            query=synthesis_prompt,
            temperature=0.5,
            max_tokens=8192
        )
        
        try:
            response = self.gemini.process(synthesis_request)
            if response.success:
                return response.content
        except:
            pass
        
        # Fallback: concatenate with separator
        return f"{groq_content}\n\n--- Additional Insights ---\n\n{gemini_content}"
    
    def _is_response_sufficient(self, response: str) -> bool:
        """Check if response is sufficient (no need to escalate)"""
        # Check for uncertainty indicators
        uncertainty_phrases = [
            "i don't know", "i'm not sure", "i cannot", "i can't",
            "insufficient information", "need more context"
        ]
        
        response_lower = response.lower()
        
        # If response is too short, might be insufficient
        if len(response) < 50:
            return False
        
        # Check for uncertainty
        for phrase in uncertainty_phrases:
            if phrase in response_lower:
                return False
        
        return True
    
    def _analyze_complexity(self, query: str) -> int:
        """Analyze query complexity (0-10 scale)"""
        score = 0
        
        # Length factor
        if len(query) > 500:
            score += 2
        elif len(query) > 200:
            score += 1
        
        # Complexity keywords
        complex_keywords = [
            'analyze', 'evaluate', 'compare', 'contrast', 'synthesize',
            'strategic', 'comprehensive', 'detailed', 'in-depth',
            'financial', 'investment', 'portfolio', 'audit',
            'document', 'research', 'study', 'thesis'
        ]
        
        for kw in complex_keywords:
            if kw in query:
                score += 1
        
        # Multiple questions
        question_count = query.count('?')
        score += min(question_count, 2)
        
        return min(score, 10)
    
    def _update_stats(self, latency_ms: float):
        """Update fusion statistics"""
        self.fusion_stats['total_fusions'] += 1
        n = self.fusion_stats['total_fusions']
        self.fusion_stats['avg_latency_ms'] = (
            (self.fusion_stats['avg_latency_ms'] * (n - 1) + latency_ms) / n
        )
    
    # ========================================================================
    # UTILITY METHODS
    # ========================================================================
    
    def get_stats(self) -> Dict:
        """Get fusion statistics"""
        return self.fusion_stats.copy()
    
    def quick_fuse(self, query: str, strategy: str = FusionStrategy.ADAPTIVE) -> str:
        """Quick fusion without full request object"""
        request = BrainRequest(
            query=query,
            fusion_strategy=strategy
        )
        response = self.process(request)
        return response.content if response.success else f"Error: {response.error}"


# =============================================================================
# STANDALONE TEST
# =============================================================================

if __name__ == "__main__":
    # Mock engines for testing
    class MockGroq:
        def process(self, request):
            return BrainResponse(
                success=True,
                content="Groq quick response",
                brain_used=BrainType.GROQ,
                latency_ms=100
            )
    
    class MockGemini:
        def process(self, request):
            return BrainResponse(
                success=True,
                content="Gemini detailed response with more context and depth",
                brain_used=BrainType.GEMINI,
                latency_ms=500
            )
    
    fusion = ContextFusion(MockGroq(), MockGemini())
    
    # Test
    request = BrainRequest(query="Explain quantum computing")
    result = fusion.process(request)
    
    print(f"Fused response: {result.content}")
    print(f"Stats: {fusion.get_stats()}")

#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                      🔮 GEMINI ENGINE - HIGH-CONTEXT BRAIN                    ║
║                                                                              ║
║  Deep strategic planning | Video/Podcast analysis | Complex data auditing   ║
║  Model: Gemini Pro | 1M token context | Multimodal capabilities             ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

import os
import time
import json
from typing import Dict, List, Optional, Any, Union
from dataclasses import dataclass

try:
    import google.generativeai as genai
    from google.generativeai.types import HarmCategory, HarmBlockThreshold
    GEMINI_AVAILABLE = True
except ImportError:
    GEMINI_AVAILABLE = False
    print("[WARNING] Google Generative AI package not installed")

from .api_manager import BrainRequest, BrainResponse, BrainType


# =============================================================================
# GEMINI ENGINE
# =============================================================================

class GeminiEngine:
    """
    🔮 GEMINI ENGINE - High-Context Brain
    
    Capabilities:
    - 1 million token context window
    - Deep strategic planning
    - YouTube/Podcast link analysis (1hr+ content)
    - Complex financial data auditing
    - Multimodal understanding (text, images, video)
    - Document analysis and summarization
    
    Model: gemini-pro (text), gemini-pro-vision (multimodal)
    """
    
    # Safety settings
    SAFETY_SETTINGS = {
        HarmCategory.HARM_CATEGORY_HARASSMENT: HarmBlockThreshold.BLOCK_NONE,
        HarmCategory.HARM_CATEGORY_HATE_SPEECH: HarmBlockThreshold.BLOCK_NONE,
        HarmCategory.HARM_CATEGORY_SEXUALLY_EXPLICIT: HarmBlockThreshold.BLOCK_NONE,
        HarmCategory.HARM_CATEGORY_DANGEROUS_CONTENT: HarmBlockThreshold.BLOCK_NONE,
    }
    
    # System prompts for different tasks
    SYSTEM_PROMPTS = {
        'default': """You are JARVIS, an advanced AI assistant with deep analytical capabilities.
Provide thorough, well-reasoned responses.""",
        
        'analysis': """You are an expert analyst. Provide deep, comprehensive analysis.
Consider multiple perspectives and provide evidence-based conclusions.""",
        
        'video': """You are a video content analyst. Extract key insights, timestamps, and themes.
Identify viral moments and content opportunities.""",
        
        'financial': """You are a financial analyst. Analyze data carefully and provide actionable insights.
Include risk assessments and recommendations.""",
        
        'strategic': """You are a strategic planning expert. Think long-term and consider all variables.
Provide actionable strategic recommendations.""",
        
        'creative': """You are a creative consultant. Think outside the box and provide innovative ideas.
Balance creativity with practicality."""
    }
    
    def __init__(self, api_key: str, model: str = "gemini-pro"):
        """Initialize Gemini Engine"""
        if not GEMINI_AVAILABLE:
            raise RuntimeError("Google Generative AI not installed. Run: pip install google-generativeai")
        
        self.api_key = api_key
        self.model_name = model
        self.model = None
        self.vision_model = None
        
        # Performance tracking
        self.total_calls = 0
        self.total_tokens = 0
        self.avg_latency_ms = 0
        self.last_error = None
        
        # Generation config
        self.generation_config = {
            'temperature': 0.7,
            'top_p': 0.9,
            'top_k': 40,
            'max_output_tokens': 8192,
        }
        
        self._init_client()
    
    def _init_client(self):
        """Initialize Gemini client"""
        try:
            genai.configure(api_key=self.api_key)
            
            self.model = genai.GenerativeModel(
                model_name=self.model_name,
                generation_config=self.generation_config,
                safety_settings=self.SAFETY_SETTINGS
            )
            
            # Initialize vision model
            self.vision_model = genai.GenerativeModel(
                model_name='gemini-pro-vision',
                generation_config=self.generation_config,
                safety_settings=self.SAFETY_SETTINGS
            )
            
            print(f"[Gemini] Client initialized with model: {self.model_name}")
            
        except Exception as e:
            print(f"[Gemini] Client init failed: {e}")
            self.last_error = str(e)
    
    def is_healthy(self) -> bool:
        """Check if Gemini client is healthy"""
        return self.model is not None
    
    # ========================================================================
    # CORE PROCESSING
    # ========================================================================
    
    def process(self, request: BrainRequest) -> BrainResponse:
        """Process a request through Gemini"""
        start_time = time.time()
        
        try:
            # Select system prompt
            system_prompt = request.system_prompt or self._select_system_prompt(request.query)
            
            # Build content with context
            content = self._build_content(request, system_prompt)
            
            # Start chat for context management
            chat = self.model.start_chat(history=[])
            
            # Send message
            response = chat.send_message(
                content,
                generation_config={
                    'temperature': request.temperature,
                    'max_output_tokens': request.max_tokens or 8192
                }
            )
            
            # Extract response
            content_text = response.text
            
            # Estimate tokens (Gemini doesn't return exact counts)
            tokens_used = len(content.split()) + len(content_text.split())
            
            # Update stats
            latency = (time.time() - start_time) * 1000
            self._update_stats(latency, tokens_used)
            
            return BrainResponse(
                success=True,
                content=content_text,
                brain_used=BrainType.GEMINI,
                latency_ms=latency,
                tokens_used=tokens_used,
                metadata={
                    'model': self.model_name,
                    'finish_reason': 'stop'
                }
            )
            
        except Exception as e:
            latency = (time.time() - start_time) * 1000
            self.last_error = str(e)
            print(f"[Gemini] Error: {e}")
            
            return BrainResponse(
                success=False,
                content="",
                brain_used=BrainType.GEMINI,
                latency_ms=latency,
                error=str(e)
            )
    
    def process_with_history(self, request: BrainRequest, history: List[Dict]) -> BrainResponse:
        """Process with conversation history"""
        start_time = time.time()
        
        try:
            # Convert history to Gemini format
            gemini_history = []
            for msg in history:
                role = 'user' if msg.get('role') == 'user' else 'model'
                gemini_history.append({
                    'role': role,
                    'parts': [msg.get('content', '')]
                })
            
            # Start chat with history
            chat = self.model.start_chat(history=gemini_history)
            
            # Send new message
            response = chat.send_message(request.query)
            
            latency = (time.time() - start_time) * 1000
            self._update_stats(latency, len(response.text.split()))
            
            return BrainResponse(
                success=True,
                content=response.text,
                brain_used=BrainType.GEMINI,
                latency_ms=latency
            )
            
        except Exception as e:
            return BrainResponse(
                success=False,
                content="",
                brain_used=BrainType.GEMINI,
                latency_ms=(time.time() - start_time) * 1000,
                error=str(e)
            )
    
    def analyze_image(self, image_path: str, query: str = "Describe this image") -> BrainResponse:
        """Analyze an image with Gemini Vision"""
        start_time = time.time()
        
        try:
            from PIL import Image
            
            # Load image
            img = Image.open(image_path)
            
            # Generate response
            response = self.vision_model.generate_content([query, img])
            response.resolve()
            
            latency = (time.time() - start_time) * 1000
            
            return BrainResponse(
                success=True,
                content=response.text,
                brain_used=BrainType.GEMINI,
                latency_ms=latency,
                metadata={'model': 'gemini-pro-vision'}
            )
            
        except Exception as e:
            return BrainResponse(
                success=False,
                content="",
                brain_used=BrainType.GEMINI,
                latency_ms=(time.time() - start_time) * 1000,
                error=str(e)
            )
    
    def _build_content(self, request: BrainRequest, system_prompt: str) -> str:
        """Build content string for Gemini"""
        parts = [system_prompt]
        
        # Add context
        if request.context:
            context_str = self._format_context(request.context)
            if context_str:
                parts.append(f"\nContext:\n{context_str}")
        
        # Add main query
        parts.append(f"\nQuery:\n{request.query}")
        
        return "\n".join(parts)
    
    def _format_context(self, context: Dict) -> str:
        """Format context dictionary"""
        formatted = []
        for key, value in context.items():
            if key == 'documents' and isinstance(value, list):
                formatted.append(f"Documents ({len(value)} items):")
                for i, doc in enumerate(value[:5], 1):  # Limit to 5 docs
                    doc_preview = str(doc)[:500] + "..." if len(str(doc)) > 500 else str(doc)
                    formatted.append(f"  [{i}] {doc_preview}")
            elif key == 'transcript':
                transcript = str(value)[:100000]  # Limit transcript size
                formatted.append(f"Transcript:\n{transcript}")
            else:
                formatted.append(f"{key}: {value}")
        
        return "\n".join(formatted)
    
    def _select_system_prompt(self, query: str) -> str:
        """Select appropriate system prompt"""
        query_lower = query.lower()
        
        if any(kw in query_lower for kw in ['video', 'youtube', 'podcast', 'transcript', 'viral']):
            return self.SYSTEM_PROMPTS['video']
        elif any(kw in query_lower for kw in ['financial', 'investment', 'portfolio', 'market', 'fund']):
            return self.SYSTEM_PROMPTS['financial']
        elif any(kw in query_lower for kw in ['strategy', 'plan', 'long-term', 'business']):
            return self.SYSTEM_PROMPTS['strategic']
        elif any(kw in query_lower for kw in ['analyze', 'analysis', 'review', 'evaluate']):
            return self.SYSTEM_PROMPTS['analysis']
        elif any(kw in query_lower for kw in ['creative', 'idea', 'design', 'concept']):
            return self.SYSTEM_PROMPTS['creative']
        else:
            return self.SYSTEM_PROMPTS['default']
    
    def _update_stats(self, latency_ms: float, tokens: int):
        """Update performance statistics"""
        self.total_calls += 1
        self.total_tokens += tokens
        self.avg_latency_ms = (
            (self.avg_latency_ms * (self.total_calls - 1) + latency_ms) / self.total_calls
        )
    
    # ========================================================================
    # SPECIALIZED METHODS
    # ========================================================================
    
    def analyze_video_transcript(self, transcript: str, query: str = "Summarize key points") -> str:
        """Analyze video transcript for insights"""
        request = BrainRequest(
            query=f"{query}\n\nTranscript:\n{transcript[:80000]}",  # Limit size
            system_prompt=self.SYSTEM_PROMPTS['video'],
            temperature=0.5,
            max_tokens=4096
        )
        response = self.process(request)
        return response.content if response.success else f"Error: {response.error}"
    
    def identify_viral_moments(self, transcript: str, video_duration: int = 600) -> List[Dict]:
        """Identify viral moments in video content"""
        request = BrainRequest(
            query=f"""Analyze this video transcript and identify 3-5 potential viral moments.
For each moment, provide:
- Timestamp estimate (approximate)
- Why it could go viral
- Suggested clip duration
- Caption/hook suggestion

Transcript:\n{transcript[:50000]}""",
            system_prompt=self.SYSTEM_PROMPTS['video'],
            temperature=0.6
        )
        
        response = self.process(request)
        
        if response.success:
            # Parse viral moments from response
            moments = []
            lines = response.content.split('\n')
            current_moment = {}
            
            for line in lines:
                line = line.strip()
                if line.startswith('Moment') or line.startswith('**'):
                    if current_moment:
                        moments.append(current_moment)
                    current_moment = {'title': line.strip('*')}
                elif 'timestamp' in line.lower() or 'time' in line.lower():
                    current_moment['timestamp'] = line.split(':')[-1].strip()
                elif 'duration' in line.lower():
                    current_moment['duration'] = line.split(':')[-1].strip()
                elif 'caption' in line.lower() or 'hook' in line.lower():
                    current_moment['caption'] = line.split(':')[-1].strip()
            
            if current_moment:
                moments.append(current_moment)
            
            return moments
        
        return []
    
    def audit_financial_data(self, data: Dict, data_type: str = "portfolio") -> str:
        """Perform financial data audit"""
        request = BrainRequest(
            query=f"""Perform a comprehensive audit of this {data_type} data:

{json.dumps(data, indent=2)}

Provide:
1. Overall health assessment
2. Risk analysis
3. Performance insights
4. Recommendations for improvement
5. Red flags (if any)""",
            system_prompt=self.SYSTEM_PROMPTS['financial'],
            temperature=0.4,
            max_tokens=4096
        )
        response = self.process(request)
        return response.content if response.success else f"Error: {response.error}"
    
    def create_strategic_plan(self, goal: str, constraints: List[str] = None, timeframe: str = "1 year") -> str:
        """Create comprehensive strategic plan"""
        constraints_str = "\n".join(f"- {c}" for c in (constraints or []))
        
        request = BrainRequest(
            query=f"""Create a strategic plan for the following goal:

Goal: {goal}
Timeframe: {timeframe}
Constraints:
{constraints_str}

Include:
1. Executive summary
2. Key objectives and KPIs
3. Phase-by-phase implementation
4. Resource requirements
5. Risk mitigation strategies
6. Success metrics""",
            system_prompt=self.SYSTEM_PROMPTS['strategic'],
            temperature=0.5,
            max_tokens=8192
        )
        response = self.process(request)
        return response.content if response.success else f"Error: {response.error}"
    
    def summarize_long_document(self, document: str, summary_type: str = "detailed") -> str:
        """Summarize long documents"""
        prompt_map = {
            "brief": "Provide a brief 1-paragraph summary",
            "detailed": "Provide a comprehensive summary with key points",
            "bullet": "Summarize as bullet points",
            "executive": "Provide an executive summary for decision makers"
        }
        
        request = BrainRequest(
            query=f"{prompt_map.get(summary_type, prompt_map['detailed'])}:\n\n{document[:100000]}",
            temperature=0.4,
            max_tokens=4096
        )
        response = self.process(request)
        return response.content if response.success else f"Error: {response.error}"
    
    # ========================================================================
    # STATS & INFO
    # ========================================================================
    
    def get_stats(self) -> Dict:
        """Get engine statistics"""
        return {
            'total_calls': self.total_calls,
            'total_tokens': self.total_tokens,
            'avg_latency_ms': round(self.avg_latency_ms, 2),
            'model': self.model_name,
            'healthy': self.is_healthy(),
            'last_error': self.last_error
        }
    
    def quick_chat(self, message: str) -> str:
        """Quick chat without full request object"""
        request = BrainRequest(query=message, prefer_speed=False)
        response = self.process(request)
        return response.content if response.success else f"Error: {response.error}"


# =============================================================================
# STANDALONE TEST
# =============================================================================

if __name__ == "__main__":
    # Test Gemini Engine
    api_key = os.getenv('GEMINI_API_KEY', 'test_key')
    
    try:
        engine = GeminiEngine(api_key)
        
        # Test quick chat
        response = engine.quick_chat("Explain quantum computing in simple terms")
        print(f"Response: {response[:200]}...")
        
        print(f"Stats: {engine.get_stats()}")
        
    except Exception as e:
        print(f"Test failed: {e}")

#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                 📦 DEPENDENCY MANAGER - REQUIREMENTS UPDATER                  ║
║                                                                              ║
║  Auto-update dependencies                                                   ║
║  Check for newer versions | Update requirements.txt | Safe updates          ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

import os
import re
import subprocess
import json
from pathlib import Path
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
import requests


@dataclass
class PackageInfo:
    """Package information"""
    name: str
    current_version: str
    latest_version: str
    update_available: bool
    release_date: str = ""


class DependencyManager:
    """
    📦 DEPENDENCY MANAGER - Auto-updater
    
    Features:
    - Check for package updates
    - Update requirements.txt
    - Safe update with rollback
    - Batch updates
    """
    
    PYPI_API = "https://pypi.org/pypi/{package}/json"
    
    def __init__(self, requirements_file: str = "requirements.txt"):
        """Initialize Dependency Manager"""
        self.requirements_file = Path(requirements_file)
        
        # Stats
        self.checks_performed = 0
        self.updates_available = 0
        
        print("[DependencyManager] Initialized")
    
    def parse_requirements(self) -> Dict[str, str]:
        """Parse requirements.txt"""
        packages = {}
        
        if not self.requirements_file.exists():
            return packages
        
        with open(self.requirements_file, 'r') as f:
            for line in f:
                line = line.strip()
                
                # Skip comments and empty lines
                if not line or line.startswith('#'):
                    continue
                
                # Parse package name and version
                match = re.match(r'^([a-zA-Z0-9_-]+)([<>=!~]+)?(.+)?$', line)
                if match:
                    name = match.group(1)
                    version = match.group(3) or ""
                    packages[name] = version
        
        return packages
    
    def check_package_version(self, package: str) -> Optional[PackageInfo]:
        """Check latest version of package on PyPI"""
        try:
            url = self.PYPI_API.format(package=package)
            response = requests.get(url, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                latest = data['info']['version']
                
                return PackageInfo(
                    name=package,
                    current_version="unknown",
                    latest_version=latest,
                    update_available=False
                )
        except Exception as e:
            print(f"[DependencyManager] Check error for {package}: {e}")
        
        return None
    
    def check_all_updates(self) -> List[PackageInfo]:
        """Check all packages for updates"""
        packages = self.parse_requirements()
        updates = []
        
        print(f"[DependencyManager] Checking {len(packages)} packages...")
        
        for name, current_ver in packages.items():
            info = self.check_package_version(name)
            
            if info:
                info.current_version = current_ver
                info.update_available = info.latest_version != current_ver
                
                if info.update_available:
                    updates.append(info)
                    self.updates_available += 1
            
            self.checks_performed += 1
        
        return updates
    
    def update_requirements(self, package_updates: Dict[str, str]) -> bool:
        """Update requirements.txt with new versions"""
        try:
            with open(self.requirements_file, 'r') as f:
                content = f.read()
            
            for name, new_version in package_updates.items():
                # Replace version in requirements
                pattern = rf'^{re.escape(name)}[<>=!~]+.+$'
                replacement = f'{name}>={new_version}'
                content = re.sub(pattern, replacement, content, flags=re.MULTILINE)
            
            with open(self.requirements_file, 'w') as f:
                f.write(content)
            
            print(f"[DependencyManager] Updated {len(package_updates)} packages")
            return True
            
        except Exception as e:
            print(f"[DependencyManager] Update error: {e}")
            return False
    
    def get_stats(self) -> Dict:
        """Get manager statistics"""
        return {
            'checks_performed': self.checks_performed,
            'updates_available': self.updates_available,
            'requirements_file': str(self.requirements_file)
        }

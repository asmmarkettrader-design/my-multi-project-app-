"""
JARVIS EVOLUTION - Self-Upgrade & Module Generation
"""
from .self_upgrade import SelfUpgrade
from .module_generator import ModuleGenerator
from .dependency_manager import DependencyManager
from .version_checker import VersionChecker

__all__ = ['SelfUpgrade', 'ModuleGenerator', 'DependencyManager', 'VersionChecker']

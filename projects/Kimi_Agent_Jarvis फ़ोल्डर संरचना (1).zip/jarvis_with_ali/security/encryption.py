#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                      🔐 SECURITY MANAGER - ENCRYPTION                         ║
║                                                                              ║
║  Data encryption and secure storage                                         ║
║  API key management | File encryption | Secure memory                       ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

import os
import base64
import hashlib
import json
from pathlib import Path
from typing import Dict, Optional, Any
from dataclasses import dataclass

try:
    from cryptography.fernet import Fernet
    from cryptography.hazmat.primitives import hashes
    from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
    CRYPTO_AVAILABLE = True
except ImportError:
    CRYPTO_AVAILABLE = False
    print("[WARNING] cryptography not installed")


@dataclass
class EncryptedData:
    """Encrypted data container"""
    ciphertext: bytes
    salt: bytes
    nonce: Optional[bytes] = None


class SecurityManager:
    """
    🔐 SECURITY MANAGER - Encryption & Secure Storage
    
    Features:
    - Password-based encryption
    - API key secure storage
    - File encryption/decryption
    - Secure memory handling
    """
    
    def __init__(self, master_key: str = None):
        """Initialize Security Manager"""
        self.master_key = master_key or os.getenv('JARVIS_MASTER_KEY', 'default_key_change_me')
        self.cipher = None
        
        if CRYPTO_AVAILABLE:
            self._init_cipher()
        
        # Key storage
        self.key_file = Path("./data/secure/keys.enc")
        self.key_file.parent.mkdir(parents=True, exist_ok=True)
        
        print("[Security] Initialized")
    
    def _init_cipher(self):
        """Initialize encryption cipher"""
        try:
            kdf = PBKDF2HMAC(
                algorithm=hashes.SHA256(),
                length=32,
                salt=b'jarvis_salt_v1',  # In production, use random salt
                iterations=100000,
            )
            key = base64.urlsafe_b64encode(kdf.derive(self.master_key.encode()))
            self.cipher = Fernet(key)
        except Exception as e:
            print(f"[Security] Cipher init error: {e}")
    
    def encrypt(self, data: str) -> Optional[bytes]:
        """Encrypt string data"""
        if not CRYPTO_AVAILABLE or not self.cipher:
            # Fallback: base64 encode
            return base64.b64encode(data.encode())
        
        try:
            return self.cipher.encrypt(data.encode())
        except Exception as e:
            print(f"[Security] Encrypt error: {e}")
            return None
    
    def decrypt(self, ciphertext: bytes) -> Optional[str]:
        """Decrypt data to string"""
        if not CRYPTO_AVAILABLE or not self.cipher:
            # Fallback: base64 decode
            try:
                return base64.b64decode(ciphertext).decode()
            except:
                return None
        
        try:
            return self.cipher.decrypt(ciphertext).decode()
        except Exception as e:
            print(f"[Security] Decrypt error: {e}")
            return None
    
    def hash_string(self, data: str) -> str:
        """Create SHA-256 hash"""
        return hashlib.sha256(data.encode()).hexdigest()
    
    def secure_delete(self, data: bytearray):
        """Securely delete data from memory"""
        for i in range(len(data)):
            data[i] = 0

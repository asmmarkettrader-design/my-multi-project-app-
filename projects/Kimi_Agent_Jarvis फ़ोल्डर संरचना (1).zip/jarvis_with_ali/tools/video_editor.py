#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                      🎬 VIDEO EDITOR - FFMPEG AUTOMATION                      ║
║                                                                              ║
║  Autonomous video processing pipeline                                       ║
║  YouTube download → Viral detection → 9:16 crop → AI captions             ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

import os
import re
import json
import subprocess
import tempfile
import shutil
from pathlib import Path
from typing import List, Dict, Optional, Any, Tuple, Callable
from dataclasses import dataclass, field
from datetime import datetime
import time
import threading
import queue

try:
    import ffmpeg
    FFMPEG_PYTHON_AVAILABLE = True
except ImportError:
    FFMPEG_PYTHON_AVAILABLE = False

try:
    from yt_dlp import YoutubeDL
    YTDLP_AVAILABLE = True
except ImportError:
    YTDLP_AVAILABLE = False
    print("[WARNING] yt-dlp not installed")


# =============================================================================
# DATA CLASSES
# =============================================================================

@dataclass
class VideoSegment:
    """Video segment for processing"""
    start_time: float
    end_time: float
    duration: float
    label: str = ""
    confidence: float = 0.0
    viral_score: float = 0.0

@dataclass
class ProcessingJob:
    """Video processing job"""
    job_id: str
    source_url: str
    status: str = "pending"  # pending, downloading, analyzing, processing, complete, error
    progress: float = 0.0
    output_path: str = ""
    segments: List[VideoSegment] = field(default_factory=list)
    error_message: str = ""
    created_at: float = field(default_factory=time.time)
    completed_at: Optional[float] = None


# =============================================================================
# VIDEO EDITOR
# =============================================================================

class VideoEditor:
    """
    🎬 VIDEO EDITOR - FFmpeg Automation Engine
    
    Complete video processing pipeline:
    1. Download from YouTube (yt-dlp)
    2. Analyze for viral moments (Gemini)
    3. Crop to 9:16 portrait (FFmpeg)
    4. Generate AI captions (Whisper/Gemini)
    5. Export for upload
    
    Optimized for short-form content (TikTok, Reels, Shorts).
    """
    
    # Resolution presets
    RESOLUTIONS = {
        'tiktok': (1080, 1920),      # 9:16
        'instagram_reel': (1080, 1920),
        'youtube_short': (1080, 1920),
        'square': (1080, 1080),       # 1:1
        'landscape': (1920, 1080),    # 16:9
    }
    
    def __init__(
        self,
        output_dir: str = "./data/downloads/videos",
        temp_dir: str = "./data/temp",
        ffmpeg_path: str = "ffmpeg",
        ffprobe_path: str = "ffprobe"
    ):
        """Initialize Video Editor"""
        self.output_dir = Path(output_dir)
        self.temp_dir = Path(temp_dir)
        self.ffmpeg_path = ffmpeg_path
        self.ffprobe_path = ffprobe_path
        
        # Create directories
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.temp_dir.mkdir(parents=True, exist_ok=True)
        
        # Job tracking
        self.jobs: Dict[str, ProcessingJob] = {}
        self.job_queue = queue.Queue()
        self.processing_thread: Optional[threading.Thread] = None
        self.running = False
        
        # Callbacks
        self.progress_callbacks: List[Callable] = []
        
        # Stats
        self.total_processed = 0
        self.total_errors = 0
        
        print(f"[VideoEditor] Initialized (output: {self.output_dir})")
    
    # ========================================================================
    # JOB MANAGEMENT
    # ========================================================================
    
    def create_job(self, source_url: str) -> str:
        """Create new processing job"""
        job_id = f"vid_{int(time.time() * 1000)}"
        
        job = ProcessingJob(
            job_id=job_id,
            source_url=source_url
        )
        
        self.jobs[job_id] = job
        self.job_queue.put(job_id)
        
        print(f"[VideoEditor] Job created: {job_id}")
        
        # Start processing thread if not running
        if not self.running:
            self.start_processor()
        
        return job_id
    
    def start_processor(self):
        """Start background processing thread"""
        self.running = True
        self.processing_thread = threading.Thread(target=self._process_queue, daemon=True)
        self.processing_thread.start()
        print("[VideoEditor] Processor started")
    
    def stop_processor(self):
        """Stop background processing"""
        self.running = False
        if self.processing_thread:
            self.processing_thread.join(timeout=5)
        print("[VideoEditor] Processor stopped")
    
    def _process_queue(self):
        """Process jobs from queue"""
        while self.running:
            try:
                job_id = self.job_queue.get(timeout=1)
                job = self.jobs.get(job_id)
                
                if job:
                    self._process_job(job)
                
            except queue.Empty:
                continue
            except Exception as e:
                print(f"[VideoEditor] Queue error: {e}")
    
    def _process_job(self, job: ProcessingJob):
        """Process a single job"""
        try:
            # Step 1: Download
            self._update_job(job, "downloading", 0.1)
            video_path = self._download_video(job.source_url, job.job_id)
            
            if not video_path:
                raise Exception("Download failed")
            
            # Step 2: Analyze for viral moments
            self._update_job(job, "analyzing", 0.3)
            segments = self._analyze_viral_moments(video_path)
            job.segments = segments
            
            # Step 3: Process segments
            self._update_job(job, "processing", 0.5)
            output_files = []
            
            for i, segment in enumerate(segments[:5]):  # Max 5 segments
                progress = 0.5 + (i / len(segments)) * 0.4
                self._update_job(job, "processing", progress)
                
                output_path = self._process_segment(video_path, segment, job.job_id, i)
                if output_path:
                    output_files.append(output_path)
            
            # Complete
            job.output_path = output_files[0] if output_files else ""
            self._update_job(job, "complete", 1.0)
            self.total_processed += 1
            
            # Cleanup temp
            self._cleanup_temp(job.job_id)
            
        except Exception as e:
            job.error_message = str(e)
            self._update_job(job, "error", 0)
            self.total_errors += 1
            print(f"[VideoEditor] Job {job.job_id} failed: {e}")
    
    def _update_job(self, job: ProcessingJob, status: str, progress: float):
        """Update job status and notify"""
        job.status = status
        job.progress = progress
        
        for callback in self.progress_callbacks:
            try:
                callback(job)
            except:
                pass
        
        print(f"[VideoEditor] Job {job.job_id}: {status} ({progress*100:.0f}%)")
    
    # ========================================================================
    # DOWNLOAD
    # ========================================================================
    
    def _download_video(self, url: str, job_id: str) -> Optional[str]:
        """Download video from URL"""
        if not YTDLP_AVAILABLE:
            raise RuntimeError("yt-dlp not installed")
        
        output_path = self.temp_dir / f"{job_id}_original"
        
        ydl_opts = {
            'format': 'best[height<=1080]',
            'outtmpl': str(output_path) + '.%(ext)s',
            'quiet': True,
            'no_warnings': True,
        }
        
        try:
            with YoutubeDL(ydl_opts) as ydl:
                info = ydl.extract_info(url, download=True)
                downloaded_path = ydl.prepare_filename(info)
                return downloaded_path
        except Exception as e:
            print(f"[VideoEditor] Download error: {e}")
            return None
    
    # ========================================================================
    # VIRAL ANALYSIS
    # ========================================================================
    
    def _analyze_viral_moments(self, video_path: str) -> List[VideoSegment]:
        """Analyze video for viral moments"""
        # Get video info
        info = self._get_video_info(video_path)
        duration = info.get('duration', 0)
        
        # For now, create segments at regular intervals
        # In production, this would use Gemini to analyze audio/transcript
        segments = []
        
        segment_duration = 30  # 30 second clips
        num_segments = min(int(duration / segment_duration), 5)
        
        for i in range(num_segments):
            start = i * segment_duration
            end = min(start + segment_duration, duration)
            
            segment = VideoSegment(
                start_time=start,
                end_time=end,
                duration=end - start,
                label=f"Segment {i+1}",
                confidence=0.8,
                viral_score=0.7 + (0.1 * (num_segments - i))  # Higher score for earlier segments
            )
            segments.append(segment)
        
        return segments
    
    def _get_video_info(self, video_path: str) -> Dict:
        """Get video metadata using ffprobe"""
        try:
            cmd = [
                self.ffprobe_path,
                '-v', 'error',
                '-show_entries', 'format=duration',
                '-show_entries', 'stream=width,height',
                '-of', 'json',
                video_path
            ]
            
            result = subprocess.run(cmd, capture_output=True, text=True)
            data = json.loads(result.stdout)
            
            info = {
                'duration': float(data.get('format', {}).get('duration', 0)),
                'width': 0,
                'height': 0
            }
            
            for stream in data.get('streams', []):
                if stream.get('width'):
                    info['width'] = stream['width']
                    info['height'] = stream['height']
                    break
            
            return info
            
        except Exception as e:
            print(f"[VideoEditor] FFprobe error: {e}")
            return {'duration': 0, 'width': 0, 'height': 0}
    
    # ========================================================================
    # VIDEO PROCESSING
    # ========================================================================
    
    def _process_segment(
        self,
        video_path: str,
        segment: VideoSegment,
        job_id: str,
        segment_index: int
    ) -> Optional[str]:
        """Process a single video segment"""
        try:
            # Generate output filename
            output_filename = f"{job_id}_segment_{segment_index + 1}.mp4"
            output_path = self.output_dir / output_filename
            
            # Step 1: Extract segment
            temp_segment = self._extract_segment(video_path, segment, job_id, segment_index)
            
            # Step 2: Crop to 9:16
            cropped = self._crop_to_portrait(temp_segment, job_id, segment_index)
            
            # Step 3: Add captions (placeholder)
            final = self._add_captions(cropped, job_id, segment_index)
            
            # Move to output
            shutil.move(final, output_path)
            
            return str(output_path)
            
        except Exception as e:
            print(f"[VideoEditor] Segment processing error: {e}")
            return None
    
    def _extract_segment(
        self,
        video_path: str,
        segment: VideoSegment,
        job_id: str,
        segment_index: int
    ) -> str:
        """Extract segment from video"""
        output_path = self.temp_dir / f"{job_id}_seg{segment_index}_extracted.mp4"
        
        cmd = [
            self.ffmpeg_path,
            '-i', video_path,
            '-ss', str(segment.start_time),
            '-t', str(segment.duration),
            '-c', 'copy',
            '-y',
            str(output_path)
        ]
        
        subprocess.run(cmd, capture_output=True)
        return str(output_path)
    
    def _crop_to_portrait(self, video_path: str, job_id: str, segment_index: int) -> str:
        """Crop video to 9:16 portrait"""
        output_path = self.temp_dir / f"{job_id}_seg{segment_index}_cropped.mp4"
        
        # Get video dimensions
        info = self._get_video_info(video_path)
        width = info.get('width', 1920)
        height = info.get('height', 1080)
        
        # Calculate crop for 9:16 (centered)
        target_ratio = 9 / 16
        current_ratio = width / height
        
        if current_ratio > target_ratio:
            # Too wide, crop width
            new_width = int(height * target_ratio)
            x_offset = (width - new_width) // 2
            crop_filter = f"crop={new_width}:{height}:{x_offset}:0"
        else:
            # Too tall, crop height
            new_height = int(width / target_ratio)
            y_offset = (height - new_height) // 2
            crop_filter = f"crop={width}:{new_height}:0:{y_offset}"
        
        # Scale to target resolution
        target_w, target_h = self.RESOLUTIONS['tiktok']
        
        cmd = [
            self.ffmpeg_path,
            '-i', video_path,
            '-vf', f"{crop_filter},scale={target_w}:{target_h}:force_original_aspect_ratio=decrease,pad={target_w}:{target_h}:(ow-iw)/2:(oh-ih)/2",
            '-c:v', 'libx264',
            '-preset', 'fast',
            '-crf', '23',
            '-c:a', 'aac',
            '-b:a', '128k',
            '-y',
            str(output_path)
        ]
        
        result = subprocess.run(cmd, capture_output=True, text=True)
        
        if result.returncode != 0:
            print(f"[VideoEditor] FFmpeg error: {result.stderr}")
        
        return str(output_path)
    
    def _add_captions(self, video_path: str, job_id: str, segment_index: int) -> str:
        """Add AI-generated captions to video"""
        # Placeholder - would use Whisper for transcription
        # and then overlay text with FFmpeg
        output_path = self.temp_dir / f"{job_id}_seg{segment_index}_final.mp4"
        
        # For now, just copy
        shutil.copy(video_path, output_path)
        
        return str(output_path)
    
    # ========================================================================
    # CAPTION GENERATION
    # ========================================================================
    
    def generate_captions(self, video_path: str, style: str = "modern") -> List[Dict]:
        """Generate captions from video audio"""
        # Extract audio
        audio_path = self._extract_audio(video_path)
        
        # Transcribe with Whisper (placeholder)
        # Would use OpenAI Whisper API or local model
        
        captions = [
            {'start': 0, 'end': 3, 'text': 'Sample caption 1'},
            {'start': 3, 'end': 6, 'text': 'Sample caption 2'},
        ]
        
        return captions
    
    def _extract_audio(self, video_path: str) -> str:
        """Extract audio from video"""
        output_path = self.temp_dir / f"{Path(video_path).stem}.wav"
        
        cmd = [
            self.ffmpeg_path,
            '-i', video_path,
            '-vn',
            '-acodec', 'pcm_s16le',
            '-ar', '16000',
            '-ac', '1',
            '-y',
            str(output_path)
        ]
        
        subprocess.run(cmd, capture_output=True)
        return str(output_path)
    
    # ========================================================================
    # CLEANUP
    # ========================================================================
    
    def _cleanup_temp(self, job_id: str):
        """Clean up temporary files for job"""
        try:
            for file in self.temp_dir.glob(f"{job_id}_*"):
                file.unlink()
        except Exception as e:
            print(f"[VideoEditor] Cleanup error: {e}")
    
    # ========================================================================
    # PUBLIC API
    # ========================================================================
    
    def process_youtube_video(self, url: str, callback: Callable = None) -> str:
        """Process YouTube video (main entry point)"""
        if callback:
            self.progress_callbacks.append(callback)
        
        job_id = self.create_job(url)
        return job_id
    
    def get_job_status(self, job_id: str) -> Optional[ProcessingJob]:
        """Get job status"""
        return self.jobs.get(job_id)
    
    def get_stats(self) -> Dict:
        """Get editor statistics"""
        return {
            'total_processed': self.total_processed,
            'total_errors': self.total_errors,
            'pending_jobs': self.job_queue.qsize(),
            'output_dir': str(self.output_dir)
        }
    
    def crop_video(
        self,
        input_path: str,
        output_path: str,
        resolution: str = "tiktok",
        start_time: float = 0,
        duration: float = None
    ) -> bool:
        """Crop video to specified resolution"""
        try:
            target_w, target_h = self.RESOLUTIONS.get(resolution, (1080, 1920))
            
            cmd = [self.ffmpeg_path, '-i', input_path]
            
            if start_time > 0:
                cmd.extend(['-ss', str(start_time)])
            
            if duration:
                cmd.extend(['-t', str(duration)])
            
            cmd.extend([
                '-vf', f"scale={target_w}:{target_h}:force_original_aspect_ratio=decrease,pad={target_w}:{target_h}:(ow-iw)/2:(oh-ih)/2",
                '-c:v', 'libx264',
                '-preset', 'fast',
                '-crf', '23',
                '-c:a', 'aac',
                '-b:a', '128k',
                '-y',
                output_path
            ])
            
            result = subprocess.run(cmd, capture_output=True)
            return result.returncode == 0
            
        except Exception as e:
            print(f"[VideoEditor] Crop error: {e}")
            return False


# =============================================================================
# STANDALONE TEST
# =============================================================================

if __name__ == "__main__":
    # Test Video Editor
    editor = VideoEditor()
    
    print(f"Stats: {editor.get_stats()}")
    
    # Test with sample (would need actual video)
    # job_id = editor.process_youtube_video("https://youtube.com/watch?v=...")
    # print(f"Created job: {job_id}")

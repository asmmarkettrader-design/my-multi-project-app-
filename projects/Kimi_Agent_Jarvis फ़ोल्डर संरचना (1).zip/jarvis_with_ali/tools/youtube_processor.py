#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                      📺 YOUTUBE PROCESSOR - VIDEO DOWNLOADER                  ║
║                                                                              ║
║  Download and process YouTube videos                                        ║
║  Extract transcripts | Get video info | Batch processing                    ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

import os
import re
import json
from pathlib import Path
from typing import Dict, List, Optional, Any
from dataclasses import dataclass

try:
    from yt_dlp import YoutubeDL
    YTDLP_AVAILABLE = True
except ImportError:
    YTDLP_AVAILABLE = False


@dataclass
class VideoInfo:
    """YouTube video information"""
    title: str
    duration: int
    view_count: int
    uploader: str
    upload_date: str
    description: str
    thumbnail: str
    formats: List[Dict]


class YouTubeProcessor:
    """
    📺 YOUTUBE PROCESSOR - Video Downloader
    
    Features:
    - Download videos in various qualities
    - Extract audio
    - Get video metadata
    - Download transcripts
    - Batch processing
    """
    
    def __init__(
        self,
        output_dir: str = "./data/downloads/youtube",
        temp_dir: str = "./data/temp"
    ):
        """Initialize YouTube Processor"""
        self.output_dir = Path(output_dir)
        self.temp_dir = Path(temp_dir)
        
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.temp_dir.mkdir(parents=True, exist_ok=True)
        
        # Stats
        self.downloads_completed = 0
        self.downloads_failed = 0
        
        print("[YouTubeProcessor] Initialized")
    
    def get_video_info(self, url: str) -> Optional[VideoInfo]:
        """Get video information without downloading"""
        if not YTDLP_AVAILABLE:
            return None
        
        ydl_opts = {
            'quiet': True,
            'no_warnings': True,
        }
        
        try:
            with YoutubeDL(ydl_opts) as ydl:
                info = ydl.extract_info(url, download=False)
                
                return VideoInfo(
                    title=info.get('title', 'Unknown'),
                    duration=info.get('duration', 0),
                    view_count=info.get('view_count', 0),
                    uploader=info.get('uploader', 'Unknown'),
                    upload_date=info.get('upload_date', ''),
                    description=info.get('description', ''),
                    thumbnail=info.get('thumbnail', ''),
                    formats=info.get('formats', [])
                )
        except Exception as e:
            print(f"[YouTubeProcessor] Info error: {e}")
            return None
    
    def download_video(
        self,
        url: str,
        quality: str = "best",
        output_name: str = None
    ) -> Optional[str]:
        """Download video from URL"""
        if not YTDLP_AVAILABLE:
            return None
        
        output_template = str(self.output_dir / (output_name or "%(title)s"))
        
        ydl_opts = {
            'format': quality,
            'outtmpl': output_template + '.%(ext)s',
            'quiet': True,
            'no_warnings': True,
        }
        
        try:
            with YoutubeDL(ydl_opts) as ydl:
                info = ydl.extract_info(url, download=True)
                downloaded_path = ydl.prepare_filename(info)
                
                self.downloads_completed += 1
                print(f"[YouTubeProcessor] Downloaded: {downloaded_path}")
                return downloaded_path
                
        except Exception as e:
            self.downloads_failed += 1
            print(f"[YouTubeProcessor] Download error: {e}")
            return None
    
    def download_audio(self, url: str, output_name: str = None) -> Optional[str]:
        """Download audio only"""
        if not YTDLP_AVAILABLE:
            return None
        
        output_template = str(self.output_dir / (output_name or "%(title)s"))
        
        ydl_opts = {
            'format': 'bestaudio/best',
            'outtmpl': output_template + '.%(ext)s',
            'postprocessors': [{
                'key': 'FFmpegExtractAudio',
                'preferredcodec': 'mp3',
                'preferredquality': '192',
            }],
            'quiet': True,
        }
        
        try:
            with YoutubeDL(ydl_opts) as ydl:
                info = ydl.extract_info(url, download=True)
                downloaded_path = ydl.prepare_filename(info).rsplit('.', 1)[0] + '.mp3'
                
                self.downloads_completed += 1
                return downloaded_path
                
        except Exception as e:
            self.downloads_failed += 1
            print(f"[YouTubeProcessor] Audio download error: {e}")
            return None
    
    def get_transcript(self, url: str) -> Optional[str]:
        """Get video transcript if available"""
        # This would use youtube-transcript-api in production
        # For now, return placeholder
        return "Transcript extraction would use youtube-transcript-api"

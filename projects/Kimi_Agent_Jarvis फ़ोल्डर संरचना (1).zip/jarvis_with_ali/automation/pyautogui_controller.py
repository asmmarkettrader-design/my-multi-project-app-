#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                    🎮 PYAUTOGUI CONTROLLER - GUI AUTOMATION                   ║
║                                                                              ║
║  Mouse and keyboard control                                                 ║
║  Safe automation with fail-safes                                            ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

import time
import threading
from typing import Tuple, List, Optional, Callable, Dict, Any
from dataclasses import dataclass
from enum import Enum

try:
    import pyautogui
    PYAUTOGUI_AVAILABLE = True
except ImportError:
    PYAUTOGUI_AVAILABLE = False
    print("[WARNING] PyAutoGUI not installed")

try:
    import pygetwindow as gw
    PYGETWINDOW_AVAILABLE = True
except ImportError:
    PYGETWINDOW_AVAILABLE = False


# =============================================================================
# DATA CLASSES
# =============================================================================

class MouseButton(Enum):
    LEFT = "left"
    RIGHT = "right"
    MIDDLE = "middle"

@dataclass
class Point:
    """2D point"""
    x: int
    y: int

@dataclass
class Action:
    """Automation action"""
    action_type: str
    params: Dict[str, Any]
    timestamp: float


# =============================================================================
# PYAUTOGUI CONTROLLER
# =============================================================================

class PyAutoGUIController:
    """
    🎮 PYAUTOGUI CONTROLLER - GUI Automation
    
    Safe mouse and keyboard control with:
    - Fail-safe mechanisms
    - Action recording and playback
    - Smooth mouse movements
    - Window management
    """
    
    def __init__(
        self,
        fail_safe: bool = True,
        pause: float = 0.1,
        move_duration: float = 0.25
    ):
        """Initialize PyAutoGUI Controller"""
        if not PYAUTOGUI_AVAILABLE:
            raise RuntimeError("PyAutoGUI not installed")
        
        # Configure pyautogui
        pyautogui.FAILSAFE = fail_safe
        pyautogui.PAUSE = pause
        
        self.move_duration = move_duration
        
        # Screen dimensions
        self.screen_width, self.screen_height = pyautogui.size()
        
        # Action recording
        self.recording = False
        self.recorded_actions: List[Action] = []
        
        # Stats
        self.actions_executed = 0
        
        print(f"[PyAutoGUI] Initialized ({self.screen_width}x{self.screen_height})")
    
    # ========================================================================
    # MOUSE CONTROL
    # ========================================================================
    
    def move_to(self, x: int, y: int, duration: float = None) -> None:
        """Move mouse to position"""
        pyautogui.moveTo(x, y, duration=duration or self.move_duration)
        self.actions_executed += 1
    
    def move_relative(self, x: int, y: int, duration: float = None) -> None:
        """Move mouse relative to current position"""
        pyautogui.moveRel(x, y, duration=duration or self.move_duration)
        self.actions_executed += 1
    
    def click(
        self,
        x: int = None,
        y: int = None,
        button: MouseButton = MouseButton.LEFT,
        clicks: int = 1
    ) -> None:
        """Click at position"""
        if x is not None and y is not None:
            pyautogui.click(x, y, clicks=clicks, button=button.value)
        else:
            pyautogui.click(clicks=clicks, button=button.value)
        self.actions_executed += 1
    
    def double_click(self, x: int = None, y: int = None) -> None:
        """Double click"""
        if x is not None and y is not None:
            pyautogui.doubleClick(x, y)
        else:
            pyautogui.doubleClick()
        self.actions_executed += 1
    
    def right_click(self, x: int = None, y: int = None) -> None:
        """Right click"""
        if x is not None and y is not None:
            pyautogui.rightClick(x, y)
        else:
            pyautogui.rightClick()
        self.actions_executed += 1
    
    def scroll(self, amount: int, x: int = None, y: int = None) -> None:
        """Scroll at position"""
        if x is not None and y is not None:
            pyautogui.scroll(amount, x, y)
        else:
            pyautogui.scroll(amount)
        self.actions_executed += 1
    
    def drag_to(self, x: int, y: int, duration: float = None, button: MouseButton = MouseButton.LEFT) -> None:
        """Drag to position"""
        pyautogui.dragTo(x, y, duration=duration or self.move_duration, button=button.value)
        self.actions_executed += 1
    
    def get_mouse_position(self) -> Point:
        """Get current mouse position"""
        x, y = pyautogui.position()
        return Point(x, y)
    
    # ========================================================================
    # KEYBOARD CONTROL
    # ========================================================================
    
    def typewrite(self, text: str, interval: float = 0.01) -> None:
        """Type text"""
        pyautogui.typewrite(text, interval=interval)
        self.actions_executed += 1
    
    def press(self, key: str) -> None:
        """Press key"""
        pyautogui.press(key)
        self.actions_executed += 1
    
    def hotkey(self, *keys: str) -> None:
        """Press key combination"""
        pyautogui.hotkey(*keys)
        self.actions_executed += 1
    
    def key_down(self, key: str) -> None:
        """Hold key down"""
        pyautogui.keyDown(key)
    
    def key_up(self, key: str) -> None:
        """Release key"""
        pyautogui.keyUp(key)
    
    # ========================================================================
    # SCREEN FUNCTIONS
    # ========================================================================
    
    def take_screenshot(self, region: Tuple[int, int, int, int] = None) -> Any:
        """Take screenshot"""
        return pyautogui.screenshot(region=region)
    
    def locate_on_screen(self, image_path: str, confidence: float = 0.9) -> Optional[Tuple]:
        """Locate image on screen"""
        try:
            return pyautogui.locateOnScreen(image_path, confidence=confidence)
        except:
            return None
    
    def locate_center_on_screen(self, image_path: str, confidence: float = 0.9) -> Optional[Point]:
        """Locate center of image on screen"""
        try:
            location = pyautogui.locateCenterOnScreen(image_path, confidence=confidence)
            if location:
                return Point(location.x, location.y)
        except:
            pass
        return None
    
    def click_image(self, image_path: str, confidence: float = 0.9) -> bool:
        """Click on image if found"""
        location = self.locate_center_on_screen(image_path, confidence)
        if location:
            self.click(location.x, location.y)
            return True
        return False
    
    def wait_for_image(self, image_path: str, timeout: float = 10, confidence: float = 0.9) -> Optional[Point]:
        """Wait for image to appear on screen"""
        start_time = time.time()
        
        while time.time() - start_time < timeout:
            location = self.locate_center_on_screen(image_path, confidence)
            if location:
                return location
            time.sleep(0.5)
        
        return None
    
    # ========================================================================
    # WINDOW MANAGEMENT
    # ========================================================================
    
    def get_active_window(self) -> Optional[str]:
        """Get active window title"""
        if PYGETWINDOW_AVAILABLE:
            try:
                window = gw.getActiveWindow()
                return window.title if window else None
            except:
                pass
        return None
    
    def get_window(self, title: str) -> Optional[Any]:
        """Get window by title"""
        if PYGETWINDOW_AVAILABLE:
            try:
                windows = gw.getWindowsWithTitle(title)
                return windows[0] if windows else None
            except:
                pass
        return None
    
    def activate_window(self, title: str) -> bool:
        """Activate window by title"""
        window = self.get_window(title)
        if window:
            try:
                window.activate()
                return True
            except:
                pass
        return False
    
    def list_windows(self) -> List[str]:
        """List all window titles"""
        if PYGETWINDOW_AVAILABLE:
            try:
                return [w.title for w in gw.getAllWindows() if w.title]
            except:
                pass
        return []
    
    # ========================================================================
    # ACTION RECORDING
    # ========================================================================
    
    def start_recording(self):
        """Start recording actions"""
        self.recording = True
        self.recorded_actions = []
        print("[PyAutoGUI] Recording started")
    
    def stop_recording(self) -> List[Action]:
        """Stop recording and return actions"""
        self.recording = False
        print(f"[PyAutoGUI] Recording stopped ({len(self.recorded_actions)} actions)")
        return self.recorded_actions.copy()
    
    def record_action(self, action_type: str, params: Dict):
        """Record an action"""
        if self.recording:
            action = Action(
                action_type=action_type,
                params=params,
                timestamp=time.time()
            )
            self.recorded_actions.append(action)
    
    def playback_actions(self, actions: List[Action], speed: float = 1.0):
        """Playback recorded actions"""
        if not actions:
            return
        
        print(f"[PyAutoGUI] Playing back {len(actions)} actions")
        
        for action in actions:
            # Calculate delay
            if action != actions[0]:
                prev_time = actions[actions.index(action) - 1].timestamp
                delay = (action.timestamp - prev_time) / speed
                time.sleep(max(0, delay))
            
            # Execute action
            self._execute_action(action)
    
    def _execute_action(self, action: Action):
        """Execute a recorded action"""
        action_type = action.action_type
        params = action.params
        
        if action_type == "move":
            self.move_to(params['x'], params['y'])
        elif action_type == "click":
            self.click(params.get('x'), params.get('y'), MouseButton(params.get('button', 'left')))
        elif action_type == "type":
            self.typewrite(params['text'])
        elif action_type == "key":
            self.press(params['key'])
        elif action_type == "hotkey":
            self.hotkey(*params['keys'])
    
    # ========================================================================
    # HIGH-LEVEL ACTIONS
    # ========================================================================
    
    def click_at_text(self, text: str, ocr_engine: Any = None) -> bool:
        """Click at text location using OCR"""
        if ocr_engine is None:
            return False
        
        # Take screenshot
        screenshot = self.take_screenshot()
        
        # Find text
        bbox = ocr_engine.find_text(screenshot, text)
        
        if bbox:
            x = (bbox[0] + bbox[2]) // 2
            y = (bbox[1] + bbox[3]) // 2
            self.click(x, y)
            return True
        
        return False
    
    def fill_form(self, fields: Dict[str, str], submit: bool = True) -> None:
        """Fill form fields"""
        for field_name, value in fields.items():
            # Tab to next field (or click if first)
            if field_name == list(fields.keys())[0]:
                # First field - assume already focused or click
                pass
            else:
                self.press('tab')
                time.sleep(0.1)
            
            # Type value
            self.typewrite(value)
            time.sleep(0.1)
        
        if submit:
            self.press('return')
    
    def select_menu(self, menu_path: List[str]) -> None:
        """Select menu item by path"""
        for item in menu_path:
            # Click menu item
            # In practice, would use image recognition or OCR
            print(f"Selecting: {item}")
            time.sleep(0.2)
    
    # ========================================================================
    # SAFETY
    # ========================================================================
    
    def enable_failsafe(self):
        """Enable fail-safe (move mouse to corner to abort)"""
        pyautogui.FAILSAFE = True
    
    def disable_failsafe(self):
        """Disable fail-safe"""
        pyautogui.FAILSAFE = False
    
    def confirm_action(self, message: str = "Proceed?") -> bool:
        """Confirm action with user"""
        # In GUI mode, would show dialog
        # For now, auto-confirm
        return True
    
    # ========================================================================
    # STATS
    # ========================================================================
    
    def get_stats(self) -> Dict:
        """Get controller statistics"""
        return {
            'screen_size': (self.screen_width, self.screen_height),
            'actions_executed': self.actions_executed,
            'recording': self.recording,
            'recorded_actions': len(self.recorded_actions),
            'failsafe_enabled': pyautogui.FAILSAFE
        }


# =============================================================================
# STANDALONE TEST
# =============================================================================

if __name__ == "__main__":
    # Test PyAutoGUI Controller
    controller = PyAutoGUIController()
    
    print(f"Stats: {controller.get_stats()}")
    
    # Get mouse position
    pos = controller.get_mouse_position()
    print(f"Mouse position: {pos}")
    
    # List windows
    windows = controller.list_windows()
    print(f"Windows: {windows[:5]}")

"""
JARVIS AUTOMATION - Global App Handler & Control
"""
from .global_app_handler import GlobalAppHandler
from .web_scraper import DocumentationScraper
from .pyautogui_controller import PyAutoGUIController
from .app_detector import AppDetector
from .action_recorder import ActionRecorder

__all__ = ['GlobalAppHandler', 'DocumentationScraper', 'PyAutoGUIController', 'AppDetector', 'ActionRecorder']

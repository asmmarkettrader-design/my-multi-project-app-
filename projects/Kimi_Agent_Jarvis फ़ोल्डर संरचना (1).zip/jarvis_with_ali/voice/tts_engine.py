#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                      🔊 TTS ENGINE - TEXT TO SPEECH                           ║
║                                                                              ║
║  Convert text to speech using multiple backends                             ║
║  pyttsx3 (offline) | gTTS (online) | ElevenLabs (premium)                   ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

import os
import tempfile
import time
from typing import Optional
from dataclasses import dataclass
from pathlib import Path

try:
    import pyttsx3
    PYTTSX3_AVAILABLE = True
except ImportError:
    PYTTSX3_AVAILABLE = False


@dataclass
class TTSResult:
    """Text to speech result"""
    audio_path: str
    duration_ms: float
    engine: str


class TTSEngine:
    """
    🔊 TTS ENGINE - Text to Speech
    
    Supports multiple backends:
    - pyttsx3 (offline, fast)
    - gTTS (online, natural)
    - ElevenLabs (premium, ultra-natural)
    """
    
    def __init__(
        self,
        engine: str = "pyttsx3",
        voice: str = None,
        rate: int = 175,
        volume: float = 1.0,
        api_key: str = None
    ):
        """Initialize TTS Engine"""
        self.engine_name = engine
        self.voice = voice
        self.rate = rate
        self.volume = volume
        self.api_key = api_key
        
        # pyttsx3 engine
        self.engine = None
        
        if engine == "pyttsx3" and PYTTSX3_AVAILABLE:
            self._init_pyttsx3()
        
        # Output directory
        self.output_dir = Path("./data/audio")
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
        print(f"[TTS] Initialized ({engine})")
    
    def _init_pyttsx3(self):
        """Initialize pyttsx3 engine"""
        try:
            self.engine = pyttsx3.init()
            self.engine.setProperty('rate', self.rate)
            self.engine.setProperty('volume', self.volume)
            
            # Set voice if specified
            if self.voice:
                voices = self.engine.getProperty('voices')
                for v in voices:
                    if self.voice.lower() in v.name.lower():
                        self.engine.setProperty('voice', v.id)
                        break
            
            print("[TTS] pyttsx3 initialized")
            
        except Exception as e:
            print(f"[TTS] pyttsx3 init error: {e}")
            self.engine = None
    
    def speak(self, text: str, save_path: str = None) -> Optional[TTSResult]:
        """Convert text to speech and play/save"""
        start_time = time.time()
        
        if self.engine_name == "pyttsx3" and self.engine:
            return self._speak_pyttsx3(text, save_path, start_time)
        else:
            # Fallback
            print(f"[TTS] {text}")
            return None
    
    def _speak_pyttsx3(self, text: str, save_path: str, start_time: float) -> TTSResult:
        """Speak using pyttsx3"""
        if save_path:
            self.engine.save_to_file(text, save_path)
            self.engine.runAndWait()
        else:
            self.engine.say(text)
            self.engine.runAndWait()
        
        duration = (time.time() - start_time) * 1000
        
        return TTSResult(
            audio_path=save_path or "",
            duration_ms=duration,
            engine="pyttsx3"
        )
    
    def stop(self):
        """Stop speaking"""
        if self.engine:
            self.engine.stop()

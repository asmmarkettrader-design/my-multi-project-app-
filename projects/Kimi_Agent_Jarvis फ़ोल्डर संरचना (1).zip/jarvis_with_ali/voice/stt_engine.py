#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                      🎤 STT ENGINE - SPEECH TO TEXT                           ║
║                                                                              ║
║  Convert speech to text using multiple backends                             ║
║  Google Speech Recognition | Whisper | Vosk                                 ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

import os
import io
import wave
import time
from typing import Optional, List, Callable
from dataclasses import dataclass

try:
    import speech_recognition as sr
    SR_AVAILABLE = True
except ImportError:
    SR_AVAILABLE = False

try:
    import pyaudio
    PYAUDIO_AVAILABLE = True
except ImportError:
    PYAUDIO_AVAILABLE = False


@dataclass
class TranscriptionResult:
    """Speech transcription result"""
    text: str
    confidence: float
    language: str
    duration_ms: float


class STTEngine:
    """
    🎤 STT ENGINE - Speech to Text
    
    Supports multiple backends:
    - Google Speech Recognition (online, free)
    - OpenAI Whisper (online, accurate)
    - Vosk (offline, lightweight)
    """
    
    def __init__(
        self,
        engine: str = "google",
        language: str = "en-US",
        api_key: str = None
    ):
        """Initialize STT Engine"""
        self.engine = engine
        self.language = language
        self.api_key = api_key
        
        # Speech recognition
        self.recognizer = None
        self.microphone = None
        
        if SR_AVAILABLE:
            self.recognizer = sr.Recognizer()
            self.recognizer.energy_threshold = 300
            self.recognizer.dynamic_energy_threshold = True
        
        if PYAUDIO_AVAILABLE:
            self.microphone = sr.Microphone() if SR_AVAILABLE else None
        
        # Callbacks
        self.on_transcription: Optional[Callable] = None
        
        print(f"[STT] Initialized ({engine}, {language})")
    
    def listen(self, timeout: float = None, phrase_time_limit: float = None) -> Optional[TranscriptionResult]:
        """Listen and transcribe from microphone"""
        if not SR_AVAILABLE or not self.microphone:
            print("[STT] Speech recognition not available")
            return None
        
        start_time = time.time()
        
        try:
            with self.microphone as source:
                print("[STT] Listening...")
                self.recognizer.adjust_for_ambient_noise(source, duration=0.5)
                audio = self.recognizer.listen(source, timeout=timeout, phrase_time_limit=phrase_time_limit)
            
            return self._transcribe_audio(audio, start_time)
            
        except sr.WaitTimeoutError:
            print("[STT] Listen timeout")
            return None
        except Exception as e:
            print(f"[STT] Listen error: {e}")
            return None
    
    def transcribe_file(self, audio_path: str) -> Optional[TranscriptionResult]:
        """Transcribe audio file"""
        if not SR_AVAILABLE:
            return None
        
        start_time = time.time()
        
        try:
            with sr.AudioFile(audio_path) as source:
                audio = self.recognizer.record(source)
            
            return self._transcribe_audio(audio, start_time)
            
        except Exception as e:
            print(f"[STT] Transcription error: {e}")
            return None
    
    def _transcribe_audio(self, audio, start_time: float) -> Optional[TranscriptionResult]:
        """Transcribe audio data"""
        try:
            if self.engine == "google":
                text = self.recognizer.recognize_google(audio, language=self.language)
                confidence = 0.9
            elif self.engine == "whisper" and self.api_key:
                # Would use OpenAI Whisper API
                text = "Whisper transcription placeholder"
                confidence = 0.95
            else:
                text = self.recognizer.recognize_google(audio, language=self.language)
                confidence = 0.9
            
            duration = (time.time() - start_time) * 1000
            
            result = TranscriptionResult(
                text=text,
                confidence=confidence,
                language=self.language,
                duration_ms=duration
            )
            
            if self.on_transcription:
                self.on_transcription(result)
            
            return result
            
        except sr.UnknownValueError:
            print("[STT] Could not understand audio")
            return None
        except sr.RequestError as e:
            print(f"[STT] API error: {e}")
            return None
    
    def listen_continuous(self, callback: Callable, phrase_time_limit: float = 5.0):
        """Listen continuously and call callback for each transcription"""
        self.on_transcription = callback
        
        print("[STT] Continuous listening started")
        
        while True:
            result = self.listen(phrase_time_limit=phrase_time_limit)
            if result:
                callback(result)

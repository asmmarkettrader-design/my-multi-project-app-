#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                      🛒 SHOPIFY MANAGER - STORE AUTOMATION                    ║
║                                                                              ║
║  Automate Shopify store operations                                          ║
║  Product management | Order processing | Inventory tracking                 ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

import requests
import json
import time
from typing import Dict, List, Optional, Any
from dataclasses import dataclass


@dataclass
class Product:
    """Shopify product"""
    id: int
    title: str
    price: float
    inventory: int
    sku: str
    status: str


class ShopifyManager:
    """
    🛒 SHOPIFY MANAGER - Store Automation
    
    Features:
    - Product CRUD operations
    - Order management
    - Inventory tracking
    - Customer management
    """
    
    def __init__(
        self,
        shop_url: str = None,
        api_key: str = None,
        password: str = None,
        api_version: str = "2023-10"
    ):
        """Initialize Shopify Manager"""
        self.shop_url = shop_url
        self.api_key = api_key
        self.password = password
        self.api_version = api_version
        
        self.base_url = f"https://{shop_url}/admin/api/{api_version}" if shop_url else None
        
        # Auth header
        self.headers = {
            "Content-Type": "application/json",
            "X-Shopify-Access-Token": password
        } if password else {}
        
        print("[ShopifyManager] Initialized")
    
    def _make_request(self, method: str, endpoint: str, data: Dict = None) -> Optional[Dict]:
        """Make API request to Shopify"""
        if not self.base_url:
            return None
        
        url = f"{self.base_url}/{endpoint}"
        
        try:
            if method == "GET":
                response = requests.get(url, headers=self.headers, timeout=30)
            elif method == "POST":
                response = requests.post(url, headers=self.headers, json=data, timeout=30)
            elif method == "PUT":
                response = requests.put(url, headers=self.headers, json=data, timeout=30)
            elif method == "DELETE":
                response = requests.delete(url, headers=self.headers, timeout=30)
            else:
                return None
            
            if response.status_code in [200, 201]:
                return response.json()
            else:
                print(f"[ShopifyManager] API error: {response.status_code}")
                return None
                
        except Exception as e:
            print(f"[ShopifyManager] Request error: {e}")
            return None
    
    def get_products(self, limit: int = 50) -> List[Product]:
        """Get all products"""
        data = self._make_request("GET", f"products.json?limit={limit}")
        
        if not data:
            return []
        
        products = []
        for p in data.get('products', []):
            variant = p.get('variants', [{}])[0]
            products.append(Product(
                id=p.get('id'),
                title=p.get('title', ''),
                price=float(variant.get('price', 0)),
                inventory=variant.get('inventory_quantity', 0),
                sku=variant.get('sku', ''),
                status=p.get('status', '')
            ))
        
        return products
    
    def update_inventory(self, product_id: int, quantity: int) -> bool:
        """Update product inventory"""
        # Get variant ID
        data = self._make_request("GET", f"products/{product_id}.json")
        
        if not data or not data.get('product'):
            return False
        
        variant_id = data['product']['variants'][0]['id']
        
        # Update inventory
        inventory_data = {
            "inventory_item": {
                "id": variant_id,
                "available": quantity
            }
        }
        
        result = self._make_request("PUT", f"inventory_items/{variant_id}.json", inventory_data)
        return result is not None

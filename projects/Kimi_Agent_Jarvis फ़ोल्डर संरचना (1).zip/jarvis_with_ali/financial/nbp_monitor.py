#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                      💰 NBP MONITOR - INVESTMENT TRACKER                      ║
║                                                                              ║
║  Monitor NBP Funds and other investment platforms                           ║
║  Compounding growth tracking | Market alerts | Investment suggestions       ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

import os
import json
import time
import threading
from pathlib import Path
from typing import Dict, List, Optional, Any, Callable
from dataclasses import dataclass, field
from datetime import datetime, timedelta
import requests


# =============================================================================
# DATA CLASSES
# =============================================================================

@dataclass
class FundInvestment:
    """Individual fund investment"""
    fund_name: str
    fund_code: str
    initial_investment: float
    current_value: float
    units_held: float
    nav_at_purchase: float
    current_nav: float
    purchase_date: str
    last_updated: float = field(default_factory=time.time)
    
    @property
    def returns_absolute(self) -> float:
        return self.current_value - self.initial_investment
    
    @property
    def returns_percentage(self) -> float:
        if self.initial_investment > 0:
            return (self.returns_absolute / self.initial_investment) * 100
        return 0.0
    
    @property
    def annualized_return(self) -> float:
        """Calculate annualized return"""
        try:
            purchase = datetime.strptime(self.purchase_date, "%Y-%m-%d")
            days_held = (datetime.now() - purchase).days
            if days_held > 0:
                total_return = self.returns_percentage / 100
                years = days_held / 365.25
                return ((1 + total_return) ** (1 / years) - 1) * 100
        except:
            pass
        return 0.0

@dataclass
class MarketAlert:
    """Market alert notification"""
    alert_type: str  # 'price_drop', 'price_rise', 'target_reached', 'news'
    fund_code: str
    message: str
    severity: str = "info"  # info, warning, critical
    timestamp: float = field(default_factory=time.time)
    data: Dict[str, Any] = field(default_factory=dict)


# =============================================================================
# NBP MONITOR
# =============================================================================

class NBPMonitor:
    """
    💰 NBP MONITOR - Investment Intelligence
    
    Features:
    - Track NBP Funds performance
    - Monitor compounding growth
    - Price alerts and notifications
    - Investment suggestions
    - Portfolio analysis
    
    Check interval: Every 6 hours
    """
    
    # NBP Fund NAV API (example endpoints)
    NBP_API_BASE = "https://www.nbp.com.pk/api"
    
    # Popular NBP Funds
    POPULAR_FUNDS = {
        'NBPIF': 'NBP Islamic Fund',
        'NBPIEF': 'NBP Islamic Equity Fund',
        'NBPGOF': 'NBP Government Securities Fund',
        'NBPCGF': 'NBP Capital Growth Fund',
        'NBPIMF': 'NBP Income Fund',
        'NBPMAAF': 'NBP Monthly AA Fund',
    }
    
    def __init__(
        self,
        portfolio_file: str = "./data/portfolio.json",
        check_interval_hours: int = 6,
        alert_threshold_percent: float = 5.0
    ):
        """Initialize NBP Monitor"""
        self.portfolio_file = Path(portfolio_file)
        self.check_interval = check_interval_hours * 3600
        self.alert_threshold = alert_threshold_percent
        
        # Portfolio data
        self.investments: Dict[str, FundInvestment] = {}
        self.fund_nav_cache: Dict[str, Dict] = {}
        
        # Alerts
        self.alerts: List[MarketAlert] = []
        self.alert_callbacks: List[Callable] = []
        
        # Monitoring
        self.monitoring = False
        self.monitor_thread: Optional[threading.Thread] = None
        
        # Stats
        self.last_check = 0
        self.total_checks = 0
        
        # Load portfolio
        self._load_portfolio()
        
        print("[NBPMonitor] Initialized")
    
    # ========================================================================
    # PORTFOLIO MANAGEMENT
    # ========================================================================
    
    def _load_portfolio(self):
        """Load portfolio from file"""
        if self.portfolio_file.exists():
            try:
                with open(self.portfolio_file, 'r') as f:
                    data = json.load(f)
                
                for code, inv_data in data.get('investments', {}).items():
                    self.investments[code] = FundInvestment(**inv_data)
                
                print(f"[NBPMonitor] Loaded {len(self.investments)} investments")
            except Exception as e:
                print(f"[NBPMonitor] Load error: {e}")
    
    def _save_portfolio(self):
        """Save portfolio to file"""
        try:
            self.portfolio_file.parent.mkdir(parents=True, exist_ok=True)
            
            data = {
                'investments': {
                    code: {
                        'fund_name': inv.fund_name,
                        'fund_code': inv.fund_code,
                        'initial_investment': inv.initial_investment,
                        'current_value': inv.current_value,
                        'units_held': inv.units_held,
                        'nav_at_purchase': inv.nav_at_purchase,
                        'current_nav': inv.current_nav,
                        'purchase_date': inv.purchase_date,
                        'last_updated': inv.last_updated
                    }
                    for code, inv in self.investments.items()
                },
                'last_saved': time.time()
            }
            
            with open(self.portfolio_file, 'w') as f:
                json.dump(data, f, indent=2)
            
        except Exception as e:
            print(f"[NBPMonitor] Save error: {e}")
    
    def add_investment(
        self,
        fund_code: str,
        fund_name: str,
        initial_investment: float,
        units_held: float,
        nav_at_purchase: float,
        purchase_date: str = None
    ) -> FundInvestment:
        """Add new investment to portfolio"""
        purchase_date = purchase_date or datetime.now().strftime("%Y-%m-%d")
        
        investment = FundInvestment(
            fund_name=fund_name,
            fund_code=fund_code,
            initial_investment=initial_investment,
            current_value=initial_investment,
            units_held=units_held,
            nav_at_purchase=nav_at_purchase,
            current_nav=nav_at_purchase,
            purchase_date=purchase_date
        )
        
        self.investments[fund_code] = investment
        self._save_portfolio()
        
        print(f"[NBPMonitor] Added investment: {fund_name} ({fund_code})")
        return investment
    
    def remove_investment(self, fund_code: str) -> bool:
        """Remove investment from portfolio"""
        if fund_code in self.investments:
            del self.investments[fund_code]
            self._save_portfolio()
            return True
        return False
    
    # ========================================================================
    # NAV FETCHING
    # ========================================================================
    
    def fetch_nav(self, fund_code: str) -> Optional[float]:
        """Fetch current NAV for fund"""
        try:
            # In production, this would call actual NBP API
            # For now, simulate with cached or estimated value
            
            if fund_code in self.fund_nav_cache:
                cache = self.fund_nav_cache[fund_code]
                if time.time() - cache['timestamp'] < 3600:  # 1 hour cache
                    return cache['nav']
            
            # Simulate API call
            # nav = self._call_nbp_api(fund_code)
            
            # For demo, generate realistic NAV
            base_nav = 10.0
            if fund_code in self.investments:
                base_nav = self.investments[fund_code].nav_at_purchase
            
            # Add some random variation
            import random
            variation = random.uniform(-0.05, 0.05)
            nav = base_nav * (1 + variation)
            
            # Cache result
            self.fund_nav_cache[fund_code] = {
                'nav': nav,
                'timestamp': time.time()
            }
            
            return nav
            
        except Exception as e:
            print(f"[NBPMonitor] NAV fetch error: {e}")
            return None
    
    def _call_nbp_api(self, fund_code: str) -> Optional[float]:
        """Call NBP API for NAV"""
        try:
            url = f"{self.NBP_API_BASE}/funds/{fund_code}/nav"
            response = requests.get(url, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                return float(data.get('nav', 0))
            
        except Exception as e:
            print(f"[NBPMonitor] API error: {e}")
        
        return None
    
    # ========================================================================
    # MONITORING
    # ========================================================================
    
    def start_monitoring(self):
        """Start automatic monitoring"""
        if self.monitoring:
            return
        
        self.monitoring = True
        self.monitor_thread = threading.Thread(target=self._monitor_loop, daemon=True)
        self.monitor_thread.start()
        print("[NBPMonitor] Monitoring started")
    
    def stop_monitoring(self):
        """Stop automatic monitoring"""
        self.monitoring = False
        if self.monitor_thread:
            self.monitor_thread.join(timeout=2)
        print("[NBPMonitor] Monitoring stopped")
    
    def _monitor_loop(self):
        """Main monitoring loop"""
        while self.monitoring:
            try:
                self.check_all_funds()
                
                # Sleep until next check
                for _ in range(int(self.check_interval / 10)):
                    if not self.monitoring:
                        break
                    time.sleep(10)
                    
            except Exception as e:
                print(f"[NBPMonitor] Monitor error: {e}")
                time.sleep(60)
    
    def check_all_funds(self):
        """Check all funds in portfolio"""
        print("[NBPMonitor] Checking all funds...")
        
        for fund_code, investment in self.investments.items():
            try:
                # Fetch current NAV
                current_nav = self.fetch_nav(fund_code)
                
                if current_nav:
                    # Update investment
                    old_value = investment.current_value
                    investment.current_nav = current_nav
                    investment.current_value = investment.units_held * current_nav
                    investment.last_updated = time.time()
                    
                    # Check for significant changes
                    change_percent = ((investment.current_value - old_value) / old_value * 100) if old_value > 0 else 0
                    
                    if abs(change_percent) >= self.alert_threshold:
                        self._create_alert(fund_code, change_percent, investment)
                
            except Exception as e:
                print(f"[NBPMonitor] Check error for {fund_code}: {e}")
        
        # Save updated portfolio
        self._save_portfolio()
        
        self.last_check = time.time()
        self.total_checks += 1
        
        print(f"[NBPMonitor] Check complete. Total checks: {self.total_checks}")
    
    def _create_alert(self, fund_code: str, change_percent: float, investment: FundInvestment):
        """Create market alert"""
        alert_type = 'price_rise' if change_percent > 0 else 'price_drop'
        severity = 'warning' if abs(change_percent) > 10 else 'info'
        
        alert = MarketAlert(
            alert_type=alert_type,
            fund_code=fund_code,
            message=f"{investment.fund_name} {'up' if change_percent > 0 else 'down'} {abs(change_percent):.2f}%",
            severity=severity,
            data={
                'change_percent': change_percent,
                'current_value': investment.current_value,
                'returns_percentage': investment.returns_percentage
            }
        )
        
        self.alerts.append(alert)
        
        # Notify callbacks
        for callback in self.alert_callbacks:
            try:
                callback(alert)
            except:
                pass
        
        print(f"[NBPMonitor] Alert: {alert.message}")
    
    # ========================================================================
    # ANALYSIS & SUGGESTIONS
    # ========================================================================
    
    def get_portfolio_summary(self) -> Dict:
        """Get portfolio summary"""
        if not self.investments:
            return {
                'total_invested': 0,
                'current_value': 0,
                'total_returns': 0,
                'returns_percentage': 0,
                'fund_count': 0
            }
        
        total_invested = sum(inv.initial_investment for inv in self.investments.values())
        current_value = sum(inv.current_value for inv in self.investments.values())
        total_returns = current_value - total_invested
        returns_percentage = (total_returns / total_invested * 100) if total_invested > 0 else 0
        
        return {
            'total_invested': round(total_invested, 2),
            'current_value': round(current_value, 2),
            'total_returns': round(total_returns, 2),
            'returns_percentage': round(returns_percentage, 2),
            'fund_count': len(self.investments)
        }
    
    def get_fund_performance(self, fund_code: str = None) -> Dict:
        """Get performance data for fund(s)"""
        if fund_code:
            inv = self.investments.get(fund_code)
            if inv:
                return {
                    'fund_code': fund_code,
                    'fund_name': inv.fund_name,
                    'initial_investment': inv.initial_investment,
                    'current_value': inv.current_value,
                    'returns_absolute': inv.returns_absolute,
                    'returns_percentage': inv.returns_percentage,
                    'annualized_return': inv.annualized_return,
                    'days_held': (datetime.now() - datetime.strptime(inv.purchase_date, "%Y-%m-%d")).days
                }
            return {}
        
        # Return all funds
        return {code: self.get_fund_performance(code) for code in self.investments}
    
    def suggest_investment_moves(self) -> List[str]:
        """Suggest investment moves based on analysis"""
        suggestions = []
        
        summary = self.get_portfolio_summary()
        
        # Check overall performance
        if summary['returns_percentage'] < -5:
            suggestions.append("Portfolio showing negative returns. Consider reviewing underperforming funds.")
        
        if summary['returns_percentage'] > 15:
            suggestions.append("Strong portfolio performance! Consider taking some profits.")
        
        # Check individual funds
        for code, inv in self.investments.items():
            if inv.returns_percentage < -10:
                suggestions.append(f"{inv.fund_name} is down {inv.returns_percentage:.1f}%. Consider rebalancing.")
            
            if inv.returns_percentage > 20:
                suggestions.append(f"{inv.fund_name} showing strong gains ({inv.returns_percentage:.1f}%). Review for profit booking.")
        
        # Diversification check
        if len(self.investments) < 3:
            suggestions.append("Portfolio is under-diversified. Consider adding more funds.")
        
        return suggestions
    
    def calculate_compounding(
        self,
        principal: float,
        annual_rate: float,
        years: int,
        monthly_contribution: float = 0
    ) -> Dict:
        """Calculate compounding growth projection"""
        monthly_rate = annual_rate / 100 / 12
        months = years * 12
        
        future_value = principal
        total_contributed = principal
        
        for _ in range(months):
            future_value = future_value * (1 + monthly_rate) + monthly_contribution
            total_contributed += monthly_contribution
        
        interest_earned = future_value - total_contributed
        
        return {
            'principal': principal,
            'monthly_contribution': monthly_contribution,
            'annual_rate': annual_rate,
            'years': years,
            'future_value': round(future_value, 2),
            'total_contributed': round(total_contributed, 2),
            'interest_earned': round(interest_earned, 2),
            'growth_multiple': round(future_value / principal, 2) if principal > 0 else 0
        }
    
    # ========================================================================
    # ALERTS
    # ========================================================================
    
    def add_alert_callback(self, callback: Callable):
        """Add callback for alerts"""
        self.alert_callbacks.append(callback)
    
    def get_recent_alerts(self, count: int = 10) -> List[MarketAlert]:
        """Get recent alerts"""
        return sorted(self.alerts, key=lambda a: a.timestamp, reverse=True)[:count]
    
    def clear_alerts(self):
        """Clear all alerts"""
        self.alerts = []
    
    # ========================================================================
    # STATS
    # ========================================================================
    
    def get_stats(self) -> Dict:
        """Get monitor statistics"""
        return {
            'investments_count': len(self.investments),
            'total_checks': self.total_checks,
            'last_check': self.last_check,
            'monitoring': self.monitoring,
            'alert_count': len(self.alerts),
            'portfolio': self.get_portfolio_summary()
        }


# =============================================================================
# STANDALONE TEST
# =============================================================================

if __name__ == "__main__":
    # Test NBP Monitor
    monitor = NBPMonitor()
    
    # Add test investment
    monitor.add_investment(
        fund_code='NBPIF',
        fund_name='NBP Islamic Fund',
        initial_investment=100000,
        units_held=10000,
        nav_at_purchase=10.0,
        purchase_date='2024-01-01'
    )
    
    # Check funds
    monitor.check_all_funds()
    
    # Print summary
    print(f"\nPortfolio Summary: {monitor.get_portfolio_summary()}")
    print(f"\nSuggestions: {monitor.suggest_investment_moves()}")
    
    # Compounding calculation
    comp = monitor.calculate_compounding(100000, 15, 5, 10000)
    print(f"\nCompounding Projection: {comp}")
    
    print(f"\nStats: {monitor.get_stats()}")

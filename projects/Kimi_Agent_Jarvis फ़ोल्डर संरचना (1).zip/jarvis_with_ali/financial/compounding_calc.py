#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                    📈 COMPOUNDING CALCULATOR - GROWTH PROJECTION              ║
║                                                                              ║
║  Calculate investment growth with compounding                               ║
║  Multiple scenarios | Visual projections | Comparison tools                 ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

import json
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass


@dataclass
class InvestmentScenario:
    """Investment scenario"""
    name: str
    principal: float
    monthly_contribution: float
    annual_rate: float
    years: int
    compounding_frequency: str = "monthly"


@dataclass
class ProjectionResult:
    """Projection calculation result"""
    scenario: InvestmentScenario
    final_amount: float
    total_contributed: float
    total_interest: float
    yearly_breakdown: List[Dict]


class CompoundingCalculator:
    """
    📈 COMPOUNDING CALCULATOR
    
    Calculate investment growth with compounding interest.
    Supports multiple scenarios and visual projections.
    """
    
    FREQUENCIES = {
        'monthly': 12,
        'quarterly': 4,
        'semi-annual': 2,
        'annual': 1,
        'daily': 365
    }
    
    def __init__(self):
        """Initialize Calculator"""
        self.scenarios: List[InvestmentScenario] = []
        print("[CompoundingCalc] Initialized")
    
    def calculate(
        self,
        principal: float,
        annual_rate: float,
        years: int,
        monthly_contribution: float = 0,
        frequency: str = "monthly"
    ) -> ProjectionResult:
        """Calculate compound growth"""
        
        periods_per_year = self.FREQUENCIES.get(frequency, 12)
        total_periods = years * periods_per_year
        rate_per_period = (annual_rate / 100) / periods_per_year
        
        # Calculate future value
        amount = principal
        total_contributed = principal
        yearly_breakdown = []
        
        for year in range(1, years + 1):
            start_amount = amount
            
            for _ in range(periods_per_year):
                amount = amount * (1 + rate_per_period) + monthly_contribution
                total_contributed += monthly_contribution
            
            yearly_breakdown.append({
                'year': year,
                'start_amount': round(start_amount, 2),
                'end_amount': round(amount, 2),
                'interest_earned': round(amount - start_amount - (monthly_contribution * periods_per_year), 2),
                'total_contributed': round(total_contributed, 2)
            })
        
        scenario = InvestmentScenario(
            name=f"Scenario_{len(self.scenarios) + 1}",
            principal=principal,
            monthly_contribution=monthly_contribution,
            annual_rate=annual_rate,
            years=years,
            compounding_frequency=frequency
        )
        
        self.scenarios.append(scenario)
        
        return ProjectionResult(
            scenario=scenario,
            final_amount=round(amount, 2),
            total_contributed=round(total_contributed, 2),
            total_interest=round(amount - total_contributed, 2),
            yearly_breakdown=yearly_breakdown
        )
    
    def compare_scenarios(self, scenarios: List[InvestmentScenario]) -> List[ProjectionResult]:
        """Compare multiple investment scenarios"""
        results = []
        
        for s in scenarios:
            result = self.calculate(
                principal=s.principal,
                annual_rate=s.annual_rate,
                years=s.years,
                monthly_contribution=s.monthly_contribution,
                frequency=s.compounding_frequency
            )
            results.append(result)
        
        return results
    
    def get_summary(self, result: ProjectionResult) -> Dict:
        """Get human-readable summary"""
        s = result.scenario
        
        return {
            'scenario_name': s.name,
            'initial_investment': s.principal,
            'monthly_contribution': s.monthly_contribution,
            'annual_return_rate': f"{s.annual_rate}%",
            'investment_period': f"{s.years} years",
            'final_amount': result.final_amount,
            'total_contributed': result.total_contributed,
            'total_interest_earned': result.total_interest,
            'growth_multiple': round(result.final_amount / s.principal, 2) if s.principal > 0 else 0
        }

#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                      📝 JARVIS LOGGER - CENTRAL LOGGING                       ║
║                                                                              ║
║  Centralized logging system with multiple outputs                           ║
║  File | Console | GUI | Remote                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

import os
import sys
import json
import logging
import queue
import threading
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Optional, Callable, Any
from dataclasses import dataclass, field


@dataclass
class LogEntry:
    """Log entry data"""
    timestamp: str
    level: str
    module: str
    message: str
    metadata: Dict[str, Any] = field(default_factory=dict)


class JarvisLogger:
    """
    📝 JARVIS LOGGER - Central Logging System
    
    Features:
    - Multiple output handlers
    - Async logging
    - Log rotation
    - GUI integration
    - Remote logging
    """
    
    LEVELS = {
        'DEBUG': 10,
        'INFO': 20,
        'WARNING': 30,
        'ERROR': 40,
        'CRITICAL': 50
    }
    
    def __init__(
        self,
        log_dir: str = "./data/logs",
        log_level: str = "INFO",
        max_file_size: int = 10 * 1024 * 1024,  # 10MB
        max_files: int = 5
    ):
        """Initialize Logger"""
        self.log_dir = Path(log_dir)
        self.log_dir.mkdir(parents=True, exist_ok=True)
        self.log_level = self.LEVELS.get(log_level, 20)
        self.max_file_size = max_file_size
        self.max_files = max_files
        
        # Log file
        self.log_file = self.log_dir / f"jarvis_{datetime.now().strftime('%Y%m%d')}.log"
        
        # Async queue
        self.log_queue = queue.Queue()
        self.running = False
        self.writer_thread: Optional[threading.Thread] = None
        
        # Callbacks
        self.callbacks: List[Callable] = []
        
        # Stats
        self.entries_logged = 0
        
        # Start writer
        self.start()
        
        print(f"[Logger] Initialized ({log_dir})")
    
    def start(self):
        """Start logger"""
        self.running = True
        self.writer_thread = threading.Thread(target=self._writer_loop, daemon=True)
        self.writer_thread.start()
    
    def stop(self):
        """Stop logger"""
        self.running = False
        self.log_queue.put(None)  # Signal to stop
        if self.writer_thread:
            self.writer_thread.join(timeout=2)
    
    def _writer_loop(self):
        """Background writer thread"""
        while self.running:
            try:
                entry = self.log_queue.get(timeout=1)
                if entry is None:
                    break
                self._write_entry(entry)
            except queue.Empty:
                continue
    
    def _write_entry(self, entry: LogEntry):
        """Write log entry to file"""
        line = f"[{entry.timestamp}] [{entry.level:8}] [{entry.module:15}] {entry.message}\n"
        
        with open(self.log_file, 'a', encoding='utf-8') as f:
            f.write(line)
        
        self.entries_logged += 1
    
    def log(self, message: str, level: str = "INFO", module: str = "SYSTEM", metadata: Dict = None):
        """Log a message"""
        if self.LEVELS.get(level, 20) < self.log_level:
            return
        
        entry = LogEntry(
            timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3],
            level=level,
            module=module,
            message=message,
            metadata=metadata or {}
        )
        
        # Add to queue
        self.log_queue.put(entry)
        
        # Console output
        print(f"[{entry.level}] [{module}] {message}")
        
        # Notify callbacks
        for callback in self.callbacks:
            try:
                callback(entry)
            except:
                pass
    
    def debug(self, message: str, module: str = "SYSTEM"):
        self.log(message, "DEBUG", module)
    
    def info(self, message: str, module: str = "SYSTEM"):
        self.log(message, "INFO", module)
    
    def warning(self, message: str, module: str = "SYSTEM"):
        self.log(message, "WARNING", module)
    
    def error(self, message: str, module: str = "SYSTEM"):
        self.log(message, "ERROR", module)
    
    def critical(self, message: str, module: str = "SYSTEM"):
        self.log(message, "CRITICAL", module)

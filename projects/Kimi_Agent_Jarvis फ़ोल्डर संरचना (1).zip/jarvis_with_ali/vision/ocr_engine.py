#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                         📝 OCR ENGINE - TEXT EXTRACTION                       ║
║                                                                              ║
║  Extract text from screen regions                                           ║
║  Supports EasyOCR and Tesseract                                             ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

import os
import re
from typing import List, Tuple, Optional, Any
from dataclasses import dataclass

try:
    import cv2
    import numpy as np
    CV_AVAILABLE = True
except ImportError:
    CV_AVAILABLE = False

# OCR backends
try:
    import easyocr
    EASYOCR_AVAILABLE = True
except ImportError:
    EASYOCR_AVAILABLE = False

try:
    import pytesseract
    TESSERACT_AVAILABLE = True
except ImportError:
    TESSERACT_AVAILABLE = False


# =============================================================================
# OCR ENGINE
# =============================================================================

class OCREngine:
    """
    📝 OCR ENGINE - Text Extraction
    
    Extracts text from images using:
    - EasyOCR (preferred, more accurate)
    - Tesseract (fallback, faster)
    
    Optimized for UI text extraction.
    """
    
    def __init__(self, engine: str = "auto", languages: List[str] = None):
        """Initialize OCR Engine"""
        if not CV_AVAILABLE:
            raise RuntimeError("OpenCV required for OCR")
        
        self.languages = languages or ["en"]
        self.engine = engine
        self.reader = None
        
        # Initialize
        self._init_engine()
    
    def _init_engine(self):
        """Initialize OCR backend"""
        if self.engine == "auto":
            if EASYOCR_AVAILABLE:
                self._init_easyocr()
            elif TESSERACT_AVAILABLE:
                self.engine = "tesseract"
                print("[OCR] Using Tesseract")
            else:
                print("[OCR] No OCR engine available")
        elif self.engine == "easyocr" and EASYOCR_AVAILABLE:
            self._init_easyocr()
        elif self.engine == "tesseract" and TESSERACT_AVAILABLE:
            pass
        else:
            print(f"[OCR] Requested engine {self.engine} not available")
    
    def _init_easyocr(self):
        """Initialize EasyOCR"""
        try:
            self.reader = easyocr.Reader(self.languages, gpu=False)
            self.engine = "easyocr"
            print("[OCR] EasyOCR initialized")
        except Exception as e:
            print(f"[OCR] EasyOCR init failed: {e}")
            self.reader = None
    
    # ========================================================================
    # TEXT EXTRACTION
    # ========================================================================
    
    def extract_text(self, image: Any) -> str:
        """Extract text from image"""
        if self.engine == "easyocr" and self.reader:
            return self._extract_easyocr(image)
        elif self.engine == "tesseract":
            return self._extract_tesseract(image)
        else:
            return ""
    
    def extract_with_boxes(self, image: Any) -> List[Tuple[str, Tuple]]:
        """Extract text with bounding boxes"""
        if self.engine == "easyocr" and self.reader:
            return self._extract_easyocr_boxes(image)
        elif self.engine == "tesseract":
            return self._extract_tesseract_boxes(image)
        else:
            return []
    
    def _extract_easyocr(self, image: Any) -> str:
        """Extract using EasyOCR"""
        try:
            # Preprocess
            processed = self._preprocess(image)
            
            # OCR
            results = self.reader.readtext(processed)
            
            # Extract text
            texts = [r[1] for r in results]
            return " ".join(texts)
            
        except Exception as e:
            print(f"[OCR] EasyOCR error: {e}")
            return ""
    
    def _extract_easyocr_boxes(self, image: Any) -> List[Tuple[str, Tuple]]:
        """Extract with boxes using EasyOCR"""
        try:
            processed = self._preprocess(image)
            results = self.reader.readtext(processed)
            
            # Format: [(text, (x1, y1, x2, y2)), ...]
            formatted = []
            for r in results:
                bbox = r[0]
                text = r[1]
                # Convert polygon to bbox
                x_coords = [p[0] for p in bbox]
                y_coords = [p[1] for p in bbox]
                x1, y1 = min(x_coords), min(y_coords)
                x2, y2 = max(x_coords), max(y_coords)
                formatted.append((text, (x1, y1, x2, y2)))
            
            return formatted
            
        except Exception as e:
            print(f"[OCR] EasyOCR boxes error: {e}")
            return []
    
    def _extract_tesseract(self, image: Any) -> str:
        """Extract using Tesseract"""
        try:
            processed = self._preprocess(image)
            
            # Configure for single uniform block of text
            custom_config = r'--oem 3 --psm 6'
            text = pytesseract.image_to_string(processed, config=custom_config)
            
            return text.strip()
            
        except Exception as e:
            print(f"[OCR] Tesseract error: {e}")
            return ""
    
    def _extract_tesseract_boxes(self, image: Any) -> List[Tuple[str, Tuple]]:
        """Extract with boxes using Tesseract"""
        try:
            processed = self._preprocess(image)
            
            # Get data
            data = pytesseract.image_to_data(processed, output_type=pytesseract.Output.DICT)
            
            results = []
            for i in range(len(data['text'])):
                if int(data['conf'][i]) > 60:  # Confidence threshold
                    text = data['text'][i].strip()
                    if text:
                        x, y, w, h = data['left'][i], data['top'][i], data['width'][i], data['height'][i]
                        results.append((text, (x, y, x + w, y + h)))
            
            return results
            
        except Exception as e:
            print(f"[OCR] Tesseract boxes error: {e}")
            return []
    
    # ========================================================================
    # PREPROCESSING
    # ========================================================================
    
    def _preprocess(self, image: Any) -> Any:
        """Preprocess image for better OCR"""
        # Convert to grayscale if needed
        if len(image.shape) == 3:
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        else:
            gray = image
        
        # Resize if too small
        h, w = gray.shape
        if h < 100 or w < 100:
            scale = max(200 / h, 200 / w)
            gray = cv2.resize(gray, None, fx=scale, fy=scale, interpolation=cv2.INTER_CUBIC)
        
        # Denoise
        denoised = cv2.fastNlMeansDenoising(gray)
        
        # Contrast enhancement
        clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
        enhanced = clahe.apply(denoised)
        
        # Binarization
        _, binary = cv2.threshold(enhanced, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        
        return binary
    
    # ========================================================================
    # UTILITY METHODS
    # ========================================================================
    
    def extract_numbers(self, image: Any) -> List[str]:
        """Extract only numbers from image"""
        text = self.extract_text(image)
        numbers = re.findall(r'\d+\.?\d*', text)
        return numbers
    
    def extract_emails(self, image: Any) -> List[str]:
        """Extract email addresses"""
        text = self.extract_text(image)
        emails = re.findall(r'[\w\.-]+@[\w\.-]+\.\w+', text)
        return emails
    
    def extract_urls(self, image: Any) -> List[str]:
        """Extract URLs"""
        text = self.extract_text(image)
        urls = re.findall(r'https?://[^\s<>"{}|\\^`[\]]+', text)
        return urls
    
    def find_text(self, image: Any, search_text: str) -> Optional[Tuple]:
        """Find specific text and return its bounding box"""
        results = self.extract_with_boxes(image)
        
        for text, bbox in results:
            if search_text.lower() in text.lower():
                return bbox
        
        return None


# =============================================================================
# STANDALONE TEST
# =============================================================================

if __name__ == "__main__":
    # Test OCR
    if CV_AVAILABLE:
        engine = OCREngine()
        
        # Create test image with text
        test_image = np.zeros((100, 400), dtype=np.uint8)
        cv2.putText(test_image, "Hello World 123", (10, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, 255, 2)
        
        # Extract
        text = engine.extract_text(test_image)
        print(f"Extracted: '{text}'")

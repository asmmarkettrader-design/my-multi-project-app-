#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                      📸 SCREEN CAPTURE - SCREENSHOT ENGINE                    ║
║                                                                              ║
║  Cross-platform screen capture                                              ║
║  Windows & Android support                                                  ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

import os
import platform
import time
from typing import Optional, Tuple, Any
from dataclasses import dataclass

try:
    import numpy as np
    NP_AVAILABLE = True
except ImportError:
    NP_AVAILABLE = False

try:
    from PIL import Image
    PIL_AVAILABLE = True
except ImportError:
    PIL_AVAILABLE = False


# =============================================================================
# SCREEN CAPTURE
# =============================================================================

class ScreenCapture:
    """
    📸 SCREEN CAPTURE - Screenshot Engine
    
    Cross-platform screen capture supporting:
    - Windows (PIL, pyautogui, mss)
    - Linux (mss, PIL)
    - Android (Termux API, screencap)
    
    Optimized for low memory usage and fast capture.
    """
    
    def __init__(self, capture_method: str = "auto", quality: int = 85):
        """Initialize Screen Capture"""
        self.quality = quality
        self.capture_method = capture_method
        self.platform = platform.system().lower()
        
        # Capture backends
        self.mss = None
        self.pyautogui = None
        
        # Stats
        self.capture_count = 0
        self.avg_capture_time_ms = 0
        
        # Initialize backend
        self._init_backend()
    
    def _init_backend(self):
        """Initialize capture backend"""
        if self.capture_method == "auto":
            # Try methods in order of preference
            if self._try_mss():
                pass
            elif self._try_pyautogui():
                pass
            elif self._try_pil():
                pass
            else:
                print("[ScreenCapture] No capture backend available")
        else:
            # Use specified method
            method_map = {
                'mss': self._try_mss,
                'pyautogui': self._try_pyautogui,
                'pil': self._try_pil
            }
            method_map.get(self.capture_method, self._try_mss)()
    
    def _try_mss(self) -> bool:
        """Try to initialize mss"""
        try:
            import mss
            self.mss = mss.mss()
            self.capture_method = "mss"
            print("[ScreenCapture] Using mss backend")
            return True
        except ImportError:
            return False
    
    def _try_pyautogui(self) -> bool:
        """Try to initialize pyautogui"""
        try:
            import pyautogui
            self.pyautogui = pyautogui
            self.capture_method = "pyautogui"
            print("[ScreenCapture] Using pyautogui backend")
            return True
        except ImportError:
            return False
    
    def _try_pil(self) -> bool:
        """Try to initialize PIL"""
        if PIL_AVAILABLE:
            try:
                if self.platform == "windows":
                    import PIL.ImageGrab
                    self.capture_method = "pil"
                    print("[ScreenCapture] Using PIL backend")
                    return True
            except:
                pass
        return False
    
    # ========================================================================
    # CAPTURE METHODS
    # ========================================================================
    
    def capture(self, region: Tuple[int, int, int, int] = None) -> Optional[Any]:
        """Capture full screen or region"""
        start_time = time.time()
        
        try:
            if self.capture_method == "mss":
                image = self._capture_mss(region)
            elif self.capture_method == "pyautogui":
                image = self._capture_pyautogui(region)
            elif self.capture_method == "pil":
                image = self._capture_pil(region)
            else:
                print("[ScreenCapture] No capture method available")
                return None
            
            # Update stats
            capture_time = (time.time() - start_time) * 1000
            self._update_stats(capture_time)
            
            return image
            
        except Exception as e:
            print(f"[ScreenCapture] Capture error: {e}")
            return None
    
    def _capture_mss(self, region: Tuple = None) -> Any:
        """Capture using mss"""
        if region:
            monitor = {
                "left": region[0],
                "top": region[1],
                "width": region[2] - region[0],
                "height": region[3] - region[1]
            }
        else:
            monitor = self.mss.monitors[1]  # Primary monitor
        
        screenshot = self.mss.grab(monitor)
        
        # Convert to numpy array
        return np.array(screenshot)
    
    def _capture_pyautogui(self, region: Tuple = None) -> Any:
        """Capture using pyautogui"""
        if region:
            screenshot = self.pyautogui.screenshot(region=region)
        else:
            screenshot = self.pyautogui.screenshot()
        
        # Convert to numpy array
        return np.array(screenshot)
    
    def _capture_pil(self, region: Tuple = None) -> Any:
        """Capture using PIL"""
        from PIL import ImageGrab
        
        screenshot = ImageGrab.grab(bbox=region)
        return np.array(screenshot)
    
    def capture_window(self, window_title: str) -> Optional[Any]:
        """Capture specific window"""
        try:
            if self.platform == "windows":
                return self._capture_window_windows(window_title)
            else:
                # Fallback to full screen
                return self.capture()
        except Exception as e:
            print(f"[ScreenCapture] Window capture error: {e}")
            return None
    
    def _capture_window_windows(self, window_title: str) -> Optional[Any]:
        """Capture window on Windows"""
        try:
            import pygetwindow as gw
            
            window = gw.getWindowsWithTitle(window_title)
            if window:
                win = window[0]
                region = (win.left, win.top, win.right, win.bottom)
                return self.capture(region)
        except Exception as e:
            print(f"[ScreenCapture] Windows capture error: {e}")
        
        return None
    
    def capture_android(self) -> Optional[Any]:
        """Capture on Android (Termux)"""
        try:
            # Use Android screencap
            os.system("screencap -p /sdcard/screen.png")
            
            if os.path.exists("/sdcard/screen.png"):
                from PIL import Image
                img = Image.open("/sdcard/screen.png")
                return np.array(img)
        except Exception as e:
            print(f"[ScreenCapture] Android capture error: {e}")
        
        return None
    
    # ========================================================================
    # WINDOW MANAGEMENT
    # ========================================================================
    
    def get_active_window(self) -> str:
        """Get title of active window"""
        try:
            if self.platform == "windows":
                import pygetwindow as gw
                active = gw.getActiveWindow()
                return active.title if active else "Unknown"
            elif self.platform == "linux":
                # Try using xdotool
                import subprocess
                result = subprocess.run(
                    ["xdotool", "getactivewindow", "getwindowname"],
                    capture_output=True, text=True
                )
                return result.stdout.strip() or "Unknown"
            else:
                return "Unknown"
        except:
            return "Unknown"
    
    def list_windows(self) -> list:
        """List all window titles"""
        try:
            if self.platform == "windows":
                import pygetwindow as gw
                return [w.title for w in gw.getAllWindows() if w.title]
            else:
                return []
        except:
            return []
    
    def get_screen_resolution(self) -> Tuple[int, int]:
        """Get screen resolution"""
        try:
            if self.capture_method == "mss":
                monitor = self.mss.monitors[1]
                return (monitor["width"], monitor["height"])
            elif self.capture_method == "pyautogui":
                size = self.pyautogui.size()
                return (size.width, size.height)
            else:
                # Capture and get size
                img = self.capture()
                if img is not None:
                    return (img.shape[1], img.shape[0])
                return (1920, 1080)
        except:
            return (1920, 1080)
    
    # ========================================================================
    # UTILITIES
    # ========================================================================
    
    def _update_stats(self, capture_time_ms: float):
        """Update capture statistics"""
        self.capture_count += 1
        self.avg_capture_time_ms = (
            (self.avg_capture_time_ms * (self.capture_count - 1) + capture_time_ms) / self.capture_count
        )
    
    def save_screenshot(self, filepath: str, region: Tuple = None) -> bool:
        """Capture and save screenshot"""
        image = self.capture(region)
        
        if image is None:
            return False
        
        try:
            from PIL import Image
            
            # Convert numpy to PIL
            if len(image.shape) == 3:
                img = Image.fromarray(image)
            else:
                img = Image.fromarray(image, mode='L')
            
            img.save(filepath, quality=self.quality)
            return True
            
        except Exception as e:
            print(f"[ScreenCapture] Save error: {e}")
            return False
    
    def get_stats(self) -> dict:
        """Get capture statistics"""
        return {
            'capture_method': self.capture_method,
            'platform': self.platform,
            'capture_count': self.capture_count,
            'avg_capture_time_ms': round(self.avg_capture_time_ms, 2),
            'resolution': self.get_screen_resolution()
        }


# =============================================================================
# STANDALONE TEST
# =============================================================================

if __name__ == "__main__":
    # Test screen capture
    capture = ScreenCapture()
    
    print(f"Stats: {capture.get_stats()}")
    
    # Test capture
    img = capture.capture()
    
    if img is not None:
        print(f"Captured image shape: {img.shape}")
        
        # Save test
        capture.save_screenshot("test_screenshot.jpg")
        print("Screenshot saved to test_screenshot.jpg")
    else:
        print("Capture failed")

#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                         🎯 UI DETECTOR - ELEMENT DETECTION                    ║
║                                                                              ║
║  YOLOv8-based UI element detection                                          ║
║  Identifies buttons, text fields, labels, images, etc.                      ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

import os
import time
from typing import List, Dict, Optional, Any, Tuple
from dataclasses import dataclass
from pathlib import Path

try:
    import cv2
    import numpy as np
    CV_AVAILABLE = True
except ImportError:
    CV_AVAILABLE = False

# YOLOv8
try:
    from ultralytics import YOLO
    YOLO_AVAILABLE = True
except ImportError:
    YOLO_AVAILABLE = False
    print("[WARNING] YOLOv8 not installed. UI detection limited.")

from .screen_perception import UIElement, UIElementType


# =============================================================================
# UI DETECTOR
# =============================================================================

class UIDetector:
    """
    🎯 UI DETECTOR - Element Detection Engine
    
    Uses YOLOv8 for real-time UI element detection.
    Can detect: buttons, text fields, labels, images, dropdowns, etc.
    
    Optimized for:
    - Web interfaces
    - Desktop applications
    - Mobile app screenshots
    """
    
    # YOLO class to UIElementType mapping
    CLASS_MAPPING = {
        0: UIElementType.BUTTON,
        1: UIElementType.TEXT_FIELD,
        2: UIElementType.LABEL,
        3: UIElementType.IMAGE,
        4: UIElementType.DROPDOWN,
        5: UIElementType.CHECKBOX,
        6: UIElementType.LINK,
        7: UIElementType.MENU,
        8: UIElementType.TABLE,
    }
    
    # Color coding for visualization
    COLORS = {
        UIElementType.BUTTON: (0, 255, 0),      # Green
        UIElementType.TEXT_FIELD: (255, 0, 0),   # Blue
        UIElementType.LABEL: (0, 255, 255),      # Cyan
        UIElementType.IMAGE: (255, 0, 255),      # Magenta
        UIElementType.DROPDOWN: (0, 165, 255),   # Orange
        UIElementType.CHECKBOX: (255, 255, 0),   # Yellow
        UIElementType.LINK: (128, 0, 128),       # Purple
        UIElementType.MENU: (128, 128, 0),       # Olive
        UIElementType.TABLE: (0, 128, 128),      # Teal
        UIElementType.UNKNOWN: (128, 128, 128),  # Gray
    }
    
    def __init__(self, model_path: str = None, confidence: float = 0.5):
        """Initialize UI Detector"""
        if not CV_AVAILABLE:
            raise RuntimeError("OpenCV required")
        
        self.confidence = confidence
        self.model = None
        self.using_yolo = False
        
        # Performance tracking
        self.detection_time_ms = 0
        self.total_detections = 0
        
        # Initialize model
        if YOLO_AVAILABLE:
            self._init_yolo(model_path)
        else:
            print("[UIDetector] Using fallback detection methods")
    
    def _init_yolo(self, model_path: str = None):
        """Initialize YOLOv8 model"""
        try:
            if model_path and os.path.exists(model_path):
                self.model = YOLO(model_path)
            else:
                # Use pretrained or default
                self.model = YOLO('yolov8n.pt')  # Nano model for speed
            
            self.using_yolo = True
            print("[UIDetector] YOLOv8 initialized")
            
        except Exception as e:
            print(f"[UIDetector] YOLO init failed: {e}")
            self.model = None
    
    # ========================================================================
    # DETECTION METHODS
    # ========================================================================
    
    def detect(self, image: Any) -> List[UIElement]:
        """Detect UI elements in image"""
        start_time = time.time()
        
        if self.using_yolo and self.model:
            elements = self._detect_yolo(image)
        else:
            elements = self._detect_fallback(image)
        
        # Update stats
        self.detection_time_ms = (time.time() - start_time) * 1000
        self.total_detections += len(elements)
        
        return elements
    
    def _detect_yolo(self, image: Any) -> List[UIElement]:
        """Detect using YOLOv8"""
        elements = []
        
        try:
            # Run inference
            results = self.model(image, verbose=False)
            
            # Parse results
            for result in results:
                boxes = result.boxes
                
                for box in boxes:
                    # Get coordinates
                    x1, y1, x2, y2 = box.xyxy[0].cpu().numpy()
                    x1, y1, x2, y2 = int(x1), int(y1), int(x2), int(y2)
                    
                    # Get confidence
                    conf = float(box.conf[0].cpu().numpy())
                    
                    if conf < self.confidence:
                        continue
                    
                    # Get class
                    cls_id = int(box.cls[0].cpu().numpy())
                    element_type = self.CLASS_MAPPING.get(cls_id, UIElementType.UNKNOWN)
                    
                    # Create element
                    element = UIElement(
                        element_type=element_type,
                        bbox=(x1, y1, x2, y2),
                        confidence=conf
                    )
                    
                    elements.append(element)
        
        except Exception as e:
            print(f"[UIDetector] YOLO detection error: {e}")
        
        return elements
    
    def _detect_fallback(self, image: Any) -> List[UIElement]:
        """Fallback detection using OpenCV"""
        elements = []
        
        try:
            # Convert to grayscale
            if len(image.shape) == 3:
                gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
            else:
                gray = image
            
            # Detect buttons (rectangular shapes)
            buttons = self._detect_rectangles(gray, min_area=1000, max_area=50000)
            for bbox in buttons:
                elements.append(UIElement(
                    element_type=UIElementType.BUTTON,
                    bbox=bbox,
                    confidence=0.7
                ))
            
            # Detect text fields (larger rectangles)
            text_fields = self._detect_rectangles(gray, min_area=50000, max_area=200000)
            for bbox in text_fields:
                elements.append(UIElement(
                    element_type=UIElementType.TEXT_FIELD,
                    bbox=bbox,
                    confidence=0.6
                ))
            
            # Detect images (contours with specific aspect ratios)
            images = self._detect_images(gray)
            for bbox in images:
                elements.append(UIElement(
                    element_type=UIElementType.IMAGE,
                    bbox=bbox,
                    confidence=0.65
                ))
        
        except Exception as e:
            print(f"[UIDetector] Fallback detection error: {e}")
        
        return elements
    
    def _detect_rectangles(self, gray: Any, min_area: int, max_area: int) -> List[Tuple]:
        """Detect rectangular shapes"""
        rectangles = []
        
        # Threshold
        _, thresh = cv2.threshold(gray, 127, 255, cv2.THRESH_BINARY_INV)
        
        # Find contours
        contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        for cnt in contours:
            area = cv2.contourArea(cnt)
            
            if min_area < area < max_area:
                x, y, w, h = cv2.boundingRect(cnt)
                
                # Check if rectangular
                peri = cv2.arcLength(cnt, True)
                approx = cv2.approxPolyDP(cnt, 0.04 * peri, True)
                
                if len(approx) == 4:  # Rectangle
                    rectangles.append((x, y, x + w, y + h))
        
        return rectangles
    
    def _detect_images(self, gray: Any) -> List[Tuple]:
        """Detect image regions"""
        images = []
        
        # Edge detection
        edges = cv2.Canny(gray, 50, 150)
        
        # Find contours
        contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        for cnt in contours:
            area = cv2.contourArea(cnt)
            
            if 10000 < area < 500000:
                x, y, w, h = cv2.boundingRect(cnt)
                aspect_ratio = float(w) / h
                
                # Images typically have reasonable aspect ratios
                if 0.5 < aspect_ratio < 3.0:
                    images.append((x, y, x + w, y + h))
        
        return images
    
    # ========================================================================
    # VISUALIZATION
    # ========================================================================
    
    def visualize(self, image: Any, elements: List[UIElement], show_labels: bool = True) -> Any:
        """Draw detected elements on image"""
        vis_image = image.copy()
        
        for element in elements:
            x1, y1, x2, y2 = element.bbox
            color = self.COLORS.get(element.element_type, (128, 128, 128))
            
            # Draw rectangle
            cv2.rectangle(vis_image, (x1, y1), (x2, y2), color, 2)
            
            # Draw label
            if show_labels:
                label = f"{element.element_type.value}: {element.confidence:.2f}"
                if element.text:
                    label += f" | {element.text[:20]}"
                
                # Label background
                (text_w, text_h), _ = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.5, 1)
                cv2.rectangle(vis_image, (x1, y1 - text_h - 8), (x1 + text_w, y1), color, -1)
                
                # Label text
                cv2.putText(vis_image, label, (x1, y1 - 5), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
        
        return vis_image
    
    def save_visualization(self, image: Any, elements: List[UIElement], filepath: str):
        """Save visualization to file"""
        vis = self.visualize(image, elements)
        cv2.imwrite(filepath, vis)
    
    # ========================================================================
    # UTILITY METHODS
    # ========================================================================
    
    def get_stats(self) -> Dict:
        """Get detector statistics"""
        return {
            'using_yolo': self.using_yolo,
            'confidence_threshold': self.confidence,
            'avg_detection_time_ms': round(self.detection_time_ms, 2),
            'total_detections': self.total_detections
        }
    
    def filter_by_confidence(self, elements: List[UIElement], min_conf: float = None) -> List[UIElement]:
        """Filter elements by confidence"""
        min_conf = min_conf or self.confidence
        return [e for e in elements if e.confidence >= min_conf]
    
    def filter_by_type(self, elements: List[UIElement], element_type: UIElementType) -> List[UIElement]:
        """Filter elements by type"""
        return [e for e in elements if e.element_type == element_type]
    
    def merge_overlapping(self, elements: List[UIElement], iou_threshold: float = 0.5) -> List[UIElement]:
        """Merge overlapping detections"""
        if not elements:
            return []
        
        # Sort by confidence
        sorted_elements = sorted(elements, key=lambda e: e.confidence, reverse=True)
        
        merged = []
        for element in sorted_elements:
            should_add = True
            
            for kept in merged:
                iou = self._calculate_iou(element.bbox, kept.bbox)
                if iou > iou_threshold:
                    should_add = False
                    break
            
            if should_add:
                merged.append(element)
        
        return merged
    
    def _calculate_iou(self, bbox1: Tuple, bbox2: Tuple) -> float:
        """Calculate Intersection over Union"""
        x1_1, y1_1, x2_1, y2_1 = bbox1
        x1_2, y1_2, x2_2, y2_2 = bbox2
        
        # Intersection
        xi1 = max(x1_1, x1_2)
        yi1 = max(y1_1, y1_2)
        xi2 = min(x2_1, x2_2)
        yi2 = min(y2_1, y2_2)
        
        inter_area = max(0, xi2 - xi1) * max(0, yi2 - yi1)
        
        # Union
        box1_area = (x2_1 - x1_1) * (y2_1 - y1_1)
        box2_area = (x2_2 - x1_2) * (y2_2 - y1_2)
        union_area = box1_area + box2_area - inter_area
        
        return inter_area / union_area if union_area > 0 else 0


# =============================================================================
# STANDALONE TEST
# =============================================================================

if __name__ == "__main__":
    # Test with sample image
    detector = UIDetector()
    
    # Create test image
    test_image = np.zeros((600, 800, 3), dtype=np.uint8)
    cv2.rectangle(test_image, (100, 100), (300, 200), (100, 100, 100), -1)  # Button-like
    cv2.rectangle(test_image, (400, 300), (700, 400), (150, 150, 150), -1)  # Text field-like
    
    # Detect
    elements = detector.detect(test_image)
    
    print(f"Detected {len(elements)} elements")
    for e in elements:
        print(f"  - {e.element_type.value}: {e.bbox} (conf: {e.confidence:.2f})")
    
    print(f"Stats: {detector.get_stats()}")

#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                    👁️ SCREEN PERCEPTION - NVIDIA NIM LOGIC                    ║
║                                                                              ║
║  Real-time screen scanning every 2 seconds                                  ║
║  UI element detection in non-API apps (Shopify, Meta Ads, Banking)          ║
║  Powered by Nvidia NIM microservices                                       ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

import os
import time
import threading
import queue
from typing import Dict, List, Optional, Any, Tuple, Callable
from dataclasses import dataclass, field
from enum import Enum
from collections import deque
import json

try:
    import cv2
    import numpy as np
    from PIL import Image
    CV_AVAILABLE = True
except ImportError:
    CV_AVAILABLE = False
    print("[WARNING] OpenCV not available for vision")

try:
    import requests
    REQUESTS_AVAILABLE = True
except ImportError:
    REQUESTS_AVAILABLE = False


# =============================================================================
# DATA CLASSES
# =============================================================================

class UIElementType(Enum):
    """Types of UI elements"""
    BUTTON = "button"
    TEXT_FIELD = "text_field"
    LABEL = "label"
    IMAGE = "image"
    DROPDOWN = "dropdown"
    CHECKBOX = "checkbox"
    LINK = "link"
    MENU = "menu"
    TABLE = "table"
    UNKNOWN = "unknown"

@dataclass
class UIElement:
    """Detected UI element"""
    element_type: UIElementType
    bbox: Tuple[int, int, int, int]  # x1, y1, x2, y2
    confidence: float
    text: str = ""
    attributes: Dict[str, Any] = field(default_factory=dict)
    timestamp: float = field(default_factory=time.time)

@dataclass
class ScreenState:
    """Current screen state snapshot"""
    timestamp: float
    elements: List[UIElement]
    raw_image: Optional[Any] = None
    active_window: str = ""
    screen_resolution: Tuple[int, int] = (1920, 1080)


# =============================================================================
# SCREEN PERCEPTION ENGINE
# =============================================================================

class ScreenPerception:
    """
    👁️ SCREEN PERCEPTION - Nvidia NIM Powered Vision
    
    Features:
    - Automatic screen scanning every 2 seconds
    - UI element detection using YOLOv8 + Nvidia NIM
    - OCR for text extraction
    - Change detection between scans
    - App-specific handlers (Shopify, Meta Ads, Banking)
    
    Use Cases:
    - Automate non-API apps
    - Extract data from any interface
    - Guide user through UI workflows
    """
    
    # Supported apps with custom handlers
    SUPPORTED_APPS = {
        'shopify': 'Shopify Admin',
        'meta_ads_manager': 'Meta Ads Manager',
        'facebook': 'Facebook',
        'instagram': 'Instagram',
        'banking': 'Banking App',
        'youtube': 'YouTube Studio',
        'tiktok': 'TikTok'
    }
    
    def __init__(
        self,
        screen_capture: Any,
        ui_detector: Any,
        nvidia_api_key: str = "",
        scan_interval: float = 2.0,
        enable_nim: bool = False
    ):
        """Initialize Screen Perception"""
        if not CV_AVAILABLE:
            raise RuntimeError("OpenCV required for screen perception")
        
        self.screen_capture = screen_capture
        self.ui_detector = ui_detector
        self.nvidia_api_key = nvidia_api_key
        self.scan_interval = scan_interval
        self.enable_nim = enable_nim and nvidia_api_key
        
        # State tracking
        self.current_state: Optional[ScreenState] = None
        self.previous_state: Optional[ScreenState] = None
        self.state_history = deque(maxlen=10)
        
        # Threading
        self.scanning = False
        self.scan_thread: Optional[threading.Thread] = None
        self.callbacks: List[Callable] = []
        
        # Detection results queue
        self.detection_queue = queue.Queue()
        
        # App handlers
        self.app_handlers: Dict[str, Any] = {}
        
        # Performance
        self.last_scan_time = 0
        self.avg_scan_time_ms = 0
        self.total_scans = 0
        
        print(f"[ScreenPerception] Initialized (scan interval: {scan_interval}s)")
        
        if self.enable_nim:
            print("[ScreenPerception] Nvidia NIM enabled")
    
    # ========================================================================
    # LIFECYCLE
    # ========================================================================
    
    def start(self):
        """Start continuous screen scanning"""
        if self.scanning:
            return
        
        self.scanning = True
        self.scan_thread = threading.Thread(target=self._scan_loop, daemon=True)
        self.scan_thread.start()
        print("[ScreenPerception] Scanning started")
    
    def stop(self):
        """Stop screen scanning"""
        self.scanning = False
        if self.scan_thread:
            self.scan_thread.join(timeout=2)
        print("[ScreenPerception] Scanning stopped")
    
    def _scan_loop(self):
        """Main scanning loop"""
        while self.scanning:
            try:
                start_time = time.time()
                
                # Perform scan
                self._perform_scan()
                
                # Calculate sleep time
                elapsed = time.time() - start_time
                sleep_time = max(0, self.scan_interval - elapsed)
                
                time.sleep(sleep_time)
                
            except Exception as e:
                print(f"[ScreenPerception] Scan error: {e}")
                time.sleep(self.scan_interval)
    
    def _perform_scan(self):
        """Perform single screen scan"""
        start_time = time.time()
        
        # Capture screen
        screenshot = self.screen_capture.capture()
        if screenshot is None:
            return
        
        # Detect UI elements
        elements = self.ui_detector.detect(screenshot)
        
        # Extract text via OCR
        elements = self._enrich_with_ocr(elements, screenshot)
        
        # Identify active app/window
        active_window = self.screen_capture.get_active_window()
        
        # Create state
        state = ScreenState(
            timestamp=time.time(),
            elements=elements,
            raw_image=screenshot,
            active_window=active_window,
            screen_resolution=screenshot.shape[:2][::-1] if hasattr(screenshot, 'shape') else (1920, 1080)
        )
        
        # Update state history
        self.previous_state = self.current_state
        self.current_state = state
        self.state_history.append(state)
        
        # Detect changes
        changes = self._detect_changes()
        
        # Update stats
        scan_time = (time.time() - start_time) * 1000
        self._update_stats(scan_time)
        
        # Notify callbacks
        if changes or not self.previous_state:
            self._notify_callbacks(state, changes)
        
        self.last_scan_time = time.time()
    
    def _update_stats(self, scan_time_ms: float):
        """Update performance statistics"""
        self.total_scans += 1
        self.avg_scan_time_ms = (
            (self.avg_scan_time_ms * (self.total_scans - 1) + scan_time_ms) / self.total_scans
        )
    
    # ========================================================================
    # DETECTION & OCR
    # ========================================================================
    
    def _enrich_with_ocr(self, elements: List[UIElement], image: Any) -> List[UIElement]:
        """Add OCR text to detected elements"""
        try:
            from .ocr_engine import OCREngine
            ocr = OCREngine()
            
            for element in elements:
                if element.element_type in [UIElementType.TEXT_FIELD, UIElementType.LABEL, UIElementType.BUTTON]:
                    # Extract region
                    x1, y1, x2, y2 = element.bbox
                    roi = image[y1:y2, x1:x2]
                    
                    # OCR
                    text = ocr.extract_text(roi)
                    element.text = text
                    
        except Exception as e:
            print(f"[ScreenPerception] OCR error: {e}")
        
        return elements
    
    def _detect_changes(self) -> List[Dict]:
        """Detect changes between current and previous state"""
        if not self.previous_state or not self.current_state:
            return []
        
        changes = []
        
        # Compare elements
        prev_elements = {self._element_hash(e): e for e in self.previous_state.elements}
        curr_elements = {self._element_hash(e): e for e in self.current_state.elements}
        
        # Find new elements
        for hash_val, element in curr_elements.items():
            if hash_val not in prev_elements:
                changes.append({
                    'type': 'added',
                    'element': element
                })
        
        # Find removed elements
        for hash_val, element in prev_elements.items():
            if hash_val not in curr_elements:
                changes.append({
                    'type': 'removed',
                    'element': element
                })
        
        # Check window change
        if self.previous_state.active_window != self.current_state.active_window:
            changes.append({
                'type': 'window_change',
                'from': self.previous_state.active_window,
                'to': self.current_state.active_window
            })
        
        return changes
    
    def _element_hash(self, element: UIElement) -> str:
        """Generate hash for element comparison"""
        return f"{element.element_type.value}_{element.bbox}_{element.text[:20]}"
    
    # ========================================================================
    # NVIDIA NIM INTEGRATION
    # ========================================================================
    
    def _call_nim_vision(self, image: Any, task: str = "detect") -> List[Dict]:
        """Call Nvidia NIM vision API"""
        if not self.enable_nim or not REQUESTS_AVAILABLE:
            return []
        
        try:
            # Encode image
            _, img_encoded = cv2.imencode('.jpg', image)
            img_base64 = img_encoded.tobytes()
            
            # NIM API endpoint
            url = "https://ai.api.nvidia.com/v1/cv/nvidia/nv-grounding-dino"
            
            headers = {
                "Authorization": f"Bearer {self.nvidia_api_key}",
                "Content-Type": "application/json"
            }
            
            payload = {
                "input": img_base64.decode('latin-1'),
                "task": task
            }
            
            response = requests.post(url, headers=headers, json=payload, timeout=10)
            
            if response.status_code == 200:
                return response.json().get('detections', [])
            else:
                print(f"[NIM] API error: {response.status_code}")
                return []
                
        except Exception as e:
            print(f"[NIM] Error: {e}")
            return []
    
    # ========================================================================
    # APP HANDLERS
    # ========================================================================
    
    def register_app_handler(self, app_name: str, handler: Any):
        """Register custom handler for specific app"""
        self.app_handlers[app_name] = handler
        print(f"[ScreenPerception] Handler registered for {app_name}")
    
    def get_active_app_handler(self) -> Optional[Any]:
        """Get handler for currently active app"""
        if not self.current_state:
            return None
        
        window_title = self.current_state.active_window.lower()
        
        for app_key, app_name in self.SUPPORTED_APPS.items():
            if app_key in window_title or app_name.lower() in window_title:
                return self.app_handlers.get(app_key)
        
        return None
    
    # ========================================================================
    # QUERY INTERFACE
    # ========================================================================
    
    def find_element(self, element_type: UIElementType = None, text_contains: str = None) -> Optional[UIElement]:
        """Find UI element by criteria"""
        if not self.current_state:
            return None
        
        for element in self.current_state.elements:
            # Filter by type
            if element_type and element.element_type != element_type:
                continue
            
            # Filter by text
            if text_contains and text_contains.lower() not in element.text.lower():
                continue
            
            return element
        
        return None
    
    def find_all_elements(self, element_type: UIElementType = None, text_contains: str = None) -> List[UIElement]:
        """Find all UI elements matching criteria"""
        if not self.current_state:
            return []
        
        results = []
        for element in self.current_state.elements:
            if element_type and element.element_type != element_type:
                continue
            if text_contains and text_contains.lower() not in element.text.lower():
                continue
            results.append(element)
        
        return results
    
    def get_clickable_elements(self) -> List[UIElement]:
        """Get all clickable elements"""
        clickable_types = [
            UIElementType.BUTTON,
            UIElementType.LINK,
            UIElementType.CHECKBOX,
            UIElementType.DROPDOWN
        ]
        
        return [e for e in self.current_state.elements if e.element_type in clickable_types] if self.current_state else []
    
    def get_text_fields(self) -> List[UIElement]:
        """Get all text input fields"""
        return self.find_all_elements(element_type=UIElementType.TEXT_FIELD)
    
    # ========================================================================
    # CALLBACKS
    # ========================================================================
    
    def add_callback(self, callback: Callable):
        """Add callback for state changes"""
        self.callbacks.append(callback)
    
    def remove_callback(self, callback: Callable):
        """Remove callback"""
        if callback in self.callbacks:
            self.callbacks.remove(callback)
    
    def _notify_callbacks(self, state: ScreenState, changes: List[Dict]):
        """Notify all registered callbacks"""
        for callback in self.callbacks:
            try:
                callback(state, changes)
            except Exception as e:
                print(f"[ScreenPerception] Callback error: {e}")
    
    # ========================================================================
    # UTILITY METHODS
    # ========================================================================
    
    def get_current_state(self) -> Optional[ScreenState]:
        """Get current screen state"""
        return self.current_state
    
    def get_stats(self) -> Dict:
        """Get perception statistics"""
        return {
            'total_scans': self.total_scans,
            'avg_scan_time_ms': round(self.avg_scan_time_ms, 2),
            'last_scan_ago': round(time.time() - self.last_scan_time, 2) if self.last_scan_time else None,
            'current_elements': len(self.current_state.elements) if self.current_state else 0,
            'nim_enabled': self.enable_nim,
            'scanning': self.scanning
        }
    
    def wait_for_element(self, element_type: UIElementType, text_contains: str, timeout: float = 10.0) -> Optional[UIElement]:
        """Wait for element to appear on screen"""
        start_time = time.time()
        
        while time.time() - start_time < timeout:
            element = self.find_element(element_type, text_contains)
            if element:
                return element
            time.sleep(0.5)
        
        return None
    
    def export_state(self, filepath: str):
        """Export current state to file"""
        if not self.current_state:
            return
        
        data = {
            'timestamp': self.current_state.timestamp,
            'active_window': self.current_state.active_window,
            'resolution': self.current_state.screen_resolution,
            'elements': [
                {
                    'type': e.element_type.value,
                    'bbox': e.bbox,
                    'confidence': e.confidence,
                    'text': e.text,
                    'attributes': e.attributes
                }
                for e in self.current_state.elements
            ]
        }
        
        with open(filepath, 'w') as f:
            json.dump(data, f, indent=2)


# =============================================================================
# STANDALONE TEST
# =============================================================================

if __name__ == "__main__":
    # Mock components for testing
    class MockScreenCapture:
        def capture(self):
            return np.zeros((1080, 1920, 3), dtype=np.uint8)
        
        def get_active_window(self):
            return "Test Window"
    
    class MockUIDetector:
        def detect(self, image):
            return [
                UIElement(UIElementType.BUTTON, (100, 100, 200, 150), 0.95, "Click Me"),
                UIElement(UIElementType.TEXT_FIELD, (300, 200, 500, 250), 0.88, ""),
            ]
    
    # Test
    perception = ScreenPerception(
        MockScreenCapture(),
        MockUIDetector(),
        scan_interval=2.0
    )
    
    # Manual scan
    perception._perform_scan()
    
    print(f"Stats: {perception.get_stats()}")
    print(f"Elements: {len(perception.current_state.elements) if perception.current_state else 0}")
